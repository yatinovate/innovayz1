<?php

return [

    /*
     * Is email activation required
     */
    'activation' => env('ACTIVATION', true)

];