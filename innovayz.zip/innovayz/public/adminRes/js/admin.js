/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function () {
    var skill_p = '{{ URL::to("admin/setting/quiz/wizard")}}';
    var username = $.cookie("cookie_skill_test_id");
    if (!!$.cookie('cookie_skill_test_id')) {
        $('#all_users').load(skill_p + '/' + username);
    } else {
       // $("#all_users").load('alluser');
    }




    $("#campaign_op").click(function ()
    {
        $('#all_users').load('setting/campaign');
    });
    
});