jQuery(document).ready(function($){
    $(window).scroll(function () {
        if ($(this).scrollTop() > 20) {
            $('.navbar').addClass('navbar-fixed-top active');
            //  $('.navbar').css("background","#ffffff");
        } else {
            $('.navbar').removeClass('navbar-fixed-top active');
        }
    }); 
    
	var formModal = $('.cd-user-modal'),
		formLogin = formModal.find('#cd-login'),
		formSignup = formModal.find('#cd-signup'),
		formForgotPassword = formModal.find('#cd-reset-password'),
		formModalTab = $('.cd-switcher'),
		tabLogin = formModalTab.children('li').eq(0).children('a'),
		tabSignup = formModalTab.children('li').eq(1).children('a'),
		forgotPasswordLink = formLogin.find('#forgetformpop'),
		backToLoginLink = formForgotPassword.find('.cd-form-bottom-message a'),
		mainNav = $('.main-nav');

	//open modal
	mainNav.on('load', function(event){
		$(event.target).is(mainNav) && mainNav.children('ul').toggleClass('is-visible');
	});
        
        

	//open sign-up form
	mainNav.on('click', '.cd-signup', signup_selected);
	//open login-form form
	mainNav.on('click', '.cd-signin', login_selected);

	//close modal
	formModal.on('click', function(event){
		if( $(event.target).is(formModal) || $(event.target).is('.cd-close-form') ) {
			formModal.removeClass('is-visible');
		}	
                $("body").css({'overflow': 'auto'});
	});
	//close modal when clicking the esc keyboard button
	$(document).keyup(function(event){
    	if(event.which=='27'){
    		formModal.removeClass('is-visible');
	    }
    });

	//switch from a tab to another
	formModalTab.on('click', function(event) {
		event.preventDefault();
		( $(event.target).is( tabLogin ) ) ? login_selected() : signup_selected();
	});

	

	//show forgot-password form 
	forgotPasswordLink.on('click', function(event){
		event.preventDefault();
		forgot_password_selected();
	});

	//back to login from the forgot-password form
	backToLoginLink.on('click', function(event){
		event.preventDefault();
		login_selected();
	});

	function login_selected(){
            $("body").css({'overflow': 'hidden'});
		mainNav.children('ul').removeClass('is-visible');
		formModal.addClass('is-visible');
		formLogin.addClass('is-selected');
		formSignup.removeClass('is-selected');
		formForgotPassword.removeClass('is-selected');
		tabLogin.addClass('selected');
		tabSignup.removeClass('selected');
                $("#login_form")[0].reset();
                $("#login_form").find('.form-group').removeClass('has-error');
                $("#login_form").find('.form-group').find(".help-block strong").text("");
                
	}

	function signup_selected(){
            $("body").css({'overflow': 'hidden'});
		mainNav.children('ul').removeClass('is-visible');
		formModal.addClass('is-visible');
		formLogin.removeClass('is-selected');
		formSignup.addClass('is-selected');
		formForgotPassword.removeClass('is-selected');
		tabLogin.removeClass('selected');
		tabSignup.addClass('selected');
                $("#signup_form")[0].reset();
                $("#signup_form").find('.form-group').removeClass('has-error');
                $("#signup_form").find('.form-group').find(".help-block strong").text("");
	}

	function forgot_password_selected(){$("body").css({'overflow': 'hidden'});
		formLogin.removeClass('is-selected');
		formSignup.removeClass('is-selected');
		formForgotPassword.addClass('is-selected');
	}



	//IE9 placeholder fallback
	//credits http://www.hagenburger.net/BLOG/HTML5-Input-Placeholder-Fix-With-jQuery.html
	if(!Modernizr.input.placeholder){
		$('[placeholder]').focus(function() {
			var input = $(this);
			if (input.val() == input.attr('placeholder')) {
				input.val('');
		  	}
		}).blur(function() {
		 	var input = $(this);
		  	if (input.val() == '' || input.val() == input.attr('placeholder')) {
				input.val(input.attr('placeholder'));
		  	}
		}).blur();
		$('[placeholder]').parents('form').submit(function() {
		  	$(this).find('[placeholder]').each(function() {
				var input = $(this);
				if (input.val() == input.attr('placeholder')) {
			 		input.val('');
				}
		  	})
		});
	}
        
        
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.scrollup').show();

        } else {
            $('.scrollup').fadeOut();
        }
    });

    $('.scrollup').click(function () {
        $("html, body").animate({scrollTop: 0}, 600);
        return false;
    });
FormValidation.Validator.password = {
        validate: function(validator, $field, options) {
            var value = $field.val();
            if (value === '') {
                return true;
            }

            if (value.length < 8) {
                return false;
            }
            if (value === value.toLowerCase()) {
                return false;
            }
            if (value === value.toUpperCase()) {
                return false;
            }
            if (value.search(/[0-9]/) < 0) {
                return false;
            }

            return true;
        }
    };
    $('#login_form').formValidation({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            email: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }, emailAddress: {
                            message: 'The input is not a valid email address'
                        }
                }
            },
            password: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    },password: {
                        message: 'Must be more than 8 characters including upper case,lower case & digit'
                    }
                }
            }
        }
    });
    $('#forget_form').formValidation({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            resetpass: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }, emailAddress: {
                            message: 'The input is not a valid email address'
                        }
                }
            }
        }
    });
    
  $('#signup_form').formValidation({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            name: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    },regexp: {
                        regexp: /^[a-z\s]+$/i,
                        message: 'The full name can consist of alphabetical characters and spaces only'
                    }
                }
            },email: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }, emailAddress: {
                            message: 'The input is not a valid email address'
                        }
                }
            },password: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    },password: {
                        message: 'Must be more than 8 characters including upper case,lower case & digit'
                    }
                }
            }, confirmpass: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    },
                    identical: {
                        field: 'password',
                        message: 'The password and its confirm are not the same'
                    },password: {
                        message: 'Must be more than 8 characters including upper case,lower case & digit'
                    }
                }
            },u_check: {
                validators: {
                    notEmpty: {
                        message: ''
                    }
                }
            }
        }
    }) .on('err.field.fv', function(e, data) {
            data.element
                .data('fv.messages')
                .find('.help-block[data-fv-for="u_check"]').hide();
        });
    /*******live search******/
    $("#searcbar_categ li a").click(function(){
          var currnt=  $(this);
          currnt.parent().parent().find(".active").removeClass("active");
          currnt.parent().addClass('active');
          $("#catcont").html($(this).text()+ ' <span class="caret"></span>');    
        });
    $("#searchbar").keyup(function () {
        
        var url=$(".searchnav").attr("dataa_u");
        var category=$(".searchnav").find("li.active a").attr("data_value");
        var searchid = $(this).val();
        var dataString = 'search=' + searchid+'&category='+category;
        if (searchid != '' && searchid.length > 3) {
            $.ajax({
                type: "POST",
                url: url,
                data: dataString,
                cache: false,
                success: function (html) {
                    $("#result").html(html).show();
                }
            });
        }
        return false;
    });
    $(window).load(function() {
    var searchwidth=$("#search-form .input-group").width();
$("#result").width(searchwidth);
});
    
$("#search-form").on('submit',{'category':$(".searchnav").find("li.active a").text()},function(event){
        $("#searchusercategory").val($(".searchnav").find("li.active a").attr("data_value"));
});
    jQuery(document).on("click", function (e) {
        var $clicked = $(e.target);
        if (!$clicked.hasClass("search")) {
            jQuery("#result").fadeOut();
        }
    });
});

  

  
   
//credits http://css-tricks.com/snippets/jquery/move-cursor-to-end-of-textarea-or-input/
jQuery.fn.putCursorAtEnd = function() {
	return this.each(function() {
    	// If this function exists...
    	if (this.setSelectionRange) {
      		// ... then use it (Doesn't work in IE)
      		// Double the length because Opera is inconsistent about whether a carriage return is one character or two. Sigh.
      		var len = $(this).val().length * 2;
      		this.focus();
      		this.setSelectionRange(len, len);
    	} else {
    		// ... otherwise replace the contents with itself
    		// (Doesn't work in Google Chrome)
      		$(this).val($(this).val());
    	}
	});
};