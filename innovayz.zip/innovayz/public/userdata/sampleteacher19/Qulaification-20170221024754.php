<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Model;

class Qulaification extends Model
{
    protected $fillable = ['user_id', 'study_place','qualification','stream','institute'];
}
