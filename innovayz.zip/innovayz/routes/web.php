<?php

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | This file is where you may define all of the routes that are handled
  | by your application. Just tell Laravel the URIs it should respond
  | to using a Closure or controller method. Build something great!
  |
 */
Route::get('/error-page', ['uses' => 'Guest\GuestController@setErrorpage', 'as' => 'ex.errorpage']);

Route::get('/vistorcount', ['uses' => 'Guest\GuestController@setVisitor', 'as' => 'user.vistorcount']);
Route::group(['middleware' => 'guest'], function() {
    Route::get('/', ['uses' => 'Guest\GuestController@index', 'as' => '/']);

    Route::post('/login', 'Auth\LoginController@authenticate');
    Route::post('/register', ['as' => 'register', 'uses' => 'Auth\RegisterController@register']);
    Route::get('/terms', ['uses' => 'Guest\GuestController@terms', 'as' => 'terms']);
    Route::get('/privacy-policy', ['uses' => 'Guest\GuestController@privacy', 'as' => 'privacypolicy']);
    Route::get('/services', ['uses' => 'Guest\GuestController@services', 'as' => 'services']);
    
    Route::post('/forget-password', ['uses' => 'Auth\LoginController@forget', 'as' => 'forget-password']);
    Route::get('/password/reset/{token}', 'Auth\LoginController@passwordset');
    Route::post('password/setpassword', ['uses' => 'Auth\LoginController@setpassword', 'as' => 'setpassword']);
    
    Route::get('/activate/{token}', ['as' => 'authenticated.activate', 'uses' => 'Auth\ActivateController@activate']);


    Route::get('social/auth/redirect/{provider}', 'Auth\SocialController@redirectToProvider');
    Route::get('social/auth/{provider}', 'Auth\SocialController@handleProviderCallback');

    /* Route::get('not-activated', ['as' => 'not-activated', 'uses' => function () {
      return view('errors.not-activated');
      }]);
      $s = 'social.';
      Route::get('/social/redirect/{provider}', ['as' => $s . 'redirect', 'uses' => 'Auth\SocialController@getSocialRedirect']);
      Route::get('/social/handle/{provider}', ['as' => $s . 'handle', 'uses' => 'Auth\SocialController@getSocialHandle']); */
});

/***********Search*****************/
Route::post('/searcher', 'Search\SearchController@find');
Route::get('/follow', ['as' => 'follow', 'uses' => 'Search\SearchController@follow']);


Route::group(['prefix' => 'search'], function() {
    $rt = "search.";
    Route::get('/', ["uses" => 'Search\SearchController@searchSubmitView', "as" => $rt."submit"]);
    Route::get('query/', ["uses" => 'Search\SearchController@searchitemView', "as" => $rt."item"]);
    Route::get('query/skill', ["uses" => 'Search\SearchController@searchitemViewSkill', "as" => $rt."skillitem"]);
    Route::get('query/location', ["uses" => 'Search\SearchController@searchitemViewlocation', "as" => $rt."locitem"]);
    Route::get('/searchitem/{key}', 'ProfileController@searchitemView');
});


/***********Search end*****************/

Route::get('/check', 'DashboardController@follwerCount');
//Route::get('/check', 'ProfileController@asd');
Route::post('/chk', 'ProfileController@das');


Route::group(['prefix' => 'user/profile'], function() {
    $pr = "profile.";
    Route::get('/', ['uses' => 'Profile\GuestProfile@index', 'as' => $pr . 'index']);
});

Route::post('/Subscription', ['uses' => 'UserController@Subscription', 'as' => 'Subscription']);
Route::group(['middleware' => 'c_auth'], function() {

    Route::get('/Profile/about/{userid}', 'ProfileController@about');
    Route::get('/Profile/question/{userid}', 'ProfileController@questionarie');
});

Route::get('/E-Library', ['uses' => 'UserController@E-Library', 'as' => 'E-Library']);
Route::get('/Skill-test', ['uses' => 'UserController@Skill-test', 'as' => 'Skill-test']);
Route::get('/Questionaire', ['uses' => 'UserController@Questionaire', 'as' => 'Questionaire']);
Route::get('/Share', ['uses' => 'UserController@Share', 'as' => 'Share']);






Route::post('/signup', [
    'uses' => 'UserController@postSignUP',
    'as' => 'signup'
]);


Route::get('register/verify/{confirmationCode}', [
    'as' => 'confirmation_path',
    'uses' => 'UserController@confirm'
]);
//Route::post('/login','UserController@postSignIN');
//Route::get('/groups/getUser','Group\GroupController@getUser');
Route::group(['middleware' => 'auth:all'], function() {
    $a = 'authenticated.';
    Route::get('/logout', ['as' => 'logout', 'uses' => 'Auth\LoginController@logout']);
//    Route::get('/activate/{token}', ['as' => $a . 'activate', 'uses' => 'Auth\ActivateController@activate']);
    //   Route::get('/activate', ['as' => $a . 'activation-resend', 'uses' => 'Auth\ActivateController@resend']);
});

Route::get('/postlogincheck', [
    'uses' => 'UserController@postlogincheck',
    'as' => 'postlogincheck'
]);



Route::group(['prefix' => 'user', 'middleware' => 'auth:user'], function() {
    Route::group(['middleware' => 'activated'], function () {
        $rt = "user.";
        Route::post('/postknowledge', ['uses' => 'PostController@postknowledge', 'as' => $rt . 'postknowledge']);
    });
});


Route::group(['prefix' => 'profile/wizard', 'middleware' => 'auth:user'], function() {
    Route::group(['middleware' => 'activated'], function () {

        Route::get('/socilaprofile', ['uses' => 'ProfileController@socilaprofile', 'as' => 'socilaprofile']);
        Route::post('/socilaprofileuser', ['uses' => 'ProfileController@socilaprofileuser', 'as' => 'socilaprofileuser']);
        $a = 'profile.';
        Route::get('profile-completion', ['uses' => 'ProfileController@verifyprofilesteps', 'as' => 'verifyprofilesteps']);
        Route::post('profile-completion/areaintreset', ['uses' => 'ProfileController@areaIntreset', 'as' => $a . 'areaintrest']);
        Route::post('profile-completion/updateareaintrest', ['uses' => 'ProfileController@updateareaintrest', 'as' => $a . 'updateareaintrest']);
        Route::get('getuserstream', ['uses' => 'ProfileController@getStream', 'as' => $a . 'getuserstream']);
        Route::get('institutes', ['uses' => 'ProfileController@getInstitute', 'as' => $a . 'getinstitute']);
        Route::get('get-city', ['uses' => 'ProfileController@getCity', 'as' => $a . 'getCity']);
        Route::post('contact', ['as' => $a . 'contact', 'uses' => 'ProfileController@saveContact']);
        Route::post('update/contact', ['as' => $a . 'updatecontact', 'uses' => 'ProfileController@updatesaveContact']);
        Route::get('update', ['uses' => 'ProfileController@updateprofile', 'as' => $a . 'updateprofile']);
        Route::get('areaintreset/delete', ['as' => $a . 'deltearea', 'uses' => 'ProfileController@deleteareaIntreset']);

        Route::group(['prefix' => 'student'], function() {
            $stud = 'student.';
            Route::get('step1', ['as' => $stud . 'step1', 'uses' => 'Profile\StudentController@step1view']);
            Route::post('step1', ['as' => $stud . 'savestep1', 'uses' => 'Profile\StudentController@step1']);
            Route::get('step2', ['as' => $stud . 'step2', 'uses' => 'Profile\StudentController@step2view']);
            Route::post('step2', ['as' => $stud . 'savestep2', 'uses' => 'Profile\StudentController@step2']);
            Route::get('step3', ['as' => $stud . 'step3', 'uses' => 'Profile\StudentController@step3view']);

            Route::get('update/step1', ['as' => $stud . 'update1', 'uses' => 'Profile\StudentController@updatestepView1']);
            Route::post('update/step1', ['as' => $stud . 'updatesave1', 'uses' => 'Profile\StudentController@updatestep1']);
            Route::get('update/step2', ['as' => $stud . 'update2', 'uses' => 'Profile\StudentController@updatestepView2']);
            Route::post('update/step2', ['as' => $stud . 'updatesave2', 'uses' => 'Profile\StudentController@updatestep2']);
            Route::get('update/step2/add', ['as' => $stud . 'addqulai', 'uses' => 'Profile\StudentController@addnewstep2']);
            Route::post('update/step2/add', ['as' => $stud . 'savenewqual', 'uses' => 'Profile\StudentController@saveaddnewstep2']);
            Route::get('update/step3', ['as' => $stud . 'update3', 'uses' => 'Profile\StudentController@updatestep3View']);
        });
        Route::group(['prefix' => 'teacher'], function() {
            $coll = 'teacher.';
            Route::get('step1', ['as' => $coll . 'step1', 'uses' => 'Profile\TeacherController@step1view']);
            Route::post('step1', ['as' => $coll . 'savestep1', 'uses' => 'Profile\TeacherController@step1']);
            Route::get('step2', ['as' => $coll . 'step2', 'uses' => 'Profile\TeacherController@step2view']);
            Route::post('step2', ['as' => $coll . 'savestep2', 'uses' => 'Profile\TeacherController@step2']);
            Route::get('step3', ['as' => $coll . 'step3', 'uses' => 'Profile\TeacherController@step3view']);
            Route::post('step3', ['as' => $coll . 'savestep3', 'uses' => 'Profile\TeacherController@step3']);
            Route::get('step4', ['as' => $coll . 'step4', 'uses' => 'Profile\TeacherController@step4view']);

            Route::get('update/step1', ['as' => $coll . 'update1', 'uses' => 'Profile\TeacherController@updatestepView1']);
            Route::post('update/step1', ['as' => $coll . 'updatesave1', 'uses' => 'Profile\TeacherController@updatestep1']);
            Route::get('update/step2', ['as' => $coll . 'update2', 'uses' => 'Profile\TeacherController@updatestepView2']);
            Route::post('update/step2', ['as' => $coll . 'updatesave2', 'uses' => 'Profile\TeacherController@updatestep2']);
            Route::get('update/step2/add', ['as' => $coll . 'addqulai', 'uses' => 'Profile\TeacherController@addnewstep2']);
            Route::post('update/step2/add', ['as' => $coll . 'savenewqual', 'uses' => 'Profile\TeacherController@saveaddnewstep2']);
            Route::get('update/step3', ['as' => $coll . 'update3', 'uses' => 'Profile\TeacherController@updatestepView3']);
            Route::post('update/step3', ['as' => $coll . 'saveupdate3', 'uses' => 'Profile\TeacherController@saveupdatestepView3']);
            Route::get('update/step4', ['as' => $coll . 'update4', 'uses' => 'Profile\TeacherController@updatestep4View']);
        });

        Route::group(['prefix' => 'college'], function() {

            $coll = 'college.';
            Route::get('step1', ['as' => $coll . 'step1', 'uses' => 'Profile\CollgeController@step1view']);
            Route::post('step1', ['as' => $coll . 'savestep1', 'uses' => 'Profile\CollgeController@step1']);
            Route::get('step2', ['as' => $coll . 'step2', 'uses' => 'Profile\CollgeController@step2view']);
            Route::post('step2', ['as' => $coll . 'savestep2', 'uses' => 'Profile\CollgeController@step2']);
            Route::get('getstream/{cat_id}', 'Profile\CollgeController@getStream');
            Route::get('step3', ['as' => $coll . 'step3', 'uses' => 'Profile\CollgeController@step3view']);

            Route::get('update/step1', ['as' => $coll . 'update1', 'uses' => 'Profile\CollgeController@updatestepView1']);
            Route::post('update/step1', ['as' => $coll . 'updatesave1', 'uses' => 'Profile\CollgeController@updatestep1']);
            Route::get('update/step2', ['as' => $coll . 'update2', 'uses' => 'Profile\CollgeController@updatestepView2']);
            Route::post('update/step2', ['as' => $coll . 'updatesave2', 'uses' => 'Profile\CollgeController@updatestep2']);
            Route::get('update/step2/addcourse', ['as' => $coll . 'update2addcourse', 'uses' => 'Profile\CollgeController@updatecourseView']);
            Route::post('update/step2/addcourse', ['as' => $coll . 'updatesave2course', 'uses' => 'Profile\CollgeController@saveupdatecourseView']);
            Route::get('update/step3', ['as' => $coll . 'update3', 'uses' => 'Profile\CollgeController@updatestepView3']);
            Route::post('update/step3', ['as' => $coll . 'updatesave3', 'uses' => 'Profile\CollgeController@updatestep3']);
            Route::post('Profile/wizard/college/update/step3', 'Profile\CollgeController@updatestep3');
        });
    });
});

/* * **compelte profile */


Route::get('not-activated', ['as' => 'not-activated', 'uses' => function () {
        return view('errors.not-activated');
    }]);

Route::group(['middleware' => 'auth:user'], function() {
    
});




/* * *******
 * Admin** */


Route::get('/admin', ['uses' => "admin\AdminAuth@LoginView", 'as' => 'loginview']);
Route::post('/adminlogin', ['uses' => "admin\AdminAuth@adminlogin", 'as' => 'adminlogin']);


/* * *****************
 * **Post Question **
 * **************** */



Route::group(['prefix' => 'user/question', 'middleware' => 'auth:user'], function() {
    Route::group(['middleware' => 'activated'], function () {
        $pre = "question.";
        Route::post('areaintreset', ['uses' => 'Question\QuestionController@areaIntreset', 'as' => $pre . 'areaintreset']);
        Route::post('postquestion', ['uses' => 'Question\QuestionController@post', 'as' => $pre . 'post']);
        Route::get('myquestion', ['uses' => 'Question\QuestionController@questionlist', 'as' => $pre . 'myquestion']);
        Route::get('search/', ['uses' => 'Question\QuestionController@QuestionTagSearch', 'as' => $pre . 'qtagsearch']);
        Route::get('question-detail', ['uses' => 'Question\QuestionController@QuestionDetail', 'as' => $pre . 'q_detail']);
        Route::get('ansered-question', ['uses' => 'Question\QuestionController@answeredQuetions', 'as' => $pre . 'ansqlist']);
        Route::get('unansered-question', ['uses' => 'Question\QuestionController@unansweredQuetions', 'as' => $pre . 'unansqlist']);
        Route::get('anserpopup/', ['uses' => 'Question\QuestionController@viewPop', 'as' => $pre . 'anspop']);
        Route::post('postanswer/', ['uses' => 'Question\QuestionController@postAnswer', 'as' => $pre . 'postAnswer']);

        Route::get('answers/', ['as' => $pre . 'answerlist', 'uses' => 'Question\QuestionController@answerlist']);
        Route::get('answers/delete/', ['as' => $pre . 'answerdelete', 'uses' => 'Question\QuestionController@deleteAnswer']);
        Route::post('answers/like/', ['as' => $pre . 'answerlike', 'uses' => 'Question\QuestionController@likeAnswer']);
        Route::get('suggested/', ['as' => $pre . 'suggested', 'uses' => 'Question\QuestionController@getSuggestedQuetions']);
    });
});
 

/* * **********chalenge test** */
Route::group(['prefix' => 'user/challenge/manage', 'middleware' => 'auth:user'], function() {
    Route::group(['middleware' => 'activated'], function () {
        $teach = "teach.";
        Route::get('/', ['as' => $teach . "index", 'uses' => "challenge\challengeController@index"]);
        Route::get('/get-challenges', ['as' => $teach . "getChallenge", 'uses' => "challenge\challengeController@getskillView"]);
        Route::get('/create', ['as' => $teach . "creator", 'uses' => "challenge\challengeController@createor"]);
        Route::get('/modify', ['as' => $teach . "modify", 'uses' => "challenge\challengeController@manage"]);
        Route::get('/challenge-detail/', ['as' => $teach . "chdetail", 'uses' => "challenge\challengeController@viewChallengeDetail"]);


        Route::get('/creater', ['as' => $teach . "createwizard", 'uses' => "challenge\challengeController@createView"]);
        Route::post('/creater', ['as' => $teach . "savecreatewizard", 'uses' => "challenge\challengeController@postcreateview"]);
        Route::get('/wizard/', ['as' => $teach . "startwizard", 'uses' => "challenge\challengeController@challengeWizard"]);
        Route::get('wizard/questiontype/', ['as' => $teach . "qtype", 'uses' => "challenge\challengeController@qtype"]);
        Route::get('/update', ['as' => $teach . "update", 'uses' => "challenge\challengeController@updateQuestion"]);
        Route::post('/uploader', ['as' => $teach . "csvupload", 'uses' => "challenge\challengeController@post_upload"]);
        Route::get('/uploader/creater/', ['as' => $teach . "csvcreater", 'uses' => "challenge\challengeController@createviewCSV"]);
        Route::post('/uploader/creater/', ['as' => $teach . "savecsvcreater", 'uses' => "challenge\challengeController@postcreateviewCSV"]);

        Route::get('/preview/', ['as' => $teach . "preview", 'uses' => "challenge\challengeController@previewTest"]);
        Route::get('/publish', ['as' => $teach . "publish", 'uses' => "challenge\challengeController@publish"]);
        Route::get('/publish/mailer', ['as' => $teach . "publishmail", 'uses' => "challenge\challengeController@notifysubjectusers"]);
        
        Route::get('/archive', ['as' => $teach . "archive", 'uses' => "challenge\challengeController@archive"]);
        Route::post('/addquestion', ['as' => $teach . "addQuestion", 'uses' => "challenge\challengeController@addQuestion"]);
        Route::get('/edit/', ['as' => $teach . "editQuestion", 'uses' => "challenge\challengeController@editQuestion"]);
        Route::get('/delete/', ['as' => $teach . "delete", 'uses' => "challenge\challengeController@deleteTest"]);

        Route::post('/find-group/', ['as' => $teach . "findgroup", 'uses' => "challenge\challengeController@findGroup"]);
        Route::post('/sendto/', ['as' => $teach . "sendto", 'uses' => "challenge\challengeController@sendSavedTest"]);

        Route::post('/wizard/multi_option', ['as' => $teach . "savemulti", 'uses' => "challenge\challengeController@postMulti_option"]);
        Route::post('/wizard/multi_option/update', ['as' => $teach . "savemultiupdate", 'uses' => "challenge\challengeController@postMulti_optionUpdate"]);
        Route::post('/wizard/multi_choice', ['as' => $teach . "savemultichoice", 'uses' => "challenge\challengeController@postMulti_choice"]);
        Route::post('/wizard/multi_choice/update', ['as' => $teach . "savemultichoiceupdate", 'uses' => "challenge\challengeController@postMulti_choiceUpdate"]);
        Route::post('/wizard/ture_false', ['as' => $teach . "savetrue", 'uses' => "challenge\challengeController@postTrue_false"]);
        Route::post('/wizard/ture_false/update', ['as' => $teach . "savetrueupdate", 'uses' => "challenge\challengeController@postTrue_falseUpdate"]);
    });
});
/* * ****Student****************** */

Route::group(['prefix' => 'user/challenge/', 'middleware' => 'auth:user'], function() {
    Route::group(['middleware' => 'activated'], function () {
        $teach = "student.";
        Route::get('/active-challenge/', ['as' => $teach . "geterpage", 'uses' => "DashboardController@getChallenge"]);
        Route::get('/get-challenge/', ['as' => $teach . "getter", 'uses' => "DashboardController@getchallengeView"]);
        Route::get('/Instruction/', ['as' => $teach . "instruction", 'uses' => "challenge\TakeController@showInstruction"]);
        Route::get('/leaderboard/', ['as' => $teach . "leaderbord", 'uses' => "challenge\TakeController@getleaderView"]);
        Route::get('/quiz/', ['as' => $teach . "startquiz", 'uses' => "challenge\TakeController@index"]);
        Route::get('/quiz/timer', ['as' => $teach . "tmerstartquiz", 'uses' => "challenge\TakeController@updatetime"]);
        Route::post('/quiz/result', ['as' => $teach . "resultpage", 'uses' => "challenge\TakeController@result"]);
    });
});

Route::group(['prefix' => 'user/skill-test/', 'middleware' => 'auth:user'], function() {
    Route::group(['middleware' => 'activated'], function () {
        $teach = "student.";
        Route::get('/active-skill-test/', ['as' => $teach . "activeskill", 'uses' => "Quiz\SkillController@getActiveSkill"]);
        Route::get('/get-skill/', ['as' => $teach . "activeskillgrid", 'uses' => "Quiz\SkillController@getActiveSkillGrid"]);
        Route::get('/Instruction/', ['as' => $teach . "skillinstruction", 'uses' => "Quiz\SkillController@showInstruction"]);
        Route::get('/leaderboard/', ['as' => $teach . "skillleaderbord", 'uses' => "Quiz\SkillController@getleaderView"]);
        Route::get('/quiz/', ['as' => $teach . "startskillquiz", 'uses' => "Quiz\SkillController@index"]);
        Route::get('/quiz/timer', ['as' => $teach . "tmerstartskillquiz", 'uses' => "Quiz\SkillController@updatetime"]);
        Route::post('/quiz/result', ['as' => $teach . "skillresultpage", 'uses' => "Quiz\SkillController@submitQuiz"]);
    });
});


Route::get('images/get/{image}/{a}', function($image, $a) {

    //do so other checks here if you wish
    $storagePath = Storage::disk('public')->getDriver()->getAdapter()->getPathPrefix();
    $image = $storagePath . $image . '/' . $a;
    if (!File::exists($image))
        abort(404);

    return Image::make($image)->response('jpg'); //will ensure a jpg is always returned  
});






/* * *******
 * Dashboard** */

Route::group(['prefix' => 'user/Dashboard', 'middleware' => 'auth:user'], function() {
    Route::group(['middleware' => 'activated'], function () {
        $a = "Dashboard.";
        Route::get('/', ['uses' => 'DashboardController@Dashboard', 'as' => 'Dashboard']);
        Route::post('/profileupdate', ['uses' => 'DashboardController@update_avatar', 'as' => $a . 'profilepic']);
        Route::get('/Connections}', ['uses' => 'DashboardController@getConnection', 'as' => $a . 'connections']);
        Route::post('/invite', ['uses' => 'DashboardController@postInvite', 'as' => $a . 'invite']);
        Route::get('/Questions', ['uses' => 'DashboardController@getQuetions', 'as' => $a . 'getquestions']);
        

        Route::get('/notification', ['as' => $a . 'notify', 'uses' => 'UserController@notify']);
        Route::get('/notification/read', ['as' => $a . 'notifyread', 'uses' => 'UserController@notifyread']);
        Route::get('/notification/all', ['as' => $a . 'allnotifyread', 'uses' => 'UserController@allnotifyread']);

        /*         * ******************
         * ****Message System*******
         * ****************** */
        Route::post('/send-message', ['uses' => 'UserController@sendMessage', 'as' => $a . 'sendMessage']);
        Route::get('tests', 'MessageController@tests');
        Route::get('messages', ['uses' => 'MessageController@getallMessage', 'as' => $a . 'getallmsg']);
        Route::get('message/{id}', 'MessageController@chatHistory')->name('message.read');
        Route::post('message/send', 'MessageController@ajaxSendMessage')->name('message.send');



        /*         * ******************
         * ****e library*******
         * ****************** */
        Route::group(['prefix' => 'e-library'], function() {

            Route::get('/', ['uses' => 'Elibrary\ElibraryController@getview', 'as' => 'e-library']);
            Route::get('/gdrive', ['uses' => 'Elibrary\ElibraryController@getGdriveView', 'as' => 'elib.gview']);
            Route::get('/google-connect', ['uses' => 'Elibrary\ElibraryController@gAcess', 'as' => 'elib.gaccess']);
            Route::get('/gdriveacess', ['uses' => 'Elibrary\ElibraryController@gdriveacess', 'as' => 'elib.gcallback']);
            Route::get('/documents', ['uses' => 'Elibrary\ElibraryController@gdocs', 'as' => 'gdocs']);
            Route::get('/Disconnect', ['uses' => 'Elibrary\ElibraryController@gAcessDisconnect', 'as' => 'gAcessDisconnect']);
            Route::post('/postknowledgeattachement', ['uses' => 'PostController@postknowledgeattachement', 'as' => 'postknowledgeattachement']);
        });
    });
});





















Route::group(['prefix' => 'user/groups', 'middleware' => 'auth:user'], function() {
    Route::group(['middleware' => 'activated'], function () {
        $g = "groups.";
        Route::post('/save', ['as' => $g . 'save', 'uses' => 'Group\GroupController@saveGroup']);
        Route::post('/getUser', ['as' => $g . 'getuser', 'uses' => 'Group\GroupController@getUser']);
        Route::post('getUser/addmore', ['as' => $g . 'getadduser', 'uses' => 'Group\GroupController@addgetUser']);
        Route::get('group-detail/', ['as' => $g . 'index', 'uses' => 'Group\GroupController@getGroupView']);
        Route::post('groups/savechat', ['as' => $g . 'savechat', 'uses' => 'Group\GroupController@saveChat']);
        Route::get('groups/getchat/{id}', ['as' => $g . 'getchat', 'uses' => 'Group\GroupController@getChat']);
        Route::get('groups/deleteuser/{id}', ['as' => $g . 'deleteuser', 'uses' => 'Group\GroupController@deleteUser']);
        Route::post('groups/adduser', ['as' => $g . 'adduser', 'uses' => 'Group\GroupController@addUserGroup']);


        Route::get('/all-groups', ['as' => $g . 'getall', 'uses' => 'Group\GroupController@getallGroup']);
        Route::get('manage', ['as' => $g . 'manage', 'uses' => 'Group\GroupController@manageGroup']);
        Route::post('manage/update', ['as' => $g . 'manageUpdate', 'uses' => 'Group\GroupController@manageUpdateGroup']);
        Route::get('manage/delete', ['as' => $g . 'manageDelete', 'uses' => 'Group\GroupController@manageDeleteGroup']);
        Route::get('manage/archived', ['as' => $g . 'archived', 'uses' => 'Group\GroupController@setArchived']);

        Route::post('join', ['as' => $g . 'join', 'uses' => 'Group\GroupController@joinGroup']);
        Route::get('join/accept', ['as' => $g . 'joinaccept', 'uses' => 'Group\GroupController@setJoinAccept']);
        Route::get('join/delete', ['as' => $g . 'joindelete', 'uses' => 'Group\GroupController@delteJoin']);
    });
});

/*******Admin Account ******/
Route::group(['prefix' => 'admin', 'middleware' => 'auth:administrator'], function() {
    Route::group(['middleware' => 'activated'], function () {
        $a = "admin.";
        Route::get('dashboard', ['uses' => "admin\AdminAuth@AdminDashboard", 'as' => 'admin.home']);
        Route::get('onlineuser', ['uses' => "admin\AdminAuth@viewonlineUser", 'as' => $a . 'viewonlineUser']);
        Route::get('/newuser/paginate', ['uses' => "admin\AdminAuth@viewNewUser", 'as' => $a . 'viewNewUser']);
        /*         * ***add user ** */
        Route::get('/adduser', ['uses' => "admin\AdminAuth@viewadduser", 'as' => $a . 'adduser']);
        Route::post('/adduser', ['uses' => "admin\AdminAuth@adduser", 'as' => $a . 'saveadduser']);
        /*         * ****validate user */
        Route::any('validateuser', ['uses' => "admin\AdminAuth@validateUser", 'as' => $a . 'validateUser']);
        Route::post('/validateuser/delete', ['uses' => "admin\AdminAuth@deleteUser", 'as' => $a . 'deleteUser']);
        Route::post('/validateuser/deleteall', ['uses' => "admin\AdminAuth@deleteAll", 'as' => $a . 'deleteAll']);
        Route::post('/validateuser/validate', ['uses' => "admin\AdminAuth@validateSingle", 'as' => $a . 'validatesingle']);
        Route::post('/validateuser/validateAll', ['uses' => "admin\AdminAuth@validateAll", 'as' => $a . 'validateAll']);
        Route::post('/validateuser/resend', ['uses' => "admin\AdminAuth@resend", 'as' => $a . 'resend']);
        Route::post('/validateuser/resendAll', ['uses' => "admin\AdminAuth@resendAll", 'as' => $a . 'resendAll']);

        /*         * **skill settings */
        Route::get('/area-interest', ['uses' => "admin\AdminAuth@set_skills", 'as' => $a . 'set_skills']);
        Route::post('/area-interest/delete', ['uses' => "admin\AdminAuth@Skilldelete", 'as' => $a . 'delskill']);
        Route::post('/area-interest/deleteall', ['uses' => "admin\AdminAuth@SkilldeleteAll", 'as' => $a . 'delallskill']);
        Route::post('/area-interest/validate', ['uses' => "admin\AdminAuth@validateSkills", 'as' => $a . 'validateskill']);
        Route::post('/area-interest/validateAll', ['uses' => "admin\AdminAuth@validateSkillsAll", 'as' => $a . 'validateallskill']);
        /*         * ******Institute settings */
        Route::get('/institute', ['uses' => "admin\AdminAuth@un_inst", 'as' => $a . 'institute']);
        Route::post('/institute/validate', ['uses' => "admin\AdminAuth@validateInstitute", 'as' => $a . 'validateinstitute']);
        Route::post('/institute/validateAll', ['uses' => "admin\AdminAuth@validateInstituteAll", 'as' => $a . 'validateallinstitute']);
        Route::post('/institute/delete', ['uses' => "admin\AdminAuth@InstituteDelete", 'as' => $a . 'deleteinstitute']);
        Route::post('/institute/deleteAll', ['uses' => "admin\AdminAuth@InstituteDeleteAll", 'as' => $a . 'deleteallinstitute']);
        /*         * ******Stream settings */
        Route::get('/stream', ['uses' => "admin\AdminAuth@set_stream", 'as' => $a . 'stream']);
        Route::post('/stream/validate', ['uses' => "admin\AdminAuth@validateStream", 'as' => $a . 'validatestream']);
        Route::post('/stream/validateAll', ['uses' => "admin\AdminAuth@validateStreamAll", 'as' => $a . 'validatestreamall']);
        Route::post('/stream/delete', ['uses' => "admin\AdminAuth@Streamdelete", 'as' => $a . 'deltestream']);
        Route::post('/stream/deleteAll', ['uses' => "admin\AdminAuth@StreamdeleteAll", 'as' => $a . 'deltestreamall']);

        /*         * ******Campaign settings */
        Route::get('/campaign', ['uses' => "admin\AdminAuth@create_camp", 'as' => $a . 'campaign']);
        Route::post('/campaign/skills', ['uses' => "admin\AdminAuth@getSkillsCampaign", 'as' => $a . 'skillcampaign']);
        Route::post('/campaign/quiz', ['uses' => "admin\AdminAuth@getSkillsquizCampaign", 'as' => $a . 'getskillcampaign']);
        Route::post('/campaign', ['uses' => "admin\AdminAuth@savecampaign", 'as' => $a . 'savecampaign']);
        Route::get('/campaign/manage', ['uses' => "admin\AdminAuth@manageCampaign", 'as' => $a . 'manageCampaign']);
        Route::get('/campaign/manage/delete', ['uses' => "admin\AdminAuth@deleteCampaign", 'as' => $a . 'deleteCampaign']);
        Route::get('/campaign/manage/publish', ['uses' => "admin\AdminAuth@publishCampaign", 'as' => $a . 'publishCampaign']);
        Route::get('/campaign/manage/edit', ['uses' => "admin\AdminAuth@editCampaign", 'as' => $a . 'editCampaign']);
        Route::post('/campaign/manage/edit', ['uses' => "admin\AdminAuth@updateCampaign", 'as' => $a . 'updatesavecampaign']);
        Route::get('/campaign/manage/check', ['uses' => "admin\AdminAuth@checkCampaign", 'as' => $a . 'campaignpreview']);


        /*         * ******Advertisement settings */
        Route::get('/advertisement', ['uses' => "admin\AdminAuth@createAdblock", 'as' => $a . 'adblock']);
        Route::post('/advertisement', ['uses' => "admin\AdminAuth@saveAdblock", 'as' => $a . 'saveadblock']);
        Route::get('/advertisement/manage', ['uses' => "admin\AdminAuth@manageADblock", 'as' => $a . 'manageadblock']);
        Route::get('/advertisement/manage/delete', ['uses' => "admin\AdminAuth@deleteADblock", 'as' => $a . 'deleteADblock']);



        /*         * **skill test*** */
        Route::get('/quiz', ['uses' => "admin\Quiz@makeQuiz", 'as' => $a . 'quiz']);
        Route::get('/quiz/create', ['uses' => "admin\Quiz@createview", 'as' => $a . 'createquiz']);
        Route::post('/quiz/create', ['uses' => "admin\Quiz@postcreateview", 'as' => $a . 'savecreatequiz']);
        Route::post('quiz/create/areaintreset', ['uses' => 'ProfileController@areaIntreset', 'as' => $a . 'areaintrest']);

        Route::get('/quiz/wizard/', ['uses' => "admin\Quiz@skillWizard", 'as' => $a . 'quizwizard']);
        Route::get('/quiz/wizard/questiontype/', ['uses' => "admin\Quiz@qtype", 'as' => $a . 'questype']);
        Route::get('/quiz/update', ['uses' => "admin\Quiz@updateQuestion", 'as' => $a . 'update']);

        Route::post('quiz/wizard/multi_option', ['uses' => "admin\Quiz@postMulti_option", 'as' => $a . 'savemulti']);
        Route::post('/quiz/wizard/multi_choice', ['uses' => "admin\Quiz@postMulti_choice", 'as' => $a . 'savemultichoice']);
        Route::post('/quiz/wizard/ture_false', ['uses' => "admin\Quiz@postTrue_false", 'as' => $a . 'savetrue']);

        Route::post('/quiz/wizard/multi_choice/update', ['uses' => "admin\Quiz@postMulti_choiceUpdate", 'as' => $a . 'savemultichoiceupdate']);
        Route::post('/quiz/wizard/multi_option/update', ['uses' => "admin\Quiz@postMulti_optionUpdate", 'as' => $a . 'savemultiupdate']);
        Route::post('/quiz/wizard/ture_false/update', ['uses' => "admin\Quiz@postTrue_falseUpdate", 'as' => $a . 'savetrueupdate']);


        Route::post('/quiz/upload', ['uses' => "admin\Quiz@post_upload", 'as' => $a . 'csvupload']);
        Route::get('/quiz/upload/create', ['uses' => "admin\Quiz@createviewCSV", 'as' => $a . 'csvcreater']);
        Route::post('/quiz/upload/create', ['uses' => "admin\Quiz@postcreateviewCSV", 'as' => $a . 'savecsvcreater']);


        Route::get('/quiz/preview', ['uses' => "admin\Quiz@previewTest", 'as' => $a . 'preview']);
        Route::get('/quiz/manage', ['uses' => "admin\Quiz@manage", 'as' => $a . 'manage']);
        Route::get('/quiz/manage/publish', ['uses' => "admin\Quiz@publish", 'as' => $a . 'publish']);
        Route::get('/quiz/manage/archive', ['uses' => "admin\Quiz@archive", 'as' => $a . 'archive']);
        Route::post('/quiz/manage/addquestion', ['uses' => "admin\Quiz@addQuestion", 'as' => $a . 'addQuestion']);
        Route::get('/quiz/manage/edit', ['uses' => "admin\Quiz@editQuestion", 'as' => $a . 'editQuestion']);
        Route::get('/quiz/manage/delte', ['uses' => "admin\Quiz@deleteTest", 'as' => $a . 'delete']);
    });
});

Route::get('/CountUsers', ['uses' => "admin\AdminAuth@CountUsers", 'as' => 'CountUsers']);


/*******Admin End ****/