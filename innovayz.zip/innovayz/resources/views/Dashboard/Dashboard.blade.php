@extends('layouts.master')
@section('headscript')
<link rel="stylesheet" href="{{asset("Dashboard/css/dashboard.css")}}">
<link href="{{asset("css/magicsuggest-min.css")}}" rel="stylesheet">
<title>My Home Page | Innovayz</title>
<style>
    .post_item p{
        -ms-word-break: break-all;
        word-break: break-all;

        /* Non standard for webkit */
        word-break: break-word;

        -webkit-hyphens: auto;
        -moz-hyphens: auto;
        -ms-hyphens: auto;
        hyphens: auto;
    }
</style>

@stop
@section('content')
@include("Dashboard.includes.upper_panel")

<div class="container-fluid">
    <div class="row">

        <div class="col-md-2">
            @include("Dashboard.includes.sidebar")
        </div>
        <div class="col-md-5 post_section">
            @include("errors.status")

            @if(count($postdta))
            @foreach ($postdta as $poster)
            <div class="post_item">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <?php
                        $usermain = \App\Models\User::find($poster->post->user_id);
                        ?>
                        @if($poster->post->Taguser)
                        
                        @if($poster->post->user_id==Auth::user()->id)
                        <?php
                        $usersdta= \App\Models\Profile\PostKnowledgeUser::where("post_id",$poster->post->id)->get();
                        $users="";
                        foreach($usersdta as $taguser){
                            if($poster->post->user_id!=$taguser->user->id){
                                $users='<a style="color: #007acc" href="'.Route("profile.index",["user-id" => $taguser->user->id, 'user-name' => $taguser->user->name]).'">'. $taguser->user->name .'</a>'.','.$users;
                                
                            }
                        }
                        ?>
                        <h2>{{Auth::user()->name}} with {!!rtrim($users, ',')!!}</h2>
                        <br>
                        @else
                        
                        <h2>{{Auth::user()->name}} tagged by <a style="color: #007acc" href="{{Route("profile.index",["user-id" => $usermain->id, 'user-name' => $usermain->name])}}">{{ $usermain->name }}</a></h2>
                        <br>
                        @endif
                        @endif
                        <h3>{{ $poster->post->Subject }}</h3>
                        {!! urldecode($poster->post->Description) !!}
                        @if($poster->post->attachement)
                        <br>
                        <a style="color: #007acc" href="{{URL::to("laradrop/download/".$poster->post->attachement_id)}}">{{$poster->post->attachement}}</a>
                        @endif
                        <br><br>
                        <h2 style="text-align: right;">Post by: <a style="color: #007acc" href="{{Route("profile.index",["user-id" => $usermain->id, 'user-name' => $usermain->name])}}">{{ $usermain->name }}</a></h2>
                    </div>
                </div>
            </div>

            @endforeach
            @else
            <div class="post_item">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <p><b>Start the Conversation !</b> Be the first to post to this community</p>
                    </div>
                </div>
            </div>
            @endif


        </div>
        <div class="col-md-3">
            <div class="ivite_freind">
                <div class="thumbnail center well well-sm text-center">
                    <div class="invite_alert"></div>
                    <h2>Invite a Friend</h2>
                    <form id="inviteform" method="post" role="form" action="{{Route("Dashboard.invite")}}">
                        {{csrf_field()}}
                        <div class="input-group">
                            <input class="form-control" type="text" id="email" name="email" placeholder="your@email.com">
                            <span class="input-group-btn">
                                <button class="btn btn-info" type="submit"><i class="fa fa-send"></i></button>
                            </span>
                        </div>
                    </form>
                </div> 
            </div>
            @if(Auth::user()->user_type==='students' || Auth::user()->user_type==='teachers')
            <div class="ask_question">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 text-center">

                        <a class="btn btn-info" data-toggle="modal" data-target="#postquestion">Ask a Question</a>
                    </div>
                </div>
            </div>
            <div class="dash_panel">
                <div class="row">
                    <div class="col-md-12">
                        <h2>Questions for you</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12 col-sm-12">
                        <ul class="event-list">
                            <div class='bg_loader'><img src='{{asset('adminRes/img/ajax-loader.gif')}}' class='img-responsive'></div>
                        </ul>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12 col-sm-12 text-right">
                        <a class="" id="moreqlink" href="{{Route("question.myquestion")}}#unansget">More..</a>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="postquestion" role="dialog">
                <div class="modal-dialog">

                    <!-- Modal content-->
                    <div class="modal-content question_modal">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title text-center">Ask Question</h4>
                        </div>
                        <div class="modal-body clearfix">

                            <form class="form-horizontal" id="ask_questn" method="post" action="{{Route("question.post")}}">
                                {{ csrf_field() }}
                                <div class="form-group">                                              
                                    <label class="col-sm-12 control-label">Enter your question</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="enter_question" name="enter_question"  placeholder="Enter question">
                                    </div>
                                </div>
                                <div class="form-group">  
                                    <label class="col-sm-12 control-label">Question description</label>
                                    <div class="col-sm-12">
                                        <textarea class="form-control" name="qdescription" id="qdescription" placeholder="Enter Description"></textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-12 control-label">Enter your tags</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="questiontags" name="questiontags" placeholder="Enter your tags">                            
                                        <input type="hidden" id="questiontags1" name="questiontags1" >
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <input type="submit" class="btn btn-primary pull-right" id="submit_qus" value="Post Question">
                                    </div>
                                </div>

                            </form>
                        </div>                                       
                    </div>

                </div>
            </div>

            @endif

        </div>

        <div class="col-md-2">
            @include("Dashboard.includes.advertisement")
        </div>
    </div>
</div>
</div>
@stop
@section('jsfiles')
@include("Dashboard.includes.footer")

<script>
    $(function () {

        $('#inviteform').formValidation({
            framework: 'bootstrap',
            icon: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                email: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }, emailAddress: {
                            message: 'The input is not a valid email address'
                        }
                    }
                }

            }
        });



        $.get('{{Route("Dashboard.getquestions")}}', function (data) {
            $(".dash_panel .event-list").html(data);

            var childq = $(".event-list").children().length;
            
            if (childq < 5) {
                $("#moreqlink").hide();
            } else {
                $("#moreqlink").show();
            }
        });


        $('#postquestion').on('hidden.bs.modal', function () {
            var form = $("#ask_questn");
            form.find('input, textarea, select').attr('disabled', false);
            form.find('.form-group').removeClass('has-error');
            form.find('.form-group').find(".help-block strong").text("");
        });


        var ms1 = $('#questiontags').magicSuggest({
            allowFreeEntries: false,
            valueField: 'value',
            displayField: 'label',
            required: true,
            allowDuplicates: false,
            data: '{{Route("question.areaintreset")}}',
            ajaxConfig: {
                xhrFields: {
                    withCredentials: true
                }
            }
        });

        $(ms1).on('selectionchange', function (e, m) {
            var asd = this.getValue();
            $("#questiontags1").val(asd);
            var asd = this.getValue();
            $('#ask_questn').find('[name="questiontags1"]').val(asd).end().formValidation('revalidateField', 'questiontags1');
        });
        $('#ask_questn').formValidation({
            framework: 'bootstrap',
            icon: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                enter_question: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }, qdescription: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                },
                questiontags1: {
                    excluded: false,
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }

            }
        });
    });
</script>

@endsection
<!-- Modal -->



