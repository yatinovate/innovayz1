<div class="head-detail">
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-2">
                <div class="head-img text-center">
                    
                        <img src="{{ asset(Auth::user()->avatar)}}" alt="picture" class="img-responsive img-thumbnail">
                        <form enctype="multipart/form-data" method="post" id="profpicupdater" action="{{Route("Dashboard.profilepic")}}">
                            {{ csrf_field() }}
                            <label for="avtar_pop">
                                <input type="file" id="avtar_pop" name="avatar" style="display:none">&nbsp;Update Profile Image
                            </label>
                        </form>
                </div>
            </div>
            <div class="col-md-9">
                <div class="row">
                    <div class="col-md-9">
                        <div class="head_content">
                            <h2>{{Auth::user()->name }}
                            </h2>
                            <ul> 
                                <li><i class="fa fa-user"></i> {{substr(Auth::user()->user_type , 0, -1) }}</li>
                                <?php
                                if (Auth::user()->user_type === 'students' || Auth::user()->user_type === 'teachers') {
                                    if(count(Auth::user()->qulaifiaction)){
                                        $highestarray = array();
                                    foreach (Auth::user()->qulaifiaction as $qual) {
                                        switch ($qual->specalization->qual_group) {
                                            case "":
                                                $highestarray[] = array("id" => $qual->id, "education" => $qual->specalization->qual_group);
                                                break;
                                            case "Graduation":
                                                $highestarray[] = array("id" => $qual->id, "education" => $qual->specalization->qual_group);
                                                break;
                                            case "Post Graduation":
                                                $highestarray[] = array("id" => $qual->id, "education" => $qual->specalization->qual_group);
                                                break;
                                        }
                                    }
                                    function compareByName($a, $b) {
                                        return strcmp($a["education"], $b["education"]);
                                    }
                                    usort($highestarray, 'compareByName');
                                    $keys = array_keys($highestarray);
                                    $lastKey = $keys[count($keys) - 1];
                                    $maxqulaification= App\Models\User\Qulaification::find($highestarray[$lastKey]["id"]);
                                    echo '<li><i class="fa fa-book"></i> ' . $maxqulaification->specalization->qulaification . ' ('.$maxqulaification->maxstream->qulaification.')</li>';
                                    
                                    }   
                                }
                                ?>                        
                                <?php
                                if (isset($contact->state) || isset($contact->city)) {
                                    ?>    
                                    <li><i class="fa fa-map-marker"></i>&nbsp;&nbsp;{{isset($contact->state) ? ucfirst($contact->state) : '' }}, {{isset($contact->city) ? ucfirst($contact->city) : '' }}
                                    </li>
                                    <?php
                                }
                                ?>

                            </ul>
                            <ul class="araa">
                                @foreach (Auth::user()->user_area as $error)
                                <li><a>{{ \App\Models\User\AreaIntrest::find($error->area_int->id)->area_intrest }}</a></li>
                                @endforeach
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 text-right">
                        <a href="" class="post_knowledge btn " data-toggle="modal" data-target="#postknowledge">POST YOUR KNOWLEDGE</a>
                    </div>
                </div>
                @if(Auth::user()->user_type==='students' || Auth::user()->user_type==='teachers')
                <div class="row">
                    <div class="col-md-12">
                        <div class="head_nav">
                        <ul class="nav nav-pills nav-justified">
                            <li><a href="{{Route("question.myquestion")}}">Q & A ({{$questncount}})</a></li>
                            @if(Auth::user()->user_type==='students')
                            <li><a href="{{Route("student.activeskill")}}">Skill Test ({{$skillcount}})</a></li>
                            @endif
                            <li><a href="{{route('e-library')}}">Library ({{$ecount}})</a></li>
                            @if(Auth::user()->user_type==='students')
                            <li><a href="{{Route("student.geterpage")}}">Challenge ({{$chlcount}})</a></li>
                            @endif
                            @if(Auth::user()->user_type==='teachers')
                            <li><a href="{{Route("teach.index")}}">Challenge ({{$chlcount}})</a></li>
                            @endif
                        </ul>
                    </div>
                    </div>
                    
                </div>
                @endif
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="postknowledge" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title">
                    Post your Knowledge
                </h4>
            </div>
            <!-- Modal Body -->
            <div class="modal-body">

                <form class="form-horizontal" role="form" id="postform" method="post" action="{{Route("user.postknowledge")}}">
                     {{ csrf_field() }}
                    <div class="form-group">
                        <label  class="col-sm-12 control-label">Subject</label>
                        <div class="col-sm-12">
                            <input type="text" class="form-control" placeholder="Enter Your Subject" name="subject" id="subject"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label  class="col-sm-12 control-label">Tagging</label>
                        <div class="col-sm-12">
                            <input type="text" class="form-control" placeholder="Tag Connections" id="tagcon" name="tagcon"/>
                            <input type="hidden" class="form-control" id="tagcon1" name="tagcon1"/>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-12 control-label">Description</label>
                        <div class="col-sm-12">
                            <textarea class="form-control" id="poster"  placeholder="Enter details of post" name="poster"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="submit" class="btn btn-info  btn-lg pull-right" id="next-step">Post</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="postimage" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content question_modal">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center">Edit Profile Pic</h4>
            </div>
            <div class="modal-body clearfix">



                <div class="dropzone" id="dropzoneFileUpload">
                    <input type="hidden" name="_token" id="vrcsrf" value="<?php echo Session::token(); ?>">
                </div>
            </div>                                       
        </div>

    </div>
</div>