<div class="panel-group" id="accordion">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h4 class="panel-title"><a href="{{Route("Dashboard")}}"><span class="fa fa-desktop"></span>&nbsp;&nbsp;Recend Posts</a></h4>
        </div>
    </div>
    <div class="panel panel-default">
        <div class="panel-heading">
            <h4 class="panel-title dash_header"><span class="fa fa-users"></span>&nbsp;&nbsp;Groups</h4>
        </div>
        <div id="collapseOne" class="panel-collapse collapse in">
            <ul class="list-group grouplist">
                <?php
                $grpn= App\Models\Group\GroupsUser::where("user_id",Auth::user()->id)->get();
                if(count($grpn)){ 
                    foreach($grpn as $grp_u){
                        if(!$grp_u->groupinfo->archive){
                        echo '<li class="list-group-item">'
                        . '<a href="'.Route("groups.index",["group-id"=>$grp_u->groupinfo->id,"group-name"=>$grp_u->groupinfo->group_name]).'">'.$grp_u->groupinfo->group_name.'</a></li>';
                    }
                    }
                }
                if(count($grpn)>1){
                   echo '<li class="list-group-item"><a href="'.Route("groups.getall").'">Show All Groups</a></li>';
                }
                ?>
            </ul>

        </div>
    </div>
    @if(Auth::user()->user_type==='teachers' || Auth::user()->user_type==='colleges' )
    <div class="panel panel-default">
        <div class="panel-heading">
            <h4 class="panel-title"><a href="{{Route("groups.manage")}}"><span class="fa fa-cog"></span>&nbsp;&nbsp;Manage Groups</a></h4>
        </div>
    </div>
    <div class="panel panel-default">
        <div class="panel-heading">
            <h4 class="panel-title" style="cursor: pointer" data-toggle="modal" data-target="#postgroup"><span class="fa fa-plus-circle"></span>&nbsp;&nbsp;Create a Group</h4>
        </div>
    </div>
    @endif
    @if(Auth::user()->user_type==='teachers' || Auth::user()->user_type==='students' )
    <div class="panel panel-default">
        <div class="panel-heading">
            <h4 class="panel-title" style="cursor: pointer" data-toggle="modal" data-target="#postgroupsearch"><span class="fa fa-users"></span>&nbsp;&nbsp;Join a Group</h4>
        </div>
    </div>
    @endif

</div>
<div class="panel panel-default">
    <div class="panel-heading">
        <h4 class="panel-title"><span class="fa fa-user-md"></span>&nbsp;&nbsp;Connections</h4>
    </div>
    <div id="collapseOne" class="panel-collapse collapse in">
        <ul class="list-group">
            <li class="list-group-item">
                <a href="{{Route("Dashboard.connections",["utype"=>"students"])}}">Student</a>
                <span class="badge">{{$stucount}}</span>
            </li>
            <li class="list-group-item">
                <a href="{{Route("Dashboard.connections",["utype"=>"teachers"])}}">Teacher</a>
                <span class="badge">{{$teachstucount}}</span>
            </li>
            <li class="list-group-item">
                <a href="{{Route("Dashboard.connections",["utype"=>"colleges"])}}">College</a>
                <span class="badge">{{$collstucount}}</span>
            </li>
        </ul>
    </div>
</div>

@if(Auth::user()->user_type==='students' )
@if(count($suggested))
<div class="panel panel-default">
    <div class="panel-heading">
        <h4 class="panel-title dash_header"><span class="fa fa-graduation-cap"></span>&nbsp;Suggested Teachers</h4>
    </div>
    <div id="collapseOne" class="panel-collapse collapse in">
        <ul class="list-group techer_list">
            <?php
            foreach($suggested as $area){
                $user = \App\Models\User::find($area);
                    if ($user->user_type == 'teachers') {
                        echo '<li class="list-group-item"><a href="'.Route("profile.index", ["user-id" => $user->id, 'user-name' => $user->name]).'">
                            <div class="row">
                            <div class="col-md-4"><img src="'.asset($user->avatar).'" alt="picture" class="img-responsive"></div>
                            <div class="col-md-8"><span>'.$user->name.'</span></div>
                            </div>
                            </a></li>';
                    }
            }
            ?>
        </ul>
    </div>
</div>
@endif
@endif


<div class="modal fade" id="postgroup" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content question_modal">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center">Your Virtual Class/Group</h4>
            </div>
            <div class="modal-body clearfix">

                <form class="form-horizontal" method="post" action="{{Route("groups.save")}}" id="group_form">
                    {{ csrf_field() }}
                    <div class="form-group">                                              
                        <label class="col-sm-12 control-label">Enter Group Name</label>
                        <div class="col-sm-12">
                            <input type="text" class="form-control" name="group_name"  placeholder="Enter Group Name">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-12 control-label">Add Members to the group</label>
                        <div class="col-sm-12">
                            <input type="text" class="form-control" id="group_persons1" name="group_persons1" placeholder="Add Members to the group">
                            <input type="hidden" id="group_persons" name="group_persons">
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <input type="submit" class="btn btn-primary pull-right" value="Create Group">
                        </div>
                    </div>

                </form>
            </div>                                       
        </div>

    </div>
</div>

<div class="modal fade" id="postgroupsearch" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content question_modal">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center">Join Virtual Class/Group</h4>
            </div>
            <div class="modal-body clearfix">

                <form class="form-horizontal" method="post" action="{{Route("groups.join")}}" id="group_formjoin">
                    {{ csrf_field() }}
                    <div class="form-group">                                              
                        <label class="col-sm-12 control-label text-left">Enter Group Code</label>
                        <div class="col-sm-12">
                            <input type="text" class="form-control"  name="group_code"  placeholder="Enter Group Code">
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <input type="submit" class="btn btn-primary pull-right" value="Join Group">
                        </div>
                    </div>

                </form>
            </div>                                       
        </div>

    </div>
</div>