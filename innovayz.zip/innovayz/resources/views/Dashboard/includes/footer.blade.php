<script src="{{asset("js/magicsuggest-min.js")}}"></script>
<script type="text/javascript" src="//cdn.tinymce.com/4/tinymce.min.js"></script>
<script src="{{asset("js/validation/formvalidation-min.js")}}"></script>
<script src="{{asset("js/validation/bootstrap.js")}}"></script>

<script>
    tinymce.init({
    selector: "#poster",
    entity_encoding : "raw",
    encoding: "UTF-8",
    menubar: false,
    link_assume_external_targets: true,
    plugins: ["advlist lists link image charmap  anchor"],
    toolbar: " styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist | link image",
    image_dimensions: false,
    setup: function (editor) {
        editor.on('change', function () {
            tinymce.triggerSave();
        });
    }
});
</script>
<script>
    
$(document).on('focusin', function (e) {
    if ($(e.target).closest(".mce-window").length) {
        e.stopImmediatePropagation();
    }
});
$(function (e) {
    $('#avtar_pop').change(function () {
        $('#profpicupdater').submit();
    });
       
    var ms = $('#group_persons1').magicSuggest({
        allowFreeEntries: false,
        valueField: 'value',
        displayField: 'label',
        required: true,
        allowDuplicates: false,
        data: '{{Route("groups.getuser")}}',
        ajaxConfig: {
            xhrFields: {
                withCredentials: true
            }
        }
    });

    $(ms).on('selectionchange', function (e, m) {
        var asd = this.getValue();
        $("#group_persons").val(asd);
    });

    var ms1 = $('#tagcon').magicSuggest({
        allowFreeEntries: false,
        valueField: 'value',
        displayField: 'label',
        required: true,
        allowDuplicates: false,
        data: '{{Route("groups.getuser")}}',
        ajaxConfig: {
            xhrFields: {
                withCredentials: true
            }
        }
    });

    $(ms1).on('selectionchange', function (e, m) {
        var asd = this.getValue();
        $("#tagcon1").val(asd);
    });
    
    $('#group_formjoin').formValidation({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            group_code: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }
        }
    });
    
    
    $('#group_form').formValidation({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            group_name: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }

        }
    });
    
    $('#postform').formValidation({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            subject: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }
        }
    });

});
</script>