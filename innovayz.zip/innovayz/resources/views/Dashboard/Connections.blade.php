@extends('layouts.master')
@section('headscript')
<link rel="stylesheet" href="{{asset("Dashboard/css/dashboard.css")}}">
<link href="{{asset("css/magicsuggest-min.css")}}" rel="stylesheet">
<title>Connections | Innovayz</title>
<style>
    .post_section .panel-body .nav-pills{
        background: #f2f2f2
    }
    .post_section .tab-content{
        padding: 30px 0;
    }
</style>
@stop
@section('content')
@include("Dashboard.includes.upper_panel")
<div class="container-fluid">
    <div class="row">
        <div class="col-md-2">
            @include("Dashboard.includes.sidebar")
        </div>
        <div class="col-md-8 post_section">
            @include("errors.status")
            <div class="panel panel-default">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-12">
                            <h2 class="panel-title">Connections : {{$con_type}}</h2>
                        </div>
                    </div>
                </div>
                <div class="panel-body">

                    <ul class="nav nav-pills nav-justified">
                        <li class="active"><a data-toggle="pill" href="#Followers">Followers</a></li>
                        <li><a data-toggle="pill" href="#Following">Following</a></li>
                    </ul>

                    <div class="tab-content">
                        <div id="Followers" class="tab-pane fade in active">

                            @if(count($userarray))
                            @foreach ($userarray as $poster)
                            <div class="col-md-4 user-box">
                                <div class="well well-sm">
                                    <div class="row">
                                        <div class="col-sm-6 col-md-4">
                                            <img src="{{asset($poster["avatar"])}}" alt="" class="img-rounded img-responsive" />
                                        </div>
                                        <div class="col-sm-6 col-md-8">
                                            <h4><a href="{{Route("profile.index", ["user-id" => $poster["userid"], 'user-name' => $poster["user_name"]])}}">{!! $poster["user_name"] !!}</a></h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                            @else
                            <p>No Connections</p>
                            @endif
                        </div>
                        <div id="Following" class="tab-pane fade">

                            @if(count($folloingarr))
                            @foreach ($folloingarr as $poster)
                            <div class="col-md-4 user-box">
                                <div class="well well-sm">
                                    <div class="row">
                                        <div class="col-sm-6 col-md-4">
                                            <img src="{{asset($poster["avatar"])}}" alt="" class="img-rounded img-responsive" />
                                        </div>
                                        <div class="col-sm-6 col-md-8">
                                            <h4><a href="{{Route("profile.index", ["user-id" => $poster["userid"], 'user-name' => $poster["user_name"]])}}">{!! $poster["user_name"] !!}</a></h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                            @else
                            <p>No Connections</p>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            @include("Dashboard.includes.advertisement")
        </div>
    </div>
</div>
</div>
@stop
@section('jsfiles')
@include("Dashboard.includes.footer")
@stop