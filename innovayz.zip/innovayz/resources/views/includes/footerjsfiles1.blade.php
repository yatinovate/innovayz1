<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js" ></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
<script src="js/jquery.counterup.min.js"></script> 
<script type="text/javascript">
    $(function ()
    {
        $('#carousel-example-generic').carousel({
            pause: true,
            interval: 100000
        });
        $('#testimonial').carousel({
            pause: true,
            interval: 100000
        });
        var $countNumb = $('.countNumb');

        if ($countNumb.length > 0) {
            $countNumb.counterUp({
                delay: 15,
                time: 1700
            });
        }

    });
</script>


<script src="js/main.js"></script> <!-- Gem jQuery -->
@yield('jsfiles1')