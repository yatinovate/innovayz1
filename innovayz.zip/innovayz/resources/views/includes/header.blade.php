<nav class="navbar navbar-default navbar-static-top">
    <div class="navbar-inner">
        <div class="container-fluid">
            <div class="navbar-header">

                <!-- Collapsed Hamburger -->
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                    <span class="sr-only">Toggle Navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <!-- Branding Image -->

                <a class="navbar-brand" href="{{ url('/') }}"><img src="{{asset("images/inno.png")}}" alt="logo"></a>
            </div>

            <div class="collapse navbar-collapse main-nav" id="app-navbar-collapse">
                <!-- Right Side Of Navbar -->
                <ul class="nav navbar-nav navbar-right">
                    <!-- Authentication Links -->
                    @if (Auth::guest())
                    <li><a style="cursor: pointer" class="signup_icon1  cd-signin" dataurl=""><i class="fa fa-user"></i>&nbsp;&nbsp;Sign in</a></li>
                    <li><a style="cursor: pointer" class="signup_icon cd-signup"><i class="fa fa-lock"></i>&nbsp;&nbsp;Sign up</a></li>
                    @else

                    <li class="dropdown">
                        <a id="notificationmenu" class="notifiy_icons" role="button" data-toggle="dropdown" data-target="#" >
                            <span><i class="glyphicon glyphicon-bell"></i> <span class="badge"></span></span>
                        </a>
                        <ul class="dropdown-menu notifications" role="menu" aria-labelledby="notificationmenu">
                            <div class="notifications-wrapper"></div>
                            <div class="text-center">
                                <a style="color: #337ab7" href="{{Route("Dashboard.allnotifyread")}}" class="text-center">See All Notificatons</a>
                            </div>
                        </ul>
                    </li>
                    <?php
                    $coll_elib = count(\Illuminate\Support\Facades\DB::table('laradrop_files')->where('user_id', Auth::user()->id)->whereNotIn('type', ['', 'folder'])->get());
                    ?>
                    <li><a title="E-Library" href="{{route('e-library')}}" class="notifiy_icons"><i class="fa fa-book"></i><span class="badge">{{$coll_elib}}</span></a></li>
                    <?php
                    $msgcount=0;
                    $converstion = \Illuminate\Support\Facades\DB::table('conversations')->where('user_two', Auth::user()->id)->orWhere('user_one', Auth::user()->id)->get();
                    foreach($converstion as $conv){
                        $msgcount=$msgcount+ count(\Illuminate\Support\Facades\DB::table('messages')->where('conversation_id',$conv->id)->where('user_id',"!=", Auth::user()->id)->where('is_seen',0)->get());
                    }
                    ?>
                    <li><a href="{{route('Dashboard.getallmsg')}}" class="notifiy_icons" title="Messages"><i class="fa fa-envelope"></i><span class="badge">{{$msgcount}}</span></a></li>
                    <li class="dropdown">
                        <a href="#" id="userheadername" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                            <img src="{{asset(Auth::user()->avatar)}}" alt="avatar" class="img-responsive">
                            {{ Auth::user()->name }} <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="{{ Route("profile.index", ["user-id" => Auth::user()->id, 'user-name' => Auth::user()->name]) }}">View Profile <span class="glyphicon glyphicon-user pull-right"></span></a></li>
                            <li class="divider"></li>
                            <li><a href="{{ Route('profile.updateprofile')}}">Update Profile <span class="glyphicon glyphicon-cog pull-right"></span></a></li>
                            <li class="divider"></li>
                            <li><a href="{{ route('logout')}}">Sign Out <span class="glyphicon glyphicon-log-out pull-right"></span></a></li>
                        </ul>
                    </li>
                    @endif
                </ul>
                @if (!Auth::guest())

                <form class="navbar-form" role="search" method="get" action="{{Route("search.submit")}}" id="search-form" name="search-form">
                    <div class="form-group" style="display:inline;">
                        <div class="input-group" style="display:table;">
                            <div class="input-group-btn" style="width:1%;">
                                <button type="button" class="btn btn-default dropdown-toggle" id="catcont" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Students <span class="caret text-right"></span></button>
                                <ul class="dropdown-menu searchnav" id="searcbar_categ" dataa_u="{{URL::to("searcher")}}">
                                    <li class="active"><a data_value="students">Student</a></li>
                                    <li><a data_value="teachers">Teacher</a></li>
                                    <li><a data_value="colleges">Institute</a></li>
                                </ul>
                            </div>
                            <input name="q" id="searchbar" type="text" class="form-control typeahead" placeholder="Search your query" autocomplete="off" >
                            <span class="input-group-btn btn_go">
                                <button class="btn btn-primary" type="submit"><i class="fa fa-search"></i></button>
                            </span>
                        </div>
                    </div>
                    <input name="category" id="searchusercategory" type="hidden" >
                    <div id="result">
                            <div class="row"></div>
                        </div>
                </form>
                @endif
            </div>
        </div>
    </div>

</nav>

