<?php
$ads = App\Models\Adblock::all();
?>
<div class="panel-group">
    @foreach($ads as $ad)
    <div class="panel panel-default">
        <div class="panel-body">
            <a href="{{$ad->ad_link}}" target="_blank">
                <img class="img-responsive" src="{{asset("Advertisement/".$ad->ad_image)}}" alt="{{$ad->ad_name}}">
            </a>

        </div>
    </div>
    @endforeach
</div>
