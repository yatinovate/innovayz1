<script src="{{asset("js/jquery.min.js")}}"></script>
<script src="{{asset("js/bootstrap.min.js")}}" ></script>
<script src="{{asset("js/validation/formvalidation-min.js")}}"></script>
<script src="{{asset("js/validation/bootstrap.js")}}"></script>
<script src="{{asset("js/main.js")}}"></script> <!-- Gem jQuery -->
<script>
            $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
        </script>
 
@yield('jsfiles')