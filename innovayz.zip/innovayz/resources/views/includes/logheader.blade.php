<nav class="navbar navbar-default navbar-static-top">
    <div class="container">
        <div class="navbar-header">

            <!-- Collapsed Hamburger -->
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                <span class="sr-only">Toggle Navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

            <!-- Branding Image -->
            <a class="navbar-brand" href="{{ url('/') }}">
                <img src="images/dummy-logo.png" alt='logo'>
            </a>
        </div>

        <div class="collapse navbar-collapse main-nav" id="app-navbar-collapse">
            <!-- Right Side Of Navbar -->
            <div class="nav navbar-nav navbar-left">
                <form class="navbar-form form-inline" role="search" method="get" id="search-form" name="search-form">
                    <div class="input-group">
                        <span class="input-group-addon" ><i class="fa fa-bars"></i></span>
                        <input type="text" class="form-control" placeholder="Username" />
                        <span class="input-group-addon"><i class="fa fa-times-circle"></i></span>
                    </div>
                    
                </form>
            </div>

            <ul class="nav navbar-nav navbar-right">
                <!-- Authentication Links -->
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                        {{ Auth::user()->name }} <span class="caret"></span>
                    </a>

                    <ul class="dropdown-menu" role="menu">
                        <li><a href="{{ route('logout')}}"><i class="fa fa-btn fa-sign-out"></i>Logout</a></li>
                    </ul>
                </li>
                <li><a href="#"><i class="fa fa-file"></i></a></li>
                <li><a href="#"><i class="fa fa-flag"></i></a></li>
                <li><a href="#"><i class="fa fa-commenting-o"></i></a></li>
                
            </ul>




        </div>
    </div>
</nav>

