<meta charset="UTF-8">
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="_token" content="{{ csrf_token() }}">


<link rel="stylesheet" href="{{asset("css/bootstrap.min.css")}}">
<link rel="stylesheet" href="{{asset("css/font-awesome.min.css")}}">
<link rel="stylesheet" href="{{asset("css/reset.css")}}"> <!-- CSS reset -->
<link rel="stylesheet" href="{{asset("css/style.css")}}">
<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />



<script src="{{asset("js/modernizr.js")}}"></script> <!-- Modernizr -->

<link href='https://fonts.googleapis.com/css?family=Archivo+Black|PT+Serif+Caption' rel='stylesheet' type='text/css'>
@yield('headscript')




