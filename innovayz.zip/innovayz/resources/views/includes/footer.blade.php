<div class="sub_foot">
    <div class="container">
        <div class="row">
            <div class="col-md-5 col-xs-6">
                <h3>About Us</h3>
                <p>Innovayz is an education junction and portal. It aims to provide education online for free, to one and all. Our skill tests and 
                    challenges are so designed as to help a student make the most of them, and to discover their hidden academic talents and abilities.
                    Through this website, you can share knowledge among your network.However, Innovayz is not just for students. Teachers and trainers 
                    can create a profile, post challenges and answers, and also host virtual classes for closed distribution of knowledge. 
                    Virtual Classrooms help students and teachers come in close contact both to teach, and to understand.

                </p>
            </div>
            <div class="col-md-3 col-xs-6">
                <h3>Reach Us</h3>
                <ul class="foot_li">
                    <li><a href="{{Route("privacypolicy")}}">Privacy Policy</a></li>
                    <li><a href="{{Route("terms")}}">Terms & Condition</a></li>
                </ul>
            </div>
            <div class="col-md-4 col-xs-12">
                <h3>Follow Us</h3>
                <div class="social-buttons">
                    <a href="#" class="social-button facebook"><i class="fa fa-facebook"></i></a>
                    <a href="#" class="social-button twitter"><i class="fa fa-twitter"></i></a>
                    <a href="#" class="social-button google"><i class="fa fa-google"></i></a>
                    <a href="#" class="social-button linkdin"><i class="fa fa-linkedin"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>
<a href="#" class="scrollup btn-floating">Scroll</a>
