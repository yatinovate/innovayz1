<!DOCTYPE html>
<html>
    <head>
        @include('includes.head')
    </head>
    <body>
        @include('partials.above-navbar-alert')
        <header>
            @include('includes.header')   
        </header>

        <main>
            @yield('content')      
        </main>

        <footer>
            @include('includes.footer')            
        </footer>

        <div class="copyriht">
            <p>udeshya &copy; 2016. All Rights Reserved | Design by <a href="http://www.integer-innovation.in">INTEGER Innovation</a></p>
        </div>

        <div class="cd-user-modal"> <!-- this is the entire modal form, including the background -->
            @include('Auth.signinup')   
        </div>

        @include('includes.footerjsfiles')   
        <script>
            $(function () {
                $.get('{{Route("user.vistorcount")}}', function (data) {
                    
                });
            });
        </script>

        @if (count($errors) > 0)
        @if(session()->has('login'))
        <script>
            $(function () {
                $(".signup_icon1").trigger("click");
            });
        </script>
        @else
        <script>
            $(function () {
                $(".signup_icon").trigger("click");
            });
        </script>


        @endif
        @endif
        @if(session()->has('loginactivationerror'))
        <script>
            $(function () {
                $(".signup_icon1").trigger("click");
            });
        </script>
        @endif
@if(isset($usermail))
        <script>
            $(function () {
                $(".signup_icon").trigger("click");
            });
        </script>
        @endif
        @if(session()->has('forgeterror') || session()->has('forgetsucess'))
        <script>
            $(function () {
                $(".signup_icon").trigger("click");
                $("#forgetformpop").trigger("click");
            });
        </script>
        @endif
        @if(session()->has('signuperror') || session()->has('signupsuccess'))
        <script>
            $(function () {
                $(".signup_icon").trigger("click");
            });
        </script>
        @endif
        @if (Auth::check())
        <script>
            $(function () {
                $.get('{{Route("Dashboard.notify")}}', function (data) {
                    $(".notifications-wrapper").html(data);
                    var noticunt=$(".notifications-wrapper a").length;
                    if(noticunt){
                        $("#notificationmenu .badge").html(noticunt);
                    }else{
                        $("#notificationmenu .badge").html("0");
                        $(".notifications-wrapper").html('<a class="content"><div class="notification-item"><h4 class="item-title">No Notifications Now</h4></div></a>');
                        
                    }
                    
                    
                });
                 
                $("#notificationmenu").click(function(){
                    $.get('{{Route("Dashboard.notifyread")}}', function (data) {
                    $("#notificationmenu .badge").html(data);
                });
                });
            });
        </script>
        @endif

    </body>

</html>