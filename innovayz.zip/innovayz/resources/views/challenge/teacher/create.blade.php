@extends('layouts.master')
@section('headscript')
<link href="{{asset("Challenge/css/teacher/manage.css")}}" rel="stylesheet" type="text/css">
<title>Create Challenges</title>
<style>
    #addquest .modal-header{

        background-color: #337ab7;
        color: #fff;
        padding: 10px;
        font-size: 18px;
        font-family: open sans;
        font-weight: bold;
    }

    #addquest .modal-dialog{
        width: 400px; /* or whatever you wish */
        z-index: 0;
    }
    #addquest span{
        font-size: 10px;
    }
    #addquest .control-label,#addquest label{
        text-align: left !important;
        margin-bottom: 10px !important;
        font-weight: bold;
        text-transform: capitalize;
        font-family: open sans;
        font-size: 12px;
    }
    #upload_csv{
        line-height: 1.9em;
        padding-bottom: 40px;
    }
</style>
@endsection
@section('content')
<div class="manage_challnge">
    <div class="container">
        <div class="row">
            <ol class="breadcrumb breadcrumb-arrow">
                <li><a href="{{Route("Dashboard")}}">Home</a></li>
                <li><a href="{{Route("teach.index")}}">Challenge</a></li>
                <li class="active"><span>Create Challenge</span></li>
            </ol>
        </div>
        <div class="row">
            <div class="col-md-3">
                <div class="sidebar">
                    <div class="questionwraper">
                        <a class="list-group-item  questupdate" href="{{Route("teach.index")}}">All Challenge's<span class="sr-only">(current)</span><span class="pull-right">&nbsp;<i class="fa fa-database"></i></span></a>                        
                        <a class="list-group-item active questupdate" href="{{Route("teach.creator")}}">Create Challenge <span class="sr-only">(current)</span><span class="pull-right">&nbsp;<i class="fa fa-plus-square"></i></span></a> 
                        <a class="list-group-item questupdate" href="{{Route("teach.modify")}}">Manage Challenge<span class="pull-right">&nbsp;<i class="fa fa-wrench"></i></span></a>                        
                    </div>
                </div>
            </div>
            <div class="col-md-9 main">
                <h1 class="page-header">Create Challenge</h1>
                <div class="row">
                    <div class="col-md-10 col-md-offset-1" style="padding: 40px 0">
                        <div class="col-md-4  text-center">
                            <a class="btn btn-info btn-lg" id="createquiz" href="{{Route('teach.createwizard')}}">Create Challenge</a>
                        </div>
                        <div class="col-md-4 text-center">
                            <a class="btn btn-info btn-lg" id="quizupload" data-toggle="modal" data-target="#addquest" href="#">Upload Challenge</a>
                        </div>
                        <div class="col-md-4 text-center">
                            <a class="btn btn-info btn-lg" href="{{asset("Challenge/sample-csv.csv")}}">Download Sample Csv File</a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@stop

@section('jsfiles')

<script>
    $(function () {

        $("#submit_qus").click(function (e) {
            e.preventDefault();
            if ($("#upload_csv").val().toLowerCase().lastIndexOf(".csv") == -1)
            {
                alert("Please upload a file with .csv extension.");
                return false;
            } else {
                var btn = $(this);
                btn.html('checking <i class="fa fa-spinner fa-pulse fa-1x fa-fw"></i><span class="sr-only">Loading...</span>');
                $.ajax({
                    type: "POST",
                    url: '{{Route("teach.csvupload")}}',
                    data: new FormData($("#postanswer")[0]),
                    datatype: 'JSON',
                    async: false,
                    processData: false,
                    contentType: false,
                    success: function (data) {
                        window.location.href = '{{Route("teach.csvcreater")}}';
                    }
                });
            }
        });

    });
</script>
@stop
<div class="modal fade" id="addquest" role="dialog">
    <div class="modal-dialog my_modal">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center">Upload Csv</h4>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" id="postanswer" enctype="multipart/form-data">
                    <div class="form-group">
                        <label class="col-sm-12 control-label">Add Csv (Only CSV files)</label>
                        <div class="col-sm-12">

                            <input type="file" class="form-control" id="upload_csv" name="upload_csv" placeholder="Upload Csv">    
                            <span class="help-block"><strong></strong></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <input type="button" class="btn btn-primary pull-right"  id="submit_qus" value="Upload">
                        </div>
                    </div>
                </form>


            </div>                                       
        </div>
    </div>
</div>