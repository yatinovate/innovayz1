@extends('layouts.master')
@section('headscript')
<link href="{{asset("Challenge/css/teacher/manage.css")}}" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="{{asset("Challenge/css/viewchallenge.css")}}">
<title>Manage Challenges</title>
<style>
    #skillgetter{
        padding: 30px 0;
    }
</style>
@endsection
@section('content')


<div class="manage_challnge">
    <div class="container">
        <div class="row">
            <ol class="breadcrumb breadcrumb-arrow">
                <li><a href="{{Route("Dashboard")}}">Home</a></li>
                <li><a href="{{Route("teach.index")}}">Challenge</a></li>
                <li class="active"><span>All Challenge</span></li>
            </ol>
        </div>
        <div class="row">
            <div class="col-md-3">
                <div class="sidebar">
                    <div class="questionwraper">
                        <a class="list-group-item active questupdate" href="{{Route("teach.index")}}">All Challenge's<span class="sr-only">(current)</span><span class="pull-right">&nbsp;<i class="fa fa-database"></i></span></a>                        
                        <a class="list-group-item questupdate" href="{{Route("teach.creator")}}">Create Challenge <span class="sr-only">(current)</span><span class="pull-right">&nbsp;<i class="fa fa-plus-square"></i></span></a> 
                        <a class="list-group-item questupdate" href="{{Route("teach.modify")}}">Manage Challenge<span class="pull-right">&nbsp;<i class="fa fa-wrench"></i></span></a>    
                    </div>
                </div>
            </div>
            <div class="col-md-9 main">
                <h1 class="page-header">All Challenges</h1>
                <div class="row" id="skillgetter">
                </div>
            </div>
        </div>
    </div>

    @stop
    @section('jsfiles')
    <script>
        $(function () {

            $.get('{{Route("teach.getChallenge")}}', function (data) {
                $("#skillgetter").html(data);
            });

        });
    </script>

    @endsection


