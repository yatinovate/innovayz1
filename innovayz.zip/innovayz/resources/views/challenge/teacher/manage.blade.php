@extends('layouts.master')
@section('headscript')

<link href="{{asset("Challenge/css/teacher/manage.css")}}" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">
<link href="{{asset("css/magicsuggest-min.css")}}" rel="stylesheet">
<title>Manage Challenges</title>
<style>
    .table thead{
        background: #337ab7;
        color: #fff;
    }
    .table thead a{
        color: #fff;
    }
    .table tr td a{
        color: #000;
    }
    #addquest .modal-header{

        background-color: #337ab7;
        color: #fff;
        padding: 10px;
        font-size: 18px;
        font-family: open sans;
        font-weight: bold;
    }

    #addquest .modal-dialog{
        width: 400px; /* or whatever you wish */
        z-index: 0;
    }
    #addquest span{
        font-size: 10px;
    }
    #addquest .control-label,#addquest label{
        text-align: left !important;
        margin-bottom: 10px !important;
        font-weight: bold;
        text-transform: capitalize;
        font-family: open sans;
        font-size: 12px;
    }
</style>
@endsection
@section('content')
<div class="manage_challnge">
    <div class="container">
        <div class="row">
            <ol class="breadcrumb breadcrumb-arrow">
                <li><a href="{{Route("Dashboard")}}">Home</a></li>
                <li><a href="{{Route("teach.index")}}">Challenge</a></li>
                <li class="active"><span>Manage</span></li>
            </ol>
        </div>
        <div class="row">
            <div class="main">
                @include("errors.status")
                <h1 class="page-header">Manage Challenge</h1>
                <div class="row">
                    <table class="table table-bordered table-responsive table-hover table-striped" id="dtable">
                        <thead>
                            <tr>
                                <th scope="col">S.No</th>
                                <th scope="col">Skill Test</th>
                                <th scope="col">Preview</th>
                                <th scope="col"><a>Publish Status</a></th>
                                <th scope="col"><a>Archive Status</a></th>
                                <th scope="col"><a>Add Question</a></th>
                                <th scope="col"><a>Edit</a></th>
                                <th scope="col"><a>Delete</a></th>

                            </tr>
                        </thead>
                        <tbody><?php $cout = 1; ?>
                            @foreach($skills as $test)
                            <tr>
                                <td>{{$cout}}</td>
                                <?php $cout++ ?>
                                <td>{{$test->skill_test_name}}</td>  
                                <td><a href="{{Route("teach.preview",["skill_id"=>$test->id])}}" target="_blank">Preview</a></td>
                                @if($test->publish==0)
                                <td><a href="javascript:;" class="published" data-id="{{$test->id}}" data-toggle="modal" data-target="#poptest">Publish</a></td>
                                @else
                                <td><a href="javascript:;" class="unpublished" data-id="{{$test->id}}">Unpublish</a></td>
                                @endif
                                @if($test->publish==0)
                                @if($test->archive==0)
                                <td><a href="javascript:;" class="archive" data-id="{{$test->id}}">Archive</a></td>
                                @else
                                <td><a href="javascript:;" class="archive" data-id="{{$test->id}}">Unarchive</a></td>
                                @endif
                                @else
                                @if($test->archive==0)
                                <td><a >Archive</a></td>
                                @else
                                <td><a >Unarchive</a></td>
                                @endif
                                @endif 



                                @if($test->publish==0)
                                <td><a href="javascript:;" class="addque" data-id="{{$test->id}}" data-toggle="modal" data-target="#addquest">Add</a></td>
                                @else
                                <td><a  class="disabled" >Add</a></td>
                                @endif

                                @if($test->publish==0)
                                <td><a href="{{Route("teach.editQuestion", ["skillid" =>$test->id])}}">Edit</a></td>
                                @else
                                <td><a  class="disabled">Edit</a></td>
                                @endif
                                @if($test->publish==0)
                                <td><a href="{{Route("teach.delete", ["skill-id" =>$test->id])}}">Delete</a></td>
                                @else
                                <td><a  class="disabled">Delete</a></td>
                                @endif
                            </tr>
                            @endforeach
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="poptest" role="dialog">
            <div class="modal-dialog my_modal">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title text-center">Challenge Option</h4>
                    </div>
                    <div class="modal-body">
                        <form class="form-horizontal" method="post" id="postanswer" action="{{Route("teach.sendto")}}">
                            {{csrf_field()}}
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-5 col-md-offset-1">
                                        <input type="radio" name="decsion" class="desc1" value="public" checked="">&nbsp;&nbsp;Send Publicly
                                    </div>
                                    <div class="col-md-5">
                                        <input type="radio" name="decsion" class="desc1" value="group">&nbsp;&nbsp;Send to Group
                                    </div>
                                </div>
                            </div>
                            <div class="grps" style="display: none;">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <input type="text" id="groupa" name="groupa" class="form-control" placeholder="Group Name" >
                                        <input type="hidden" id="groupa1" name="groupa1" >
                                    </div>
                                </div>
                            </div>

                            <input type="hidden"  name="skill-id" id="publishskillid" >
                            <div class="form-group">
                                <div class="col-sm-offset-2 col-sm-10">
                                    <input type="submit" class="btn btn-primary pull-right" id="submit_qus" value="Send">
                                </div>
                            </div>
                        </form>


                    </div>                                       
                </div>
            </div>
        </div>
@stop
@section('jsfiles')
 <script src="<?php echo asset('js/magicsuggest-min.js'); ?>"></script>
<script>
    $(function () {
            $(document).on("click", ".published", function (e) {

            e.preventDefault();

            var _self = $(this);

            var myBookId = _self.data('id');
            $("#publishskillid").val(myBookId);
        });

var ms = $('#groupa').magicSuggest({
        allowFreeEntries: false,
        maxSelection: 1,
        required: true,
        valueField: 'value',
        displayField: 'label',
        data: '{{Route("teach.findgroup")}}',
        ajaxConfig: {
            xhrFields: {
                withCredentials: true
            }
        }
    });
    $(ms).on('selectionchange', function (e, m) {
        var asd = this.getValue();
        $('#postanswer').find('[name="groupa1"]').val(asd).end().formValidation('revalidateField', 'groupa1');
    });
    $('#postanswer').formValidation({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            decsion: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }, groupa1: {
                enabled: false,
                excluded: false,
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }
        }
    }).on('change', '[name="decsion"]', function (e) {        
        var evntval = $('#postanswer').find('[name="decsion"]:checked').val();
        if (evntval == 'group') {
            $(".grps").show();
            $('#postanswer').data('formValidation').enableFieldValidators('groupa1', true);
        } else {
            $(".grps").hide();
            $('#postanswer').data('formValidation').enableFieldValidators('groupa1', false);
        }
    });

        $(".unpublished").click(function () {
            var btn = $(this);
            var skillid = btn.attr("data-id");
            $.get('{{Route("teach.publish")}}', {skillid: skillid})
                    .done(function (data) {
                        btn.html(data);
                        window.location.reload(true);
                    });
        });

        $(".archive").click(function () {
            var btn = $(this);
            var skillid = btn.attr("data-id");
            $.get('{{Route("teach.archive")}}', {skillid: skillid})
                    .done(function (data) {
                        btn.html(data);
                        window.location.reload(true);
                    });

        });
        
        $('#postanswer1').formValidation({
            framework: 'bootstrap',
            icon: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: { add_question: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }, regexp: {
                            message: 'Invalid Input',
                            regexp: /^[0-9]+$/
                        }
                    }
                }
            }
        });


        $(document).on("click", ".addque", function (e) {

            e.preventDefault();

            var _self = $(this);

            var myBookId = _self.data('id');
            $("#skillidq").val(myBookId);
        });


   
    });

</script>
@stop
<div class="modal fade" id="addquest" role="dialog">
    <div class="modal-dialog my_modal">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center">Add Questions</h4>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" id="postanswer1" method="post" action="{{Route("teach.addQuestion")}}">
                    {{csrf_field()}}
                    <div class="form-group">
                        <label class="col-sm-12 control-label">Add Questions</label>
                        <div class="col-sm-12">
                            <input type="text" class="form-control" id="add_question" name="add_question" placeholder="Enter no of Questions to add">
                        </div>
                    </div>

                    <input type="hidden" value="" name="skillidq" id="skillidq">
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <input type="submit" class="btn btn-primary pull-right" id="submit_qus" value="Save">
                        </div>
                    </div>
                </form>

            </div>                                       
        </div>
    </div>
</div>