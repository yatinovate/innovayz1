<form class="form-horizontal" id="multi_cho" method="post" action="<?php echo Route("teach.savemultichoiceupdate"); ?>">
    <?php echo csrf_field(); ?>

    <div class="row">
        <div class="form-group">            
            <label class="col-md-12 control-label">Question:</label>     
            <div class="col-md-12">
                <textarea class="form-control" rows="6" name="question" id="question" placeholder="Enter question"><?php echo $quesfinder->question; ?></textarea>                                                
            </div>
        </div>

        <div class="col-md-12">
            <div class="form-group">
                <label class="col-md-2 control-label">Answers:</label>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-group">
                <label class="col-md-2 control-label">A.</label>
                <div class="col-md-10">
                    <input type="text" class="form-control" name="ans_a" value="<?php echo $quesfinder->ans_a; ?>" id="ans_a" placeholder="answer A">                
                </div>
            </div>
        </div>


        <div class="col-md-6">
            <div class="form-group">
                <label class="col-md-2 control-label">B.</label>
                <div class="col-md-10">
                    <input type="text" class="form-control" name="ans_b" value="<?php echo $quesfinder->ans_b; ?>" id="ans_b" placeholder="answer B">                    
                </div>
            </div>
        </div>


        <div class="col-md-6">
            <div class="form-group">
                <label class="col-md-2 control-label">C.</label>
                <div class="col-md-10">
                    <input type="text" class="form-control" name="ans_c" value="<?php echo $quesfinder->ans_c; ?>" id="ans_c" placeholder="answer C">                
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-group">
                <label class="col-md-2 control-label">D.</label>
                <div class="col-md-10">
                    <input type="text" class="form-control" name="ans_d" value="<?php echo $quesfinder->ans_d; ?>" id="ans_d" placeholder="answer D">                
                </div>
            </div>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label class="col-md-4 control-label">Correct Answer:</label>
                <div class="col-md-8">
                    <label class="checkbox-inline"><input type="checkbox" name="mcq[]" id="mcq" value="ans_a">A</label>
                    <label class="checkbox-inline"><input type="checkbox" name="mcq[]" id="mcq1" value="ans_b">B</label>
                    <label class="checkbox-inline"><input type="checkbox" name="mcq[]" id="mcq2" value="ans_c">C</label>
                    <label class="checkbox-inline"><input type="checkbox" name="mcq[]" id="mcq3" value="ans_d">D</label>                    
                    <input type="hidden" name="correct_ans" id="correct_ans" value="<?php echo $quesfinder->correct_ans; ?>">
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label class="col-md-3 control-label">POINT</label>
                <div class="col-md-9">
                    <input type="text" class="form-control" value="<?php echo $quesfinder->points; ?>" name="points" id="points" placeholder="Enter Points">
                    <input type="hidden"  name="skill_id" id="skill_id_geter" value="<?php echo $quesfinder->challenge_id; ?>" >
                    <input type="hidden" value="<?php echo $quesfinder->id; ?>" name="quesid" id="quesid">
                </div>
            </div>
        </div>

        <div class="col-md-12">  
            <div class="col-md-2 col-md-offset-8">
                <div class="form-group">
                    <button type="button" style="display: none" class="btn btn-info btn-lg pull-right" id="preview" >Preview</button>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <button type="submit" class="btn btn-info btn-lg pull-right" id="save_ques" >Save</button>
                </div>
            </div>

        </div>
    </div>    

</form>
<script>
    var anskey = '<?php echo $quesfinder->correct_ans; ?>';
    var ansvalkes = anskey.split(",");
    $.each(ansvalkes, function (key, value) {
        var fffasd = $('#ans_a[value="' + value + '"],#ans_b[value="' + value + '"],#ans_c[value="' + value + '"],#ans_d[value="' + value + '"]').attr("id");
        $("#mcq[value=" + fffasd + "],#mcq1[value=" + fffasd + "],#mcq2[value=" + fffasd + "],#mcq3[value=" + fffasd + "]").attr('checked', 'checked');

    });
</script>
<script>
    $(function () {
        $('#multi_cho').formValidation({
            framework: 'bootstrap',
            icon: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                question: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }, ans_a: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }, ans_b: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }, ans_c: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }, ans_d: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }, corctgetter: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }, points: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }, regexp: {
                            message: 'Invalid Input',
                            regexp: /^[0-9\s\-()+\.]+$/
                        }
                    }
                }, 'mcq[]': {
                    validators: {
                        choice: {
                            min: 1,
                            max: 4,
                            message: 'Please choose'
                        }
                    }
                }
            }
        });

        $("#mcq,#mcq1,#mcq2,#mcq3").click(function () {
            var form = $(this);
            var selectedValue = form.val();
            var chd = $("#" + selectedValue).val();
            var oldval = $("#correct_ans").val();
            console.log(oldval);
            if (form.is(':checked')) {
                var newval = oldval + "," + chd;
                $("#correct_ans").val(newval);
            } else {
                var newval = oldval.replace(',' + chd, "");
                $("#correct_ans").val(newval);
            }

        });

    });
</script>
