<form class="form-horizontal" id="multi_opt" method="post" action="<?php echo Route("teach.savemulti"); ?>">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="form-group">            
            <label class="col-md-12 control-label">Question:</label>     
            <div class="col-md-12">
                <textarea class="form-control" rows="6" name="question" id="question" placeholder="Enter question"></textarea>                                                
            </div>
        </div>

        <div class="col-md-12">
            <div class="form-group">
                <label class="col-md-2 control-label">Answers:</label>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-group">
                <label class="col-md-2 control-label">A.</label>
                <div class="col-md-10">
                    <input type="text" class="form-control" name="ans_a" id="ans_a" placeholder="answer A">                
                </div>
            </div>
        </div>


        <div class="col-md-6">
            <div class="form-group">
                <label class="col-md-2 control-label">B.</label>
                <div class="col-md-10">
                    <input type="text" class="form-control" name="ans_b" id="ans_b" placeholder="answer B">                    
                </div>
            </div>
        </div>


        <div class="col-md-6">
            <div class="form-group">
                <label class="col-md-2 control-label">C.</label>
                <div class="col-md-10">
                    <input type="text" class="form-control" name="ans_c" id="ans_c" placeholder="answer C">                
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-group">
                <label class="col-md-2 control-label">D.</label>
                <div class="col-md-10">
                    <input type="text" class="form-control" name="ans_d" id="ans_d" placeholder="answer D">                
                </div>
            </div>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label class="col-md-4 control-label">Correct Answer:</label>
                <div class="col-md-6">
                    <select class="form-control" name="corctgetter" id="corctgetter">
                        <option value="">Select answer</option>
                        <option value="ans_a">A</option>
                        <option value="ans_b">B</option>
                        <option value="ans_c">C</option>
                        <option value="ans_d">D</option>
                    </select>
                    <input type="hidden" value="ans_a" name="correct_ans" id="correct_ans">
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label class="col-md-3 control-label">POINT</label>
                <div class="col-md-9">
                    <input type="text" class="form-control" name="points" id="points" placeholder="Enter Points">
                    <input type="hidden"  name="skill_id" id="skill_id_geter" value="<?php echo $challid; ?>">
                    
                </div>
            </div>
        </div>

        <div class="col-md-12">  
            <div class="col-md-2 col-md-offset-8">
                <div class="form-group">
                    <button type="button" style="display: none" class="btn btn-info btn-lg pull-right" id="preview" >Preview</button>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <button type="submit" class="btn btn-info btn-lg pull-right" id="save_ques" >Next</button>
                </div>
            </div>

        </div>
    </div>


</form>

<script>
    $(function () {
        
        $('#multi_opt').formValidation({
            framework: 'bootstrap',
            icon: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                question: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }, ans_a: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }, ans_b: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }, ans_c: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }, ans_d: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }, corctgetter: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }, points: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        },regexp: {
                        message: 'Invalid Input',
                        regexp: /^[0-9\s\-()+\.]+$/
                    }
                    }
                }
            }
        });

        $("#corctgetter").change(function () {
            var form = $(this);
            form.parent().parent().removeClass('has-error');
            var selectedValue = $(this).val();
            var vala = $('#' + selectedValue).val();
            $("#correct_ans").val(vala);
        });


    });
</script>