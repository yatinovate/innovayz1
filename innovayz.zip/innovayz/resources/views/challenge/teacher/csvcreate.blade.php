@extends('layouts.master')
@section('headscript')
<link href="{{asset("Challenge/css/teacher/manage.css")}}" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">
<link href="{{asset("css/magicsuggest-min.css")}}" rel="stylesheet">
<title>Create Challenge | Manage Challenges</title>
<style>

</style>
@endsection
@section('content')
<div class="manage_challnge">
    <div class="container">
        <div class="row">
            <ol class="breadcrumb breadcrumb-arrow">
                <li><a href="{{Route("Dashboard")}}">Home</a></li>
                <li><a href="{{Route("teach.index")}}">Challenge</a></li>
                <li class="active"><span>Create Challenge</span></li>
            </ol>
        </div>
        <div class="row">
            <div class="col-md-3">
                <div class="sidebar">
                    <div class="questionwraper">
                        <a class="list-group-item  questupdate" href="{{Route("teach.index")}}">All Challenge's<span class="sr-only">(current)</span><span class="pull-right">&nbsp;<i class="fa fa-database"></i></span></a>                        
                        <a class="list-group-item active questupdate" href="{{Route("teach.creator")}}">Create Challenge <span class="sr-only">(current)</span><span class="pull-right">&nbsp;<i class="fa fa-plus-square"></i></span></a> 
                        <a class="list-group-item questupdate" href="{{Route("teach.modify")}}">Manage Challenge<span class="pull-right">&nbsp;<i class="fa fa-wrench"></i></span></a>                        
                    </div>
                </div>
            </div>
            <div class="col-md-9 main">
                <h1 class="page-header">Create Challenge</h1>
                <div class="row">
                    <div class="col-md-10 col-md-offset-1">
                        @if (session('issues'))
                        <div class="alert alert-danger">
                            {{ session('issues') }}
                        </div>
                        @endif
                        <form class="form-horizontal" id="createtest_form" method="post" action="{{Route("teach.savecsvcreater")}}">
                            {{ csrf_field() }}

                            <div class="col-sm-12">
                                <div class="form-group">                                              
                                    <label class="col-sm-12 control-label">Challenge Name</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" name="skill_name" id="skill_name" placeholder="Challenge Title">
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">                                              
                                    <label class="col-sm-12 control-label">Category</label>
                                    <div class="col-sm-12">
                                        <select class="form-control" id="skill_cat" name="skill_cat">
                                            <option value="">Select Category</option>
                                            <?php foreach ($qual as $al): ?>
                                                <option value="<?php echo $al->id; ?>"><?php echo $al->qulaification; ?></option>
                                            <?php endforeach; ?>
                                        </select>                                        
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="col-sm-12 control-label">Subject</label>
                                    <div class="col-sm-12">                                       
                                        <input type="text" class="form-control" name="skill_sub" id="skill_sub" placeholder="Subject">
                                        <input type="hidden" id="skill_sub1" name="skill_sub1" >
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="col-sm-12 control-label">Description</label>
                                    <div class="col-sm-12">
                                        <textarea class="form-control" name="skill_desc" id="skill_desc" placeholder="Enter Description"></textarea>                                                                  
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-3">
                                <div class="form-group">
                                    <label class="col-sm-12 control-label">Start date</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" name="skill_start_date" id="skill_start_date" placeholder="Start date">                                        
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-3">
                                <div class="form-group">
                                    <label class="col-sm-12 control-label">End date</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" name="skill_end_date" id="skill_end_date" placeholder="End date">                                        
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="form-group">
                                    <label class="col-sm-12 control-label">Total Question</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" readonly="" name="skill_qno" id="skill_qno" placeholder="Number" value="{{$qcount}}">                                        
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-3">
                                <div class="form-group">
                                    <label class="col-sm-12 control-label">Duration</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" name="skill_time" id="skill_time" placeholder="in minutes">                                        
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" value="<?php echo csrf_token(); ?>" name="_token" id="csrftoken">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <input type="submit" class="btn btn-primary btn-lg pull-right" id="next" value="Next">
                                    </div>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@stop

@section('jsfiles')

<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<script src="<?php echo asset('js/magicsuggest-min.js'); ?>"></script>
<script>
$(function () {
    $('#createtest_form').formValidation({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            skill_name: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            },
            skill_cat: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }, skill_sub1: {
                excluded: false,
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }, skill_desc: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }, skill_start_date: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }, skill_end_date: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }, skill_qno: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    },
                    regexp: {
                        message: 'Invalid Input',
                        regexp: /^[0-9\s\-()+\.]+$/
                    }
                }
            }, skill_time: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    },
                    regexp: {
                        message: 'Invalid Input',
                        regexp: /^[0-9\s\-()+\.]+$/
                    }
                }
            }

        }
    });
    var ms = $('#skill_sub').magicSuggest({
        allowFreeEntries: false,
        maxSelection: 1,
        required: true,
        data: '{{Route("profile.areaintrest")}}',
        ajaxConfig: {
            xhrFields: {
                withCredentials: true
            }
        }
    });
    $(ms).on('selectionchange', function (e, m) {
        var asd = this.getValue();
        $('#createtest_form')
                .find('[name="skill_sub1"]')
                .val(asd)
                .end()
                // Revalidate it
                .formValidation('revalidateField', 'skill_sub1');
    });
    var dateToday = new Date();
    $("#skill_start_date").datepicker({
        numberOfMonths: 1,
        showButtonPanel: true,
        minDate: dateToday,
        onSelect: function (dateText, inst) {
            $("#skill_end_date").datepicker("option", "minDate",
                    $("#skill_start_date").datepicker("getDate"));
            $('#createtest_form').find('[name="skill_start_date"]').val(dateText).end().formValidation('revalidateField', 'skill_start_date');
        }
    });
    $("#skill_end_date").datepicker({
        numberOfMonths: 1,
        showButtonPanel: true,
        onSelect: function (dateText, inst) {
            $('#createtest_form').find('[name="skill_end_date"]').val(dateText).end().formValidation('revalidateField', 'skill_end_date');
        }
    });

});
</script>



@endsection