@extends('layouts.master')

@section('headscript')
<title>{{$chal->skill_test_name}} | Leaderboard</title>
<link rel="stylesheet" href="{{asset("css/skilltest.css")}}">
<meta name="_token" content="{{ csrf_token() }}">
<style>
    
.skill_test{
    margin: 80px;
    background: #fff;
    padding-bottom: 40px;
}
.skill_test .alert{
    margin: 20px;
}
.chl_lbl{
    font-weight: bold;
    margin-bottom: 20px;
}
label{
    margin-bottom: 20px;
}
</style>
@endsection
@section('content')

<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="skill_test">
                <div class="skill_test_head">
                    <h2>Challenge : {{$chal->skill_test_name}}</h1>
                </div>
                <br>
                <div class="col-md-12">
                    <div class="col-md-6">
                        <label>Category : </label>
                        <span class="chl_lbl">{{ \App\Models\User\QualificationList::find($chal->category)->qulaification}}</span>
                    </div>
                    <div class="col-md-6">
                        <label>Subject : </label>
                        <span class="chl_lbl">{{\App\Models\User\AreaIntrest::find($chal->subject)->area_intrest}}</span>
                    </div>
                    <div class="col-md-12">
                        <label>Description : </label>
                        <span class="chl_lbl">{{$chal->description}}</span>
                    </div>
                    <div class="col-md-6">
                        <label>Start Date : </label>
                        <span class="chl_lbl">{{$chal->start_date}}</span>
                    </div>
                    <div class="col-md-6">
                        <label>End Date : </label>
                        <span class="chl_lbl">{{$chal->end_date}}</span>
                    </div>
                    <div class="col-md-6">
                        <label>Total Questions : </label>
                        <span class="chl_lbl">{{$chal->questn_count}}</span>
                    </div>
                    <div class="col-md-6">
                        <label>Total Time : </label>
                        <span class="chl_lbl">{{$chal->duration}}</span>
                    </div>
                    
                    
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>



@endsection


@section('jsfiles')



@endsection


