@extends('layouts.master')

@section('headscript')
<title>{{$chllangenamae}} | Leaderboard</title>
<link rel="stylesheet" href="{{asset("css/skilltest.css")}}">
<style>

    .skill_test{
        margin: 80px;
        background: #fff;
    }
    .skill_test table thead{
        border: 1px solid #000;
    }
    .skill_test table th{
        font-weight: 600;
    }
    .skill_test .alert{
        margin: 20px;
    }
    .breadcrumb li a{
        color: #000;
        text-decoration: none;
    }
    .table_wraper{
        padding: 40px;
    }

</style>
@endsection
@section('content')

<div class="container"><br>
    <div class="row">
        <ol class="breadcrumb breadcrumb-arrow">
            <li><a href="{{Route("Dashboard")}}">Dashboard</a></li>
            @if (Auth::user()->user_type=="teachers")
            <li><a href="{{Route("teach.index")}}">Challenge</a></li>
            @elseif (Auth::user()->user_type=="students")
            <li><a href="{{Route("student.geterpage")}}">Challenge</a></li>
            @endif
            <li class="active">LeaderBoard</li>
        </ol>
    </div>
    
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="skill_test">
                <div class="skill_test_head">
                    <h2>Leaderboard : {{$chllangenamae}}</h1>
                </div>

                <br>

                @if($leader->count())
                <div class="table_wraper">
                    <table class="table table-bordered table-responsive">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Marks</th>
                            <th>Rank</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $ix=0;   ?>
                        @foreach($leader as $lead)
                        <tr>
                            <td>{{ \App\Models\User::find($lead->user_id)->name}}</td>
                            <td>{{$lead->points}}</td>
                            <td>{{++$ix}}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                </div>
                
                @elseif (Auth::user()->user_type=="teachers")
                <div class="alert alert-success">
                    "No Student participated yet!!"
                </div>
                @else
                <div class="alert alert-success">
                    "Be the first to appear in the Challange and let other chase you!!" <a href="{{Route("student.geterpage")}}">click here</a>
                </div>
                @endif
                <div class="clearfix"></div>

            </div>
        </div>
    </div>
</div>



@endsection


@section('jsfiles')



@endsection


