@extends('layouts.master')

@section('headscript')
<link rel="stylesheet" href="{{asset("Challenge/css/viewchallenge.css")}}">
<title>Challenge | Instruction Page | Innovayz</title>
@endsection
@section('content')

<div class="instruction_wrap">
    <div class="container"> 
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="instrcu">
                    <h2 class="text-left">Instructions</h2> <hr>  
                    <div class="instruction_steps">
                        <ol>
                            <li>Timer will start once the Challenge will get started.</li>
                            <li>Clicking on Proceed button implies that you accept our Terms and Conditions.</li>
                            <li>Next button to Proceed for Next question.</li>
                            <li>Previous button to reach to previous question to change any answer before Submitting.</li>
                            <li>User can also switch to any of the question in the test by clicking the question no displaying in the left side.</li>
                            <li>Done button will submit the test and will display the results on the screen.</li>
                            <li>Once timer is complete it will auto submit the test and display the results.</li>
                            <li>Test Details : </li>
                        </ol>
                        <br>
                        <table class="table table-bordered table-hover table-responsive">
                            <thead>
                                <tr>
                                    <th>Total No. of Questions</th>
                                    <th>Maximum Marks</th>
                                    <th>Total Time (Minutes)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>{{$challenge->questn_count}}</td>
                                    <td>{{$totalpoints}}</td>
                                    <td>{{$challenge->duration}}</td>
                                </tr>
                            </tbody>
                        </table>
                        <p>
                            <b>Description : </b>{{$challenge->description}}
                        </p>
                        <hr>
                        <div class="text-center">
                            <a href="{{Route("student.startquiz",["challenge-id"=>$challenge->id,"challenge-name"=>$challenge->skill_test_name])}}" class="btn btn-info btn-lg prcbtn btn-lg">Proceed</a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>


@endsection


