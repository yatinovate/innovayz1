@extends('layouts.master')

@section('headscript')
<title>Challenge | {{$quiz->skill_test_name}} | Innovayz</title>
<link rel="stylesheet" href="{{asset('css/skilltest.css')}}">
@endsection
@section('content')

<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="skill_test">
                <div class="skill_test_head">
                    <div class="row">
                        <div class="col-md-6">
                            <h2>{{$quiz->skill_test_name}} </h2>
                        </div>
                        <div class="col-md-3">
                            <p id="timer">Timer : <span></span></p>
                        </div>
                        <div class="col-md-3 text-right">
                            <a href="#" id="quiz_done" class="btn btn-danger">Done</a>
                        </div>
                    </div>
                </div>

                <div class="row nopadd">
                    <div class="col-md-3">
                        <div class="question_wraper">
                            <nav class="nav-sidebar">
                                <ul class="nav tabs">
                                    @for($ix=1;$ix<=$quiz->questn_count;$ix++)
                                    <li><a data-toggle="tab" href="#ques{{$ix}}">Question {{$ix}}</a></li>

                                    @endfor                              
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="col-md-9">

                        <div class="skill_wrapper">
                            <form id="quizform" action="{{Route("student.resultpage")}}" method="post" class="form-horizontal">
                                <div class="tab-content">

                                    @foreach($qinfo as $aed)
                                    <?php
                                    $mycalss = 'App\\Models\\Challenge\\' . $aed->qtype;
                                    $asd = $mycalss::find($aed->actual_question_id);
                                    ?>
                                    @if($aed->qtype=="TrueFalseSkillCh")
                                    <div id="ques{{$aed->question_id}}" class="tab-pane fade">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <label class="control-label question_label">{{$asd->question}}</label>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <input type="radio" name="q{{$aed->question_id}}" value="TRUE">&nbsp;&nbsp;
                                                    True
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <input type="radio" name="q{{$aed->question_id}}" value="FALSE">&nbsp;&nbsp;
                                                    False
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    @elseif($aed->qtype=="MultiChoiceCh")
                                    <div id="ques{{$aed->question_id}}" class="tab-pane fade">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <label class="control-label question_label">{{$asd->question}}</label>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <input type="checkbox" name="q{{$aed->question_id}}[]" value="{{$asd->ans_a}}">&nbsp;&nbsp;
                                                    {{$asd->ans_a}}
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <input type="checkbox" name="q{{$aed->question_id}}[]" value="{{$asd->ans_b}}">&nbsp;&nbsp;
                                                    {{$asd->ans_b}}
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <input type="checkbox" name="q{{$aed->question_id}}[]" value="{{$asd->ans_c}}">&nbsp;&nbsp;
                                                    {{$asd->ans_c}}
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <input type="checkbox" name="q{{$aed->question_id}}[]" value="{{$asd->ans_d}}">&nbsp;&nbsp;
                                                    {{$asd->ans_d}}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @else
                                    <div id="ques{{$aed->question_id}}" class="tab-pane fade">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <label class="control-label question_label">{{$asd->question}}</label>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <input type="radio" name="q{{$aed->question_id}}" value="{{$asd->ans_a}}">&nbsp;&nbsp;
                                                    {{$asd->ans_a}}
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <input type="radio" name="q{{$aed->question_id}}" value="{{$asd->ans_b}}">&nbsp;&nbsp;
                                                    {{$asd->ans_b}}
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <input type="radio" name="q{{$aed->question_id}}" value="{{$asd->ans_c}}">&nbsp;&nbsp;
                                                    {{$asd->ans_c}}
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <input type="radio" name="q{{$aed->question_id}}" value="{{$asd->ans_d}}">&nbsp;&nbsp;
                                                    {{$asd->ans_d}}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @endif
                                    @endforeach

                                    <input type="hidden" value="{{$quiz->id}}" name="skillid">
                                    <input type="hidden" value="<?php echo csrf_token(); ?>" name="_token" id="csrftoken">

                                </div> </form>
                        </div>
                        <div class="skill_butn_wrap">
                            <div class="row">
                                <div class="col-md-2 col-md-offset-8">
                                    <div class="form-group">
                                        <button type="button" style="display: none" class="btn btn-info btn-lg pull-right" id="prev" >Previous</button>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <input type="hidden" id="trigertime">
                                        <button type="button" class="btn btn-info btn-lg pull-right" id="next_ques" >Next</button>
                                        <a href="#" id="quiz_done1" class="btn btn-danger btn-lg" style="display: none">Done</a>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>

            </div>
        </div>
    </div>
</div>



@endsection
@section('jsfiles')
<script>
$(document).ready(function () {
    function disableBack() {
        window.history.forward()
    }

    window.onload = disableBack();
    window.onpageshow = function (evt) {
        if (evt.persisted)
            disableBack()
    }
});
</script>
<script>
    $(function () {

        $(".skill_wrapper .tab-content #ques1").addClass("in active ");
        $(".question_wraper ul li:first-child").addClass("in active ");
        $(".question_wraper ul li").click(function () {
            var qindex = $(this);
            $("#next_ques").show();
            $("#quiz_done1").hide();
            $('#prev').css('display', 'block');
            if (qindex.is(':last-child')) {
                $("#next_ques").hide();
                $("#quiz_done1").show();
                $('#prev').css('display', 'block');
            } else if (qindex.is(':first-child')) {
                $('#prev').css('display', 'none');
            }
        });

        $("#next_ques").click(function ()
        {
            var qno = $(".skill_wrapper .active").attr("id");
            qno = parseInt(qno.replace('ques', ''));
            if (qno >= 1) {
                $('#prev').css('display', 'block');
            }
            var qnnew = parseInt(qno) + 1;
            $(".question_wraper a[href='#ques" + qnnew + "']").trigger('click');
        });
        $("#trigertime").one("click", function () {
            timedCount();
        });
        $("#prev").click(function ()
        {
            var qno = $(".skill_wrapper .active").attr("id");
            qno = parseInt(qno.replace('ques', ''));
            var qnnew = parseInt(qno) - 1;
            if (qnnew <= 1) {
                $('#prev').css('display', 'none');
            }
            $(".question_wraper a[href='#ques" + qnnew + "']").trigger('click');
        });
        var c = parseInt('{{$activetest->activetime}}');
        timer();
        function timer() {

            var hours = parseInt(c / 3600) % 24;
            var minutes = parseInt(c / 60) % 60;
            var seconds = c % 60;
            var result = (hours < 10 ? "0" + hours : hours) + ":" + (minutes < 10 ? "0" + minutes : minutes) + ":" + (seconds < 10 ? "0" + seconds : seconds);
            $('#timer span').html(result);
        }
        var t;
        function timedCount() {
            var hours = parseInt(c / 3600) % 24;
            var minutes = parseInt(c / 60) % 60;
            var seconds = c % 60;
            var result = (hours < 10 ? "0" + hours : hours) + ":" + (minutes < 10 ? "0" + minutes : minutes) + ":" + (seconds < 10 ? "0" + seconds : seconds);
            $('#timer span').html(result);
            if (c == 0) {
                $('#timer span').html("00:00:00");
                //$("#quizform").submit();
                $("#quiz_done").addClass("disabled");

            } else {
                c = c - 1;
                $.get('{{Route("student.tmerstartquiz")}}', {time: c, id: '{{$activetest->id}}'})
                        .done(function (data) {
                            //alert("Data Loaded: " + data);
                        });
                t = setTimeout(function () {
                    timedCount();
                }, 1000);
            }
        }
        $("#quiz_done").click(function () {
            $("#quizform").submit();
        });
        $("#quiz_done1").click(function () {
            $("#quizform").submit();
        });
        $("#trigertime").trigger("click");



    });
</script>

@endsection


