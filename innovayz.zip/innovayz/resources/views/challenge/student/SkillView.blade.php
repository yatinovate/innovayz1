@extends('layouts.master')

@section('headscript')
<title>Challange | Choose Your Challange | InnoVayz</title>
<link rel="stylesheet" href="{{asset("Challenge/css/viewchallenge.css")}}">
@endsection
@section('content')

<div class="toppart">
    <div class="container-fluid">
        <div class="row">
            <div class="topbar_head">
                <h2>Challenge Test</h2>
                <p>Don't you want to check your capabilities and intellignece in your own Area of Intreset !!</p>
            </div>
        </div>
        <div class="row">
            <div class="topcountcont">
                <div class="col-md-12">
                    <div class="col-md-6 col-xs-3">
                        <div class="topcounter">
                            <h2>{{$challengecount}}</h2>
                            <p>Total Challenge</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-xs-3">
                        <div class="topcounter">
                            <h2>{{$totaluser}}</h2>
                            <p>Total Paricipated</p>
                        </div>
                    </div>                   
                </div>
            </div>
        </div>
    </div>
</div>
<div class="chalenge_cont">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-10">
                <!--<div class="norecord">
                    <h2>No Challenge Taken Yet !!</h2>
                    <p>Take Challenge and check your strenght & knowledge</p>
                    <p>
                        <a href='#'  class="btn btn-info btn-lg">Take Challenge</a>
                    </p>
                </div>-->
                <div class="row" id="skillgetter">

                </div>
            </div>
            <div class="col-md-2">
                <div class="panel-group">
                    <div class="panel panel-primary">
                        <div class="panel-body">
                            <img class="img-responsive" src="{{asset("img/hh.png")}}" alt="hllo">
                        </div>
                    </div>
                    <div class="panel panel-primary">
                        <div class="panel-body">                                
                            <img class="img-responsive" src="{{asset("img/hh.png")}}" alt="hllo">
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>
</div>
@endsection
@section('jsfiles')
<script>
    $(function () {

        $.get('{{Route("student.getter")}}', function (data) {
            $("#skillgetter").html(data);
        });

    });
</script>

@endsection


