<div class="row margin-bottom-10">
    <div class="col-md-6 col-sm-6 col-xs-6">
        <a href="{{URL::to("social/redirect/facebook")}}" class="btn btn-block facebook"><i class="fa fa-facebook"></i>&nbsp;&nbsp;Sign up</a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-6">
        <a href="{{URL::to("social/redirect/google")}}" class="btn btn-block google"><i class="fa fa-google-plus"></i>&nbsp;&nbsp;Sign up</a>
    </div>
</div>

