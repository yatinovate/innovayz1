@if(session()->has('above-navbar-message') && auth()->check())
    <div class="alert alert-success" role="alert" style="margin-bottom:0px;border-radius:  0;font-size: 14px;">
        <button type="button" class="close" data-dismiss="alert" >×</button>
        {!! session()->get('above-navbar-message') !!}
    </div>
@endif