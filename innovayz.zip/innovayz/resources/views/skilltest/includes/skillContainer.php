<div class="row">
    <div class="col-md-12">
        <label class="control-label question_label"><b>Question : </b><?php echo $ques->question; ?> </label>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <input type="radio" name="q1" value="<?php echo $ques->ans_a; ?>">&nbsp;&nbsp;
            <?php echo $ques->ans_a; ?>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <input type="radio" name="q1" value="<?php echo $ques->ans_b; ?>">&nbsp;&nbsp;
            <?php echo $ques->ans_b; ?>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <input type="radio" name="q1" value="<?php echo $ques->ans_c; ?>">&nbsp;&nbsp;
            <?php echo $ques->ans_c; ?>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <input type="radio" name="q1" value="<?php echo $ques->ans_d; ?>">&nbsp;&nbsp;
            <?php echo $ques->ans_d; ?>
        </div>
    </div>
</div>
