@extends('layouts.master')

@section('headscript')
<title>Result Skill Test</title>
<link rel="stylesheet" href="{{asset("css/skilltest.css")}}">
<style>
    .breadcrumb li a{
        color: #000;
        text-decoration: none;
    }
</style>

@endsection
@section('content')
<div class="result_banner">
    <div class="container">
        <div class="row">
            {!!$usermsg!!}
            <p><a href="{{Route("student.skillleaderbord", ["skill-id" => $skill->id, "skill-name" => $skill->skill_test_name])}}">View Leaderboard (click here)</a></p>

        </div>
    </div>
</div>

<div class="container">
    <br>
    <div class="row">
        <ol class="breadcrumb breadcrumb-arrow">
            <li><a href="{{Route("Dashboard")}}">Dashboard</a></li>
            <li><a href="{{Route("student.activeskill")}}">Active Skill Test</a></li>
            <li class="active">View Result</li>
        </ol>
    </div>
    <div class="row">
        <div class="col-md-10 col-md-offset-1 ">


            <div class="reult_wrap">
                <div class="alert alert-info text-center">
                    {{$skill->skill_test_name}}
                </div>

                <table class="table text-center table-bordered table-responsive">
                    <thead>
                    <th>Total Questions</th>
                    <th>Questions Attempted</th>
                    <th>Correct Answers</th>
                    <th>Incorrect Answers</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td>{{$totalq}}</td>
                            <td>{{$unatempt}}</td>
                            <td>{{$correctq}}</td>
                            <td>{{$incorectq}}</td>
                        </tr>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
</div>



@endsection


@section('jsfiles')



@endsection


