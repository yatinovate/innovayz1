@extends('layouts.master')

@section('headscript')
<title>Skill Test</title>
<link rel="stylesheet" href="{{asset("Challenge/css/viewchallenge.css")}}">
<meta http-equiv="refresh" content="300">
<style>

</style>
@endsection
@section('content')

<div class="toppart">
    <div class="container-fluid">
        <div class="row">
            <div class="topbar_head">
                <div class="col-md-12">
                    <h2>Skill Test</h2>
                    <p>Don't you want to check your capabilities and intellignece in your own Area of Intreset !!</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="topcountcont">
                <div class="col-md-12">
                    <div class="col-md-6">
                        <div class="topcounter">
                            <h2>{{$challengecount}}</h2>
                            <p>Total Skill Test</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="topcounter">
                            <h2>{{$totaluser}}</h2>
                            <p>Total Paricipated</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="chalenge_cont">
    <div class="container-fluid">
    <div class="row">
        <div class="col-md-9">
            <!--<div class="norecord">
                <h2>No Challenge Taken Yet !!</h2>
                <p>Take Challenge and check your strenght & knowledge</p>
                <p>
                    <a href='#'  class="btn btn-info btn-lg">Take Challenge</a>
                </p>
            </div>-->
            <div class="row" id="skillgetter">
                
            </div>
        </div>
        <div class="col-md-2 col-md-offset-1">
            @include("includes.adblock")
        </div>
    </div>

</div>
</div>
@endsection
@section('jsfiles')
<script>
$(function () {
   
$.get('{{Route("student.activeskillgrid")}}', function( data ) {
  $("#skillgetter").html( data );
});

});
</script>

@endsection


