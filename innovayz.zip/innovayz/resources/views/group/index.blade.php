@extends('layouts.master')
@section('headscript')
<meta name="_token" content="{{ csrf_token() }}">
<link rel="stylesheet" href="{{asset("Dashboard/css/dashboard.css")}}">
<link href="{{asset("css/magicsuggest-min.css")}}" rel="stylesheet">
<link rel="stylesheet" href="{{asset('groups/css/index.css')}}">

@stop
@section('content')
@include("Dashboard.includes.upper_panel")

<div class="container-fluid">
    <div class="row">

        <div class="col-md-2">
            @include("Dashboard.includes.sidebar")
        </div>
        <div class="col-md-8 post_section">
            @include("errors.status")
            <div class="panel panel-default">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-7">
                            <h2 class="panel-title">Group Name : {{$grp->group_name}}</h2>
                        </div>
                        <div class="col-xs-5">
                            <span class="pull-right">Group Code : {{$grp->group_code}}</span>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-12">

                            <div class="tabbable-panel">
                                <div class="tabbable-line tabs-below">
                                    <div class="row">
                                        <div class="col-md-12">

                                            <ul class="nav nav-tabs">
                                                <li class="active">
                                                    <a href="#pinnedevent" data-toggle="tab">Posts</a>
                                                </li>
                                                <li>
                                                    <a href="#memberlist" data-toggle="tab">Members</a>
                                                </li>
                                                @if(Auth::user()->id==$grp->user_id)
                                                <li class="">
                                                    <a href="#addmember" data-toggle="tab">Add Members</a>
                                                </li>
                                                <li class="">
                                                    <a href="#addrequest" data-toggle="tab">Add Request</a>
                                                </li>
                                                @endif
                                            </ul>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="tab-content">
                                        <div class="tab-pane active" id="pinnedevent">
                                            <form class="form-horizontal" method="post" action="" id="grp_chat">
                                                {{ csrf_field() }}
                                                <div class="form-group">
                                                    <label  class="col-sm-12 control-label">Subject</label>
                                                    <div class="col-sm-12">
                                                        <input type="text" class="form-control" placeholder="Enter Your Subject" name="g_subject"/>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-sm-12 control-label">Description</label>
                                                    <div class="col-sm-12">
                                                        <textarea class="form-control" id="g_poster"  placeholder="Enter details of post" name="g_poster"></textarea>
                                                    </div>
                                                </div>
                                                <input type="hidden" name="group_id" value="{{$grp->id}}" />
                                                <div class="form-group">
                                                    <div class="col-sm-offset-2 col-sm-10">
                                                        <input type="submit" class="btn btn-primary pull-right" id="btn-chat" value="Post">
                                                    </div>
                                                </div>
                                            </form>
                                            @if(count($grp->grpchat))
                                            <div class="chat_sepration">
                                                <p>Latest Posts</p>
                                                <hr>
                                            </div>
                                            @else
                                            <div class="chat_sepration" style="display: none">
                                                <p>Latest Posts</p>
                                                <hr>
                                            </div>
                                            @endif
                                            

                                            <div class="row">
                                                <div class="chat_wrap" style="display: none">
                                                    <div class="panel-body">
                                                        <ul class="chat" ></ul>                                  
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="addmember">
                                            <form class="form-horizontal" method="post" action="{{Route("groups.adduser")}}" id="addgroup_form">
                                                {{ csrf_field() }}
                                                <div class="form-group">
                                                    <label class="col-sm-12 control-label">Add Members to the group</label>
                                                    <div class="col-sm-12">
                                                        <input type="text" class="form-control " id="addgroup_persons1" name="addgroup_persons1" placeholder="Add Members to the group">
                                                        <input type="hidden" class="form-control" id="addgroup_persons" name="addgroup_persons" placeholder="Add Members to the group">
                                                        <input type="hidden" name="group_id" value="{{$grp->id}}" />
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-sm-offset-2 col-sm-10">
                                                        <input type="submit" class="btn btn-primary pull-right"  value="Add Member">
                                                    </div>
                                                </div>

                                            </form>
                                        </div>
                                        <div class="tab-pane" id="addrequest">
                                            @if(count($userrequest))
                                            <table class="table table-responsive table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Accept Request</th>
                                                        <th>Delete Request</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach($userrequest as $req)
                                                    <?php
                                                    $name = \App\Models\User::find($req->user_id)->name;
                                                    ?>
                                                    <tr>
                                                        <td>{{$name}}</td>
                                                        <td><a href="{{Route("groups.joinaccept",["request-id"=>$req->id])}}">accept</a></td>
                                                        <td><a href="{{Route("groups.joindelete",["request-id"=>$req->id])}}">delete</a></td>
                                                    </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                            @else
                                            <p>No request</p>
                                            @endif
                                        </div>
                                        <div class="tab-pane" id="memberlist">
                                            <?php
                                            $grpuser = App\Models\Group\GroupsUser::where("group_id", $grp->id)->get();
                                            foreach ($grpuser as $guser) {
                                                $user = \App\Models\User::find($guser->user_id);
                                                $remove = '';
                                                if (Auth::user()->id == $grp->user_id) {
                                                    $remove = '<a href="' . Route("groups.deleteuser", ["id" => $guser->user_id, "grp_id" => $grp->id]) . '">Remove</a>';
                                                }
                                                if ($grp->user_id == $guser->user_id) {
                                                    $remove = " (Group Owner)";
                                                }
                                                echo '<div class="row memberuser">';
                                                echo '<div class="col-md-2"><img src="' . asset($user->avatar) . '" alt="profile" class="img-responsive"> </div>';
                                                echo '<div class="col-md-6"><br>'
                                                . '<h3><a href="' . Route("profile.index", ["user-id" => $user->id, 'user-name' => $user->name]) . '">' . $user->name . '</a></h3><span>' . substr($user->user_type, 0, -1) . '</span></div>';
                                                echo '<div class="col-md-4">' . $remove . '</div>';
                                                echo '</div>';
                                                echo '<hr>';
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 

        </div>


        <div class="col-md-2">
            @include("Dashboard.includes.advertisement")
        </div>
    </div>
</div>
</div>
@stop
@section('jsfiles')
@include("Dashboard.includes.footer")
<script>
    tinymce.init({
        selector: "#g_poster",
        menubar: false,
        plugins: ["advlist lists link image charmap  anchor"],
        link_assume_external_targets: true,
        toolbar: " styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist | link image",
        image_dimensions: false,
        setup: function (editor) {
            editor.on('change', function () {
                tinymce.triggerSave();
            });
        }
    });
</script>
<script>
    $(function () {
        $.getJSON('{{Route("groups.getchat",["id" => $grp->id])}}', function (data) {
            $('.chat').html(data.data);
            $('.chat_wrap').show();
            var height = $('.chat_wrap').height();
            if (height >= 550) {
                $('.chat_wrap .panel-body').css({'overflow-y': 'scroll', 'height': '550px'});
            }
        }).success(function () { });


        $('#grp_chat').formValidation({
            framework: 'bootstrap',
            icon: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                g_subject: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }

            }
        }).on('success.form.fv', function (e) {
            e.preventDefault();
            var form = $('#grp_chat');
              // send ajax request
            $.ajax({
                url: '{{Route("groups.savechat")}}',
                type: 'POST',
                cache: false,
                data: form.serialize(), //form serizlize data
                beforeSend: function () {
                    
                },
                success: function (data) {
                    $.getJSON('{{Route("groups.getchat",["id" => $grp->id])}}', function (data) {
                        $('.chat_sepration').show();
                        $('.chat').html(data.data);
                        $('.chat_wrap').show();
                        var height = $('.chat_wrap').height();
                        if (height >= 550) {
                            $('.chat_wrap .panel-body').css({'overflow-y': 'scroll', 'height': '550px'});
                        }
                    });
                    form.trigger('reset');
                    $('#btn-chat').removeAttr('disabled').removeClass("disabled");
                },
                error: function (e) {
                    alert(e);
                }
            });
        });

        var ms = $('#addgroup_persons1').magicSuggest({
            allowFreeEntries: false,
            valueField: 'value',
            displayField: 'label',
            required: true,
            allowDuplicates: false,
            data: '{{Route("groups.getadduser",["grpid"=>$grp->id])}}',
            ajaxConfig: {
                xhrFields: {
                    withCredentials: true
                }
            }
        });

        $(ms).on('selectionchange', function (e, m) {
            var asd = this.getValue();
            $("#addgroup_persons").val(asd);
        });
    });
</script>

@endsection
<!-- Modal -->









