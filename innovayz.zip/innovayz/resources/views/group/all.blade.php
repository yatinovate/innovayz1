@extends('layouts.master')
@section('headscript')
<link rel="stylesheet" href="{{asset("Dashboard/css/dashboard.css")}}">
<link href="{{asset("css/magicsuggest-min.css")}}" rel="stylesheet">
<title>All Groups | Innovayz</title>

@stop
@section('content')
@include("Dashboard.includes.upper_panel")
<div class="container-fluid">
    <div class="row">
        <div class="col-md-2">
            @include("Dashboard.includes.sidebar")
        </div>
        <div class="col-md-8 post_section">
            @include("errors.status")
            <div class="panel panel-default">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-12">
                            <h2 class="panel-title">All Groups</h2>
                        </div>
                    </div>
                </div>
                <div class="panel-body">

                    @if(count($userarray))
                    @foreach ($userarray as $poster)
                    <div class="col-md-4 user-box">
                        <div class="well well-sm">
                            <div class="row">
                                <div class="col-md-12">
                                     <h4><a href="{{Route("groups.index",["group-id"=>$poster->groupinfo->id,"group-name"=>$poster->groupinfo->group_name])}}">{{ $poster->groupinfo->group_name }}</a></h4>
                                </div>
                               
                            </div>
                        </div>
                    </div>
                    @endforeach
                    @else
                    <p>No Connections</p>
                    @endif
                </div>
            </div>
        </div>
        <div class="col-md-2">
            @include("Dashboard.includes.advertisement")
        </div>
    </div>
</div>
</div>
@stop
@section('jsfiles')
@include("Dashboard.includes.footer")
@stop