@extends('layouts.master')
@section('headscript')
<title>Manage Groups | Innovayz</title>
<link rel="stylesheet" href="{{asset("Dashboard/css/dashboard.css")}}">
<link href="{{asset("css/magicsuggest-min.css")}}" rel="stylesheet">
<link rel="stylesheet" href="{{asset('groups/css/index.css')}}">
<style>
    .upadategroup{
        padding: 10px;
    }
    .upadategroup a{
        color: #761c19;
        font-weight: bold;
        font-size: 12px;
    }
</style>
@stop
@section('content')
@include("Dashboard.includes.upper_panel")
<div class="container-fluid">
    <div class="row">
        <div class="col-md-2">
            @include("Dashboard.includes.sidebar")
        </div>
        <div class="col-md-8 post_section">
            @include("errors.status")
            <div class="panel panel-default">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-12">
                            <h2 class="panel-title">Groups : Manage</h2>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-12">
                            <?php
                            $archses = "";
                            $noarchi = "active";
                            if (Session::has('archivedstatus')) {
                                $archses = "active";
                                $noarchi = "";
                            }
                            session()->forget('archivedstatus');
                            ?>
                            <div class="tabbable-panel">
                                <div class="tabbable-line tabs-below">
                                    <div class="row">
                                        <div class="col-md-12">

                                            <ul class="nav nav-tabs">
                                                <li class="{{$noarchi}}">
                                                    <a href="#activeGroup" data-toggle="tab">Active</a>
                                                </li>
                                                <li class="{{$archses}}">
                                                    <a href="#archivedgroup" data-toggle="tab">Archived</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="tab-content">
                                        <div class="tab-pane {{$noarchi}}" id="activeGroup">
                                            @if(count($grploop))
                                            <div class="list-group">
                                                @foreach ($grploop as $grplist)
                                                @if(!$grplist->archive)
                                                @if($grplist->user_id==Auth::user()->id)
                                                <a data-toggle="collapse"  href="#groupEdit{{$grplist->id}}" class="list-group-item">{{$grplist->group_name}}<span class="pull-right"><i class="fa fa-caret-down"></i></span></a>
                                                <div id="groupEdit{{$grplist->id}}" class="panel-collapse collapse">

                                                    <form class="form-horizontal upadategroup" method="post" action="{{Route("groups.manageUpdate")}}" id="addgroup_form">
                                                        {{ csrf_field() }}
                                                        <div class="form-group">
                                                            <label class="col-sm-3 control-label">Update Group Name</label>
                                                            <div class="col-sm-5">
                                                                <input type="text" class="form-control " name="grp_nme" placeholder="Group Name">
                                                                <input type="hidden" name="group_id" value="{{$grplist->id}}" />
                                                            </div>
                                                            <div class="col-sm-2">
                                                                <input type="submit" class="btn btn-primary pull-right"  value="Update Name">
                                                            </div>
                                                            <div class="col-sm-2">
                                                                or <a href="{{Route("groups.manageDelete",["grpid"=>$grplist->id])}}"><i class="fa fa-trash"></i>&nbsp;Delete Group</a>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                                @else
                                                <a href="#" class="list-group-item">{{$grplist->group_name}}</a>
                                                @endif
                                                @endif
                                                @endforeach
                                            </div>
                                            @else
                                            <p>No active groups</p>
                                            @endif
                                        </div>
                                        <div class="tab-pane {{$archses}}" id="archivedgroup">
                                            @if(count($grploop))
                                            <ul class="list-group">
                                                @foreach ($grploop as $grplist)
                                                @if($grplist->user_id==Auth::user()->id)
                                                <?php
                                                $archived = "Archive";
                                                if ($grplist->archive) {
                                                    $archived = "Unarchive";
                                                }
                                                ?>
                                                <li class="list-group-item">{{$grplist->group_name}}<span class="pull-right"><a href="{{Route("groups.archived",["grpid"=>$grplist->id])}}">{{$archived}}</a></span></li>
                                                @else
                                                <a href="#" class="list-group-item">{{$grplist->group_name}}</a>
                                                @endif
                                                @endforeach
                                            </ul>
                                            @else
                                            <p>No groups</p>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="col-md-2">
            @include("Dashboard.includes.advertisement")
        </div>
    </div>
</div>
</div>
@stop
@section('jsfiles')
@include("Dashboard.includes.footer")
@stop