@extends('admin.layout.master')

@section('adminheadscript')
<title>Create Adblock | Admin Dashboard</title>
<link href="{{asset("css/magicsuggest-min.css")}}" rel="stylesheet">
@end
@section('content')
<div class="admin_container">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2">
                @include('admin.includes.leftnav')
            </div>
            <div class="col-md-10">
                <div class="user_content">
                    <div class="tab-content">
                        <!--All Users-->
                        <div id="all_users" class="tab-pane fade in active">
                            <div class="row">
                                <h1 class="user_title">Advertisement : Create Adblock</h1>
                                @include("errors.status")
                                <form role="form" enctype="multipart/form-data"  id="camping_form" method="post" action="{{Route("admin.saveadblock")}}">
                                    {{csrf_field()}}
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label col-sm-12">Advertisement Name</label>
                                            <div class="col-sm-12">
                                                <input type="text" class="form-control" name="add_name" placeholder="Advertisement Name">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                                <label class="control-label col-md-12">Advertisement Link</label>
                                                <div class="col-md-12">
                                                    <input type="text" class="form-control" name="add_link"  placeholder="Advertisement Link">
                                                </div>
                                            </div>
                                    </div>
                                    
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="control-label col-md-12">Advertisement Image</label>
                                            <div class="col-md-12">
                                                <input type="file" class="form-control" name="add_image"  placeholder="Advertisement Link">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group"><br>
                                            <button type="submit" class="btn btn-primary pull-right">Save</button>
                                        </div>
                                    </div>
                                    
                                </form>
                            </div>
                        </div>

                    </div>
                </div>

            </div>

        </div>
    </div>
    <!-- /.row -->
</div>
@stop
@section('jsfiles')
<script src="{{asset("js/validation/formvalidation-min.js")}}"></script>
<script src="{{asset("js/validation/bootstrap.js")}}"></script>
<script>
$(document).ready(function () {

    
    $('#camping_form').formValidation({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            add_name: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }, add_link: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    },uri: {
                        message: 'The website address is not valid'
                    }
                }
            }, add_image: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    },file: {
                        extension: 'jpeg,jpg,png',
                        type: 'image/jpeg,image/png',
                        maxSize: 2097152,   // 2048 * 1024
                        message: 'The selected file is not valid'
                    }
                }
            }
        }
    });


});
</script>
@stop
