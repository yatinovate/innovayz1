@extends('admin.layout.master')
@section('adminheadscript')
<title>Manage Adblocks</title>
@end
@section('content')
<div class="admin_container">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2">
                @include('admin.includes.leftnav')
            </div>


            <div class="col-md-10">
                <div class="user_content">
                    <div class="tab-content">
                        <!--All Users-->
                        <div id="all_users" class="tab-pane fade in active">
                            <div class="row">
                                <h1 class="user_title">Advertisement : Manage Adblocks</h1>
                                <table class="table table-bordered table-responsive table-hover table-striped" id="dtable">
                                    <thead>
                                        <tr>
                                            <th scope="col">S.No</th>
                                            <th scope="col">Addblock Name</th>
                                            <th scope="col">Link</th>
                                            <th scope="col"><a>Image</a></th>
                                            <th scope="col"><a>Delete</a></th>
                                        </tr>
                                    </thead>
                                    <tbody><?php $cout = 1; ?>
                                        @foreach($campaign as $test)
                                        <tr>
                                            <td>{{$cout}}</td>
                                            <?php $cout++ ?>
                                            <td>{{$test->ad_name}}</td>     
                                            <td><a target="_blank" href="{{$test->ad_link}}">Link</a></td>
                                            <td><img width="100" src="{{asset("Advertisement/".$test->ad_image)}}"></td>
                                            <td><a href="{{Route("admin.deleteADblock", ["campaign-id" =>$test->id])}}">Delete</a></td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>

                            </div>
                        </div>

                    </div>
                </div>

            </div>

        </div>
    </div>
    <!-- /.row -->
</div>
@stop
@section('jsfiles')
<script>
    $(function () {
        $(".published").click(function () {
            var btn = $(this);
            var skillid = btn.attr("data-id");
            $.get('{{Route("admin.publishCampaign")}}', {skillid: skillid})
                    .done(function (data) {
                        btn.html(data);
                window.location.reload(true);
                    });
        });
     
   


    });

</script>
@stop
