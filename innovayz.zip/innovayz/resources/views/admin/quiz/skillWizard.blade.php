@extends('admin.layout.master')
@section('adminheadscript')
<title>Skill Test Wizard</title>
<link rel="stylesheet" href="{{asset('adminRes/css/skillwizard.css')}}">
<style>
    #multi_cho .selectContainer .form-control-feedback{
    /* Adjust feedback icon position */
    right: -40px;
}
#multi_opt .selectContainer .form-control-feedback,#tf_type .selectContainer .form-control-feedback{
    /* Adjust feedback icon position */
    right: -15px;
}
</style>
@stop
@section('content')
<div class="admin_container">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2">
                @include('admin.includes.leftnav')
                <br>
                <b>Questions</b>
                <div class="sidebar">
                    <div class="questionwraper">
                        @for($ix=1;$ix<=$skilltest->questn_count;$ix++)
                        <a class="list-group-item questupdate" data_id="{{$ix}}" id="quest<?php echo $ix; ?>">Question <?php echo $ix; ?><span class="pull-right">&nbsp;<i class="fa fa-question-circle"></i></span></a>
                        @endfor
                    </div>
                </div>
            </div>
            <div class="col-md-10">
                <div class="user_content">
                    <div class="tab-content">
                        <!--All Users-->
                        <div id="all_users" class="tab-pane fade in active">
                            <h1 class="user_title">Skill Test : Wizard</h1>
                            @include("errors.status")
                            <div class="skill_wizard_header">
                                <div class="row">
                                    <div class="col-md-12">
                                        <h3>{{$skilltest->skill_test_name}}</h3><hr>
                                    </div>
                                    <div class="col-md-12">         
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="col-md-3 control-label">TYPE</label>
                                                <div class="col-md-9">
                                                    <select class="form-control" name="test_type" id="test_type">
                                                        <option value="null">Question Type</option>
                                                        <option value="mo" >Multiple Options</option>
                                                        <option value="mcq" >Multiple Choice</option>
                                                        <option value="tf">True False</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <p class="question_count">Saved Question : <span><?php echo $skilltest->qnoprocess; ?></span></p>
                                        </div>   
                                        <div class="col-md-3 text-right">
                                            <p  class="question_count" id="question_count" data_id="<?php echo $skilltest->id; ?>">Total Question : <span><?php echo $skilltest->questn_count; ?></span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="wizard_body">
                                <div class="skill_question_content">
                                    <div class='bg_loader text-center'>
                                        Select Question type
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@stop
@section('jsfiles')

<script src="{{asset("js/validation/formvalidation-min.js")}}"></script>
<script src="{{asset("js/validation/bootstrap.js")}}"></script>
<script>
$(function () {
    var totalq = <?php echo $skilltest->questn_count; ?>;
    var qprog = <?php echo $skilltest->qnoprocess; ?>;
    var questionid = qprog + 1;
    $("#quest" + questionid).addClass("active");

    for (var i = 0; i < questionid; i++) {
        $("#quest" + i).addClass("active");
    }
    for (var i = questionid + 1; i <= totalq; i++) {
        $("#quest" + i).addClass("disabled");
    }
    if (qprog === totalq) {
        $(".skill_question_content").html("Skill Test saved");
        $(".skill_wizard_header").remove();
    }
    $("#test_type").change(function () {
        var selectedValue = $(this).val();
        $(".skill_question_content").html("<div class='bg_loader text-center'><img src='<?php echo asset('adminRes/img/ajax-loader.gif'); ?>' class='adminloader img-responsive'></div>");
        $.ajax({
            url: '{{Route("admin.questype")}}',
            type: 'GET',
            data: {qtype: selectedValue, skillid: '{{$skilltest->id}}'},
            success: function (data) {
                $(".skill_question_content").remove(".bg_loader");
                $(".skill_question_content").html(data);
                if (qprog === totalq - 1) {
                    $("#save_ques").text("Finish");
                }
            },
            error: function (data) {
                $("#test_type").attr('disabled', false);
                $(".skill_question_content").html('<div class="bg_loader text-center">Select Question type</div>');
            }
        });
    });
    $(".questupdate").click(function ()
    {
        $(".questionwraper .active").removeClass("active");
        $(this).addClass("active");
        $("#test_type").attr('disabled', 'disabled');
        var qid = $(this).attr("data_id");
        var skilid =<?php echo $skilltest->id; ?>;
        $.ajax({
            url: '{{Route("admin.update")}}',
            type: 'GET',
            data: {qid: qid, skillid: skilid},
            success: function (data) {
                $(".skill_question_content").html(data);
            },
            error: function (data) {
                $("#test_type").attr('disabled', false);
                $(".skill_question_content").html('<div class="bg_loader text-center">Select Question type</div>');
            }
        });

    });
});
</script>

@stop