@extends('admin.layout.master')
@section('adminheadscript')
<title>Make Skill Test</title>
<style>
    #addquest .modal-header{

        background-color: #337ab7;
        color: #fff;
        padding: 10px;
        font-size: 18px;
        font-family: open sans;
        font-weight: bold;
    }

    #addquest .modal-dialog{
        width: 400px; /* or whatever you wish */
        z-index: 0;
    }
    #addquest span{
        font-size: 10px;
    }
    #addquest .control-label,#addquest label{
        text-align: left !important;
        margin-bottom: 10px !important;
        font-weight: bold;
        text-transform: capitalize;
        font-family: open sans;
        font-size: 12px;
    }
    #upload_csv{
        line-height: 1.9em;
        padding-bottom: 40px;
    }
</style>
@stop
@section('content')
<div class="admin_container">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2">
                @include('admin.includes.leftnav')
            </div>
            <div class="col-md-10">
                <div class="user_content">
                    <div class="tab-content">
                        <!--All Users-->
                        <div id="all_users" class="tab-pane fade in active">
                            <div class="row">
                                <h1 class="user_title">Setting : Create Skill Test</h1>
                                <div class="col-md-12" style="padding: 40px 0">
                                    <div class="col-md-4 text-center">
                                        <a class="btn btn-info btn-lg" id="createquiz" href="{{Route('admin.createquiz')}}">Create Skill Test</a>
                                    </div>
                                    <div class="col-md-4 text-center">
                                        <a class="btn btn-info btn-lg" id="quizupload" data-toggle="modal" data-target="#addquest" href="#">Upload Skill Test</a>
                                    </div>
                                    <div class="col-md-4 text-center">
                                        <a class="btn btn-info btn-lg" href="{{asset("Challenge/sample-csv.csv")}}">Download Sample Csv File</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /.row -->
</div>
@stop
@section('jsfiles')
<script>
    $(function () {


        $("#submit_qus").click(function (e) {
            e.preventDefault();
            if ($("#upload_csv").val().toLowerCase().lastIndexOf(".csv") == -1)
            {
                alert("Please upload a file with .csv extension.");
                return false;
            } else {
                var btn = $(this);
                btn.html('checking <i class="fa fa-spinner fa-pulse fa-1x fa-fw"></i><span class="sr-only">Loading...</span>');
                $.ajax({
                    type: "POST",
                    url: '{{Route("admin.csvupload")}}',
                    data: new FormData($("#postanswer")[0]),
                    datatype: 'JSON',
                    async: false,
                    processData: false,
                    contentType: false,
                    success: function (data) {
                        window.location.href = '{{Route("admin.csvcreater")}}';
                    }
                });

            }
        });

    });
</script>
@stop
<div class="modal fade" id="addquest" role="dialog">
    <div class="modal-dialog my_modal">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center">Upload Csv</h4>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" id="postanswer" enctype="multipart/form-data">
                    <div class="form-group">
                        <label class="col-sm-12 control-label">Add Csv (Only CSV files)</label>
                        <div class="col-sm-12">
                            <input type="file" class="form-control" id="upload_csv" name="upload_csv" placeholder="Upload Csv">    
                            <span class="help-block"><strong></strong></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <input type="button" class="btn btn-primary pull-right"  id="submit_qus" value="Upload">
                        </div>
                    </div>
                </form>


            </div>                                       
        </div>
    </div>
</div>