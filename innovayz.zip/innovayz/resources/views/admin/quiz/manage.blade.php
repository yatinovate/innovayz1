@extends('admin.layout.master')
@section('adminheadscript')
<title>Skill Test Manage</title>
@end
@section('content')
<div class="admin_container">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2">
                @include('admin.includes.leftnav')
            </div>


            <div class="col-md-10">
                <div class="user_content">
                    <div class="tab-content">
                        <!--All Users-->
                        <div id="all_users" class="tab-pane fade in active">
                            <div class="row">
                                <h1 class="user_title">Skill Test : Manage Skill Test</h1>
                                <table class="table table-bordered table-responsive table-hover table-striped" id="dtable">
                                    <thead>
                                        <tr>
                                            <th scope="col">S.No</th>
                                            <th scope="col">Skill Test</th>
                                            <th scope="col">Preview</th>
                                            <th scope="col"><a>Publish Status</a></th>
                                            <th scope="col"><a>Archive Status</a></th>
                                            <th scope="col"><a>Add Question</a></th>
                                            <th scope="col"><a>Edit</a></th>
                                            <th scope="col"><a>Delete</a></th>
                                        </tr>
                                    </thead>
                                    <tbody><?php $cout = 1; ?>
                                        @foreach($skills as $test)
                                        <tr>
                                            <td>{{$cout}}</td>
                                            <?php $cout++ ?>
                                            <td>{{$test->skill_test_name}}</td>     
                                            <td><a target="_blank" href="{{Route("admin.preview",["skill_id"=>$test->id])}}">Preview</a></td>
                                            @if($test->publish==0)
                                            <td><a href="javascript:;" class="published" data-id="{{$test->id}}">Publish</a></td>
                                            @else
                                            <td><a href="javascript:;" class="published" data-id="{{$test->id}}">Unpublish</a></td>
                                            @endif
                                             @if($test->publish==0)
                                            @if($test->archive==0)
                                            <td><a href="javascript:;" class="archive" data-id="{{$test->id}}">Archive</a></td>
                                            @else
                                            <td><a href="javascript:;" class="archive" data-id="{{$test->id}}">Unarchive</a></td>
                                            @endif
                                            @else
                                            @if($test->archive==0)
                                            <td><a >Archive</a></td>
                                            @else
                                            <td><a >Unarchive</a></td>
                                            @endif
                                            @endif 
                                            
                                            @if($test->publish==0)
                                            <td><a href="javascript:;" class="addque" data-id="{{$test->id}}" data-toggle="modal" data-target="#addquest">Add Questions</a></td>
                                            @else
                                            <td><a  class="disabled" >Add Questions</a></td>
                                            @endif
                                            
                                            @if($test->publish==0)
                                            <td><a href="{{Route("admin.editQuestion", ["skillid" =>$test->id])}}">Edit</a></td>
                                            @else
                                            <td><a  class="disabled">Edit</a></td>
                                            @endif
                                            @if($test->publish==0)
                                            <td><a href="{{Route("admin.delete", ["skill-id" =>$test->id])}}">Delete</a></td>
                                            @else
                                            <td><a  class="disabled">Delete</a></td>
                                            @endif
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>

                            </div>
                        </div>

                    </div>
                </div>

            </div>

        </div>
    </div>
    <!-- /.row -->
</div>
@stop
@section('jsfiles')

<script src="{{asset("js/validation/formvalidation-min.js")}}"></script>
<script src="{{asset("js/validation/bootstrap.js")}}"></script>
<script>
    $(function () {
        $(".published").click(function () {
            var btn = $(this);
            var skillid = btn.attr("data-id");
            $.get('{{Route("admin.publish")}}', {skillid: skillid})
                    .done(function (data) {
                        btn.html(data);
                window.location.reload(true);
                    });
        });

        $(".archive").click(function () {
            var btn = $(this);
            var skillid = btn.attr("data-id");
            $.get('{{Route("admin.archive")}}', {skillid: skillid})
                    .done(function (data) {
                        btn.html(data);
                window.location.reload(true);
                    });

        });
        
        $(document).on("click", ".addque", function (e) {

    e.preventDefault();

    var _self = $(this);

    var myBookId = _self.data('id');
    $("#skillidq").val(myBookId);
});


        $('#postanswer').formValidation({
            framework: 'bootstrap',
            icon: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: { add_question: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }, regexp: {
                            message: 'Invalid Input',
                            regexp: /^[0-9]+$/
                        }
                    }
                }
            }
        });
    });

</script>
<script src="{{asset("adminRes/js/admin.js")}}"></script>
@stop

<div class="modal fade" id="addquest" role="dialog">
    <div class="modal-dialog my_modal">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center">Add Questions</h4>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" id="postanswer" method="post" action="{{Route("admin.addQuestion")}}">
                    {{csrf_field()}}
                    <div class="form-group">
                        <label class="col-sm-12 control-label">Add Questions</label>
                        <div class="col-sm-12">
                            <input type="text" class="form-control" id="add_question" name="add_question" placeholder="Enter no of Questions to add">
                        </div>
                    </div>

                    <input type="hidden" value="" name="skillidq" id="skillidq">
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <input type="submit" class="btn btn-primary pull-right" id="submit_qus" value="Save">
                        </div>
                    </div>
                </form>

            </div>                                       
        </div>
    </div>
</div>