<form class="form-horizontal" id="tf_type" method="post" action="<?php echo Route("admin.savetrueupdate"); ?>">
    <?php echo csrf_field(); ?>

    <div class="row">
        <div class="form-group">            
            <label class="col-md-12 control-label">Question:</label>     
            <div class="col-md-12">
                <textarea class="form-control" rows="6" name="question" id="question" placeholder="Enter question"><?php echo $quesfinder->question; ?></textarea>                                                
            </div>
        </div>

    </div>
    <hr>
<div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label class="col-md-4 control-label">Correct Answer:</label>
                <div class="col-md-8 selectContainer">
                    <select class="form-control" name="correct_ans" id="correct_ans">
                        <option value="">Select ans</option>
                        <option value="TRUE" <?php if ($quesfinder->correct_ans == 'TRUE') echo 'selected'; ?>>True</option>
                        <option value="FALSE" <?php if ($quesfinder->correct_ans == 'FALSE') echo 'selected'; ?>>False</option>                                             
                    </select>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label class="col-md-3 control-label">POINT</label>
                <div class="col-md-9">
                    <input type="text" class="form-control" value="<?php echo $quesfinder->points; ?>" name="points" id="points" placeholder="Enter Points">
                    <input type="hidden"  name="skill_id" id="skill_id_geter" value="<?php echo $quesfinder->skill_tests_id; ?>">                    
                    <input type="hidden" value="<?php echo $quesfinder->id; ?>" name="quesid" id="quesid">
                </div>
            </div>
        </div>

        <div class="col-md-12">  
            <div class="col-md-2 col-md-offset-8">
                <div class="form-group">
                    <button type="button" style="display: none" class="btn btn-info btn-lg pull-right" id="preview" >Preview</button>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <button type="submit" class="btn btn-info btn-lg pull-right" id="save_ques" >Save</button>
                </div>
            </div>

        </div>
    </div>   
</form>

<script>
    $(function () {
        
        $('#tf_type').formValidation({
            framework: 'bootstrap',
            icon: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                question: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }, correct_ans: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }, points: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }, regexp: {
                            message: 'Invalid Input',
                            regexp: /^[0-9\s\-()+\.]+$/
                        }
                    }
                }
            }
        });


    });
</script>