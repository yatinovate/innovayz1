@extends('admin.layout.master')

@section('adminheadscript')
<title>Create Campaign | Admin Dashboard</title>
<link href="{{asset("css/magicsuggest-min.css")}}" rel="stylesheet">
<style>
    .grps  .form-control-feedback {
    /* Adjust feedback icon position */
    right: -15px !important;
}
</style>
@end
@section('content')
<div class="admin_container">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2">
                @include('admin.includes.leftnav')
            </div>
            <div class="col-md-10">
                <div class="user_content">
                    <div class="tab-content">
                        <!--All Users-->
                        <div id="all_users" class="tab-pane fade in active">
                            <div class="row">
                                <h1 class="user_title">Settings : Create Campaign</h1>
                                @include("errors.status")
                                <form role="form" class="form-horizontal" id="camping_form" method="post" action="{{Route("admin.savecampaign")}}">
                                    {{csrf_field()}}
                                    <h4>Step 1:</h4>
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label col-sm-12">Campaign Name</label>
                                                <div class="col-sm-12">
                                                    <input type="text" class="form-control" name="campaign_name" id="campaign_name" placeholder="Campaign Name">
                                                </div>
                                                <div class="clearfix">

                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-md-12">Accessibility</label>
                                                <div class="col-md-12">
                                                    <label class="radio-inline"><input type="radio" value="public" name="accessibility" checked="">All Users</label>
                                                    <label class="radio-inline"><input type="radio" value="skill" name="accessibility">Based On Skill</label>
                                                </div>
                                            </div>
                                            <div class="grps" style="display: none;">
                                                <div class="form-group">
                                                    <div class="col-sm-12">
                                                        <input type="text" id="skillfires" name="skillfires" placeholder="Skills" >
                                                        <input type="hidden" id="skillfires1" name="skillfires1" class="form-control"  >
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label col-md-12">Description</label>
                                                <div class="col-md-12">
                                                    <textarea class="form-control" rows="4" id="description" name="description"></textarea>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <hr>
                                    </div>

                                    <h4>Step 2:</h4>
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label col-md-12">Email Type:</label>
                                                <div class="col-md-12">
                                                    <label class="radio-inline"><input type="radio" value="plain" name="e_type" >Plain Text</label>
                                                    <label class="radio-inline"><input type="radio" value="rich" name="e_type" checked="">HTML</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label col-sm-12">Select Quiz</label>
                                                <div class="col-sm-12">
                                                    <input type="text" id="skillquiz" name="skillquiz" class="form-control" placeholder="Skills" >
                                                    <div class="form-group">
                                                        <label class="control-label col-sm-12">Copy Quiz Link</label>
                                                        <div class="col-sm-12">
                                                            <input type="text" id="skillquiz1" name="skillquiz1" class="form-control">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="control-label col-sm-12">Email Subject</label>
                                                <div class="col-sm-12">
                                                    <input type="text" class="form-control" name="em_sub"id="em_sub" placeholder="Email Subject">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-md-12">Email Body:</label>
                                                <div class="col-md-12">
                                                    <textarea class="form-control" rows="5" id="emailbody" name="emailbody"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12"><br>
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary pull-right">Save</button>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>

            </div>

        </div>
    </div>
    <!-- /.row -->
</div>
@stop
@section('jsfiles')
<script src="<?php echo asset('js/magicsuggest-min.js'); ?>"></script>
<script src="{{asset("js/validation/formvalidation-min.js")}}"></script>
<script src="{{asset("js/validation/bootstrap.js")}}"></script>
<script type="text/javascript" src="//cdn.tinymce.com/4/tinymce.min.js"></script>
<script>
$(document).ready(function () {
    function applyMCE() {
        tinyMCE.init({
            mode: "textareas",
            editor_selector: "tinymce-enabled-message",
            selector: "#emailbody",
            entity_encoding: "raw",
            encoding: "UTF-8",
            menubar: false,
            link_assume_external_targets: true,
            plugins: ["advlist lists link image charmap  anchor"],
            toolbar: " styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist | link image",
            image_dimensions: false,
            setup: function (editor) {
                editor.on('change', function () {
                    tinymce.triggerSave();
                });
            }
        });
    }applyMCE();
    function AddRemoveTinyMce(editorId) {
        if (tinyMCE.get(editorId))
        {
            tinyMCE.EditorManager.execCommand('mceFocus', false, editorId);
            tinyMCE.EditorManager.execCommand('mceRemoveEditor', true, editorId);

        } else {
            tinymce.EditorManager.execCommand('mceAddEditor', false, editorId);
        }
    }

    var ms = $('#skillfires').magicSuggest({
        allowFreeEntries: false,
        maxSelection: 1,
        required: true,
        valueField: 'value',
        displayField: 'label',
        data: '{{Route("admin.skillcampaign")}}',
        ajaxConfig: {
            xhrFields: {
                withCredentials: true
            }
        }
    });
    $(ms).on('selectionchange', function (e, m) {
        var asd = this.getValue();
        $('#camping_form').find('[name="skillfires1"]').val(asd).end().formValidation('revalidateField', 'skillfires1');
    });
     var ms = $('#skillquiz').magicSuggest({
        allowFreeEntries: false,
        maxSelection: 1,
        required: true,
        valueField: 'value',
        displayField: 'label',
        data: '{{Route("admin.getskillcampaign")}}',
        ajaxConfig: {
            xhrFields: {
                withCredentials: true
            }
        }
    });
    $(ms).on('selectionchange', function (e, m) {
        var asd = this.getValue();
        $('#camping_form').find('[name="skillquiz1"]').val(asd);
    });
    $('#camping_form').formValidation({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            campaign_name: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }, description: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }, em_sub: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }, skillfires1: {
                enabled: false,
                excluded: false,
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }
        }
    }).on('change', '[name="accessibility"]', function (e) {
        var evntval = $('#camping_form').find('[name="accessibility"]:checked').val();
        if (evntval == 'skill') {
            $(".grps").show();
            $('#camping_form').data('formValidation').enableFieldValidators('skillfires1', true);
        } else {
            $(".grps").hide();
            $('#camping_form').data('formValidation').enableFieldValidators('skillfires1', false);
        }
    }).on('change', '[name="e_type"]', function (e) {
        var evntval = $('#camping_form').find('[name="e_type"]:checked').val();
        if (evntval == 'rich') {
            
            AddRemoveTinyMce('emailbody');
            //tinyintit();
        } else {
            var content = $.trim(tinyMCE.get('emailbody').getContent());
            var rex = /(<([^>]+)>)/ig;
            AddRemoveTinyMce('emailbody');
            $('#emailbody').val(content.replace(rex, ""));

            //$('#emailbody').val($('#emailbody').text());
        }
    });


});
</script>
@stop
