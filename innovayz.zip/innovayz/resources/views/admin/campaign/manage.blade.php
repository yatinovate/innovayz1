@extends('admin.layout.master')
@section('adminheadscript')
<title>Manage Campaign</title>
<style>
    #PublishModel .modal-header{
        background: #337ab7;
        color: #fff;
    }
    .bg_loader img{
    margin: 10px auto;
    padding: 20px 0;
}
</style>
@end
@section('content')
<div class="admin_container">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2">
                @include('admin.includes.leftnav')
            </div>


            <div class="col-md-10">
                <div class="user_content">
                    <div class="tab-content">
                        <!--All Users-->
                        <div id="all_users" class="tab-pane fade in active">
                            <div class="row">
                                <h1 class="user_title">Campaign : Manage Campaign</h1>
                                @include("errors.status")
                                <table class="table table-bordered table-responsive table-hover table-striped" id="dtable">
                                    <thead>
                                        <tr>
                                            <th scope="col">S.No</th>
                                            <th scope="col">Campaign</th>
                                            <th scope="col">Check</th>
                                            <th scope="col"><a>Publish Status</a></th>
                                            <th scope="col"><a>Edit</a></th>
                                            <th scope="col"><a>Delete</a></th>
                                        </tr>
                                    </thead>
                                    <tbody><?php $cout = 1; ?>
                                        @foreach($campaign as $test)
                                        <tr>
                                            <td>{{$cout}}</td>
                                            <?php $cout++ ?>
                                            <td>{{$test->campaign_name}}</td>     
                                            <td><a  href="{{Route("admin.campaignpreview",["skill_id"=>$test->id])}}">Check</a></td>
                                            @if($test->publish==0)
                                            <td><a href="javascript:;" class="published" data-id="{{$test->id}}">Publish</a></td>
                                            @else
                                            <td><a href="javascript:;" class="published" data-id="{{$test->id}}">Unpublish</a></td>
                                            @endif
                                            @if($test->publish==0)
                                            <td><a href="{{Route("admin.editCampaign", ["campaign-id" =>$test->id])}}">Edit</a></td>
                                            @else
                                            <td><a  class="disabled">Edit</a></td>
                                            @endif
                                            @if($test->publish==0)
                                            <td><a href="{{Route("admin.deleteCampaign", ["campaign-id" =>$test->id])}}">Delete</a></td>
                                            @else
                                            <td><a  class="disabled">Delete</a></td>
                                            @endif
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>

                            </div>
                        </div>

                    </div>
                </div>

            </div>

        </div>
    </div>
    <!-- /.row -->
</div>
<div id="PublishModel" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title text-center">Sending Campaign to Users</h4>
            </div>
            <div class="modal-body">
                <div class='bg_loader text-center'><img src='<?php echo asset('adminRes/img/ajax-loader.gif'); ?>' class='adminloader img-responsive'></div>
            </div>
        </div>

    </div>
</div>
@stop
@section('jsfiles')
<script>
    $(function () {
        
        $(".published").click(function () {
            var btn = $(this);
            var skillid = btn.attr("data-id");
            if($(this).text()=="Publish"){
                 $('#PublishModel').modal({
            backdrop: 'static',
            keyboard: false  // to prevent closing with Esc button (if you want this too)
        });
            }
           
            $.get('{{Route("admin.publishCampaign")}}', {skillid: skillid})
                    .done(function (data) {
                        $('#PublishModel').modal('hide');
                        btn.html(data);
                        window.location.reload(true);
                    }).fail(function () {
                alert("error occured");
            });
        });




    });

</script>
@stop
