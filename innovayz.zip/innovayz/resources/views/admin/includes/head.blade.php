<link rel="shortcut icon" href="{{asset('img/logo.png')}}" />
<link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}">
<link rel="stylesheet" href="{{asset('css/font-awesome.min.css')}}">
<link rel="stylesheet" href="{{asset('adminRes/css/admin.css')}}">
<link rel="stylesheet" href="{{asset('adminRes/css/sidenav.css')}}">
<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
<meta name="csrf-token" content="{{ csrf_token() }}">

@yield('adminheadscript')