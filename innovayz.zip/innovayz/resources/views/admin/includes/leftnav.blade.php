<ul class="nav navbar-nav side-nav">
    <li>
        <a style="cursor: pointer"  data-toggle="collapse" data-target="#user"><i class="fa fa-fw fa-user"></i> Users <i class="fa fa-caret-down"></i></a>
        <ul id="user" class="collapse">
            <li>
                <a href="{{Route("admin.viewonlineUser")}}">Currently Online</a>
            </li>
            <li>
                <a href="{{Route("admin.viewNewUser")}}">Newest</a>
            </li>
            <li>
                <a href="{{Route("admin.adduser")}}">Add New User</a>
            </li>
            <li>
                <a href="{{Route("admin.validateUser")}}">Unvalidated</a>
            </li>
        </ul>
    </li>
    <li>
        <a style="cursor: pointer" data-toggle="collapse" data-target="#demo2"><i class="fa fa-fw fa-dashboard"></i> Skill Test <i class="fa fa-fw fa-caret-down"></i></a>
        <ul id="demo2" class="collapse">
            <li>
                <a href="{{Route("admin.quiz")}}">Add Skill Test</a>
            </li>
            <li>
                <a href="{{Route("admin.manage")}}" >Manage Skill Test</a>
            </li>
        </ul>
    </li>    
    <li>
        <a style="cursor: pointer" data-toggle="collapse" data-target="#advertisemnt"><i class="fa fa-fw fa-buysellads"></i> Advertisements<i class="fa fa-fw fa-caret-down"></i></a>
        <ul id="advertisemnt" class="collapse">            
            <li>
                <a href="{{Route("admin.adblock")}}">Add Advertisements</a>
            </li>
            <li>
                <a href="{{Route("admin.manageadblock")}}">Manage Advertisements</a>
            </li>
        </ul>
    </li>
    <li>
        <a style="cursor: pointer" data-toggle="collapse" data-target="#campaign"><i class="fa fa-fw fa-gamepad"></i> Campaigns <i class="fa fa-fw fa-caret-down"></i></a>
        <ul id="campaign" class="collapse">            
            <li>
                <a href="{{Route("admin.campaign")}}">Add Campaign</a>
            </li>
            <li>
                <a href="{{Route("admin.manageCampaign")}}">Manage Campaign</a>
            </li>
        </ul>
    </li>
    <li>
        <a style="cursor: pointer" data-toggle="collapse" data-target="#demo1"><i class="fa fa-fw fa-wrench"></i> Settings <i class="fa fa-fw fa-caret-down"></i></a>
        <ul id="demo1" class="collapse">            
            <li>
                <a href="{{Route("admin.institute")}}">Unvalidate institute</a>
            </li>
            <li>
                <a href="{{Route("admin.set_skills")}}">Unvalidate skills</a>
            </li>
            <li>
                <a href="{{Route("admin.stream")}}">Unvalidate Stream</a>
            </li>
        </ul>
    </li>
</ul>