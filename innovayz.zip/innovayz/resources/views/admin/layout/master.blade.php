<!DOCTYPE html>
<html>
    <head>
        @include('admin.includes.head')
    </head>
    <body>
        <header>
            @include('admin.includes.header')
        </header>
        <main>
            @yield('content')
        </main>

        <footer>
            @include('admin.includes.footer')
        </footer>
    </body>
</html>
