@extends('admin.layout.master')
@section('adminheadscript')
<title>New User | Admin Dashboard</title>
@end
@section('content')
<div class="admin_container">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2">
                @include('admin.includes.leftnav')
            </div>
            <div class="col-md-10">
                <div class="user_content">
                    <div class="tab-content">
                        <!--All Users-->
                        <div id="all_users" class="tab-pane fade in active">
                            <div class="row">
                                <h1 class="user_title">Users : New Users</h1>
                                <table class="table table-bordered table-responsive">

                                    <tbody>
                                        <?php foreach ($data as $user): ?>
                                            <tr>
                                                <td><img src="{{ asset(Auth::user()->avatar)}}" class="img-thumbnail newuserpic">&nbsp;&nbsp;<?php echo $user->name; ?></td>
                                            </tr>

                                        <?php endforeach; ?>
                                    </tbody>
                                </table>

                                <?php echo $data->links() ?>

                            </div>
                        </div>

                    </div>
                </div>

            </div>

        </div>
    </div>
    <!-- /.row -->
</div>
@stop