@extends('admin.layout.master')
@section('adminheadscript')
<title>Add User | Admin Dashboard</title>
@end
@section('content')
<div class="admin_container">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2">
                @include('admin.includes.leftnav')
            </div>
            <div class="col-md-10">
                <div class="user_content">
                    <div class="tab-content">
                        <!--All Users-->
                        <div id="all_users" class="tab-pane fade in active">
                            <div class="row">

                                <h1 class="user_title">Users : Add New Users</h1>
                                <div class="col-md-6 col-md-offset-3">
                                    @include("errors.status")
                                    <form role="form" id="form_pad" method="post" action="{{Route("admin.saveadduser")}}">
                                        {{csrf_field()}}
                                        <div class="form-group">
                                            <input type="text" name="full_name" id="full_name" class="form-control input-lg" placeholder="Full Name" tabindex="3">                                            
                                        </div>
                                        <div class="form-group">
                                            <input type="email" name="email" id="email" class="form-control input-lg" placeholder="Email Address" tabindex="4">                                            
                                        </div>
                                        <div class="row">
                                            <div class="col-xs-12 col-sm-6 col-md-6">
                                                <div class="form-group">
                                                    <input type="password" name="password" id="password" class="form-control input-lg" placeholder="Password" tabindex="6">
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-sm-6 col-md-6">
                                                <div class="form-group">
                                                    <input type="password" name="password_confirmation" id="password_confirmation" class="form-control input-lg" placeholder="Confirm Password" tabindex="6">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="radio col-sm-6 col-md-10">
                                                <label class="radio-inline">
                                                    <input type="radio" name="optradio" checked="" value="students">Student
                                                </label>
                                                <label class="radio-inline">
                                                    <input type="radio" name="optradio" value="teachers">Teacher
                                                </label>
                                                <label class="radio-inline">
                                                    <input type="radio" name="optradio" value="colleges">College
                                                </label>
                                                <label class="radio-inline">
                                                    <input type="radio" name="optradio" value="admin">Admin
                                                </label>
                                            </div>

                                        </div>                                        
                                        <div class="row">
                                            <div class="col-xs-12 col-md-3">
                                                <input type="submit" value="Add" class="btn btn-primary btn-block btn-lg" id="add_userbtn" ></div>

                                        </div>
                                    </form>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>

            </div>

        </div>
    </div>
    <!-- /.row -->
</div>
@stop
@section('jsfiles')

<script src="{{asset("js/validation/formvalidation-min.js")}}"></script>
<script src="{{asset("js/validation/bootstrap.js")}}"></script>
<script>
$(function ()
{
    FormValidation.Validator.password = {
        validate: function (validator, $field, options) {
            var value = $field.val();
            if (value === '') {
                return true;
            }

            if (value.length < 8) {
                return false;
            }
            if (value === value.toLowerCase()) {
                return false;
            }
            if (value === value.toUpperCase()) {
                return false;
            }
            if (value.search(/[0-9]/) < 0) {
                return false;
            }

            return true;
        }
    };
    $('#form_pad').formValidation({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            full_name: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }, regexp: {
                        regexp: /^[a-z\s]+$/i,
                        message: 'The full name can consist of alphabetical characters and spaces only'
                    }
                }
            }, email: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }, emailAddress: {
                        message: 'The input is not a valid email address'
                    }
                }
            }, password: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }, password: {
                        message: 'Must be more than 8 characters including upper case,lower case & digit'
                    }
                }
            }, password_confirmation: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    },
                    identical: {
                        field: 'password',
                        message: 'The password and its confirm are not the same'
                    }, password: {
                        message: 'Must be more than 8 characters including upper case,lower case & digit'
                    }
                }
            }
        }
    });


});
</script>
@stop