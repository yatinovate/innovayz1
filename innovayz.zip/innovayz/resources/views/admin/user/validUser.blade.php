@extends('admin.layout.master')

@section('adminheadscript')
<title>Unvalidate User | Admin Dashboard</title>
@end
@section('content')
<div class="admin_container">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2">
                @include('admin.includes.leftnav')
            </div>
            <div class="col-md-10">
                <div class="user_content">
                    <div class="tab-content">
                        <!--All Users-->
                        <div id="all_users" class="tab-pane fade in active">
                            <div class="row">
                                <h1 class="user_title">Users : Unvalidate User</h1>
                                <table class="table table-bordered table-responsive table-hover table-striped" id="dtable">
                                    <thead>
                                        <tr>
                                            <th scope="col">
                                                <input type="checkbox" class="checkall" />
                                            </th>
                                            <th scope="col">Users</th>
                                            <th scope="col"><a href="#" class="resendalluser" title="dtable">Resend Validation</a></th>
                                            <th scope="col"><a href="#" class="validateeall" title="dtable">Validate</a></th>
                                            <th scope="col">
                                                <a href="#" class="deleteall" title="dtable">Delete</a></th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php foreach ($alluser as $user): ?>      
                                            <tr>
                                                <td>
                                                    <input type="checkbox" class="checkbox sub_chk" data-id="<?php echo $user->id; ?>" />
                                                </td>
                                                <td><?php echo $user->email; ?><br>
                                                    <small><?php echo $user->created_at; ?></small>
                                                </td>                                                
                                                <td><a href="javascript:;" class="resend_validation" data-id="<?php echo $user->id; ?>">Resend validation</a></td>
                                                <td><a href="javascript:;" class="validate_single" data-id="<?php echo $user->id; ?>">validate</a></td>
                                                <td>
                                                    <a href="#" class="delete_single" data-id="<?php echo $user->id; ?>">delete</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>

            </div>

        </div>
    </div>
    <!-- /.row -->
</div>
@stop
@section('jsfiles')
<script>
    $(document).ready(function () {


        $('.checkall').on('click', function () {
            var $this = $(this), checked = $this.prop('checked'), cbs = $this.closest('table').children('tbody').find('.checkbox');
            cbs.prop('checked', checked);
            cbs.closest('tr').toggleClass('selected', checked);
        });
        $('tbody tr').on('click', function () {
            var $this = $(this).toggleClass('selected');
            $this.find('.checkbox').prop('checked', $this.hasClass('selected'));
            if (!$this.hasClass('selected')) {
                $this.closest('table').children('thead').find('.checkall').prop('checked', false);
            }
        });
        $('.delete_single').on('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            var $this = $(this), c = confirm('Are you sure you want to delete this row?');
            if (!c) {
                return false;
            }
            $.ajax({
                type: "POST",
                url: '{{Route("admin.deleteUser")}}',
                data: {userid: $(this).attr('data-id')},
                datatype: 'JSON',
                success: function (data) {
                    location.reload();
                },
                error: function (xhr) {
                    console.log(xhr);
                }
            });
        });

        $('.deleteall').on('click', function (e) {

            var allVals = [];
            $(".sub_chk:checked").each(function () {
                allVals.push($(this).attr('data-id'));
            });
            //alert(allVals.length); return false;  
            if (allVals.length <= 0)
            {
                alert("Please select row.");
            } else {
                //$("#loading").show(); 
                WRN_PROFILE_DELETE = "Are you sure you want to delete this row?";
                var check = confirm(WRN_PROFILE_DELETE);
                if (check == true) {
                    var join_selected_values = allVals.join(",");

                    $.ajax({
                        type: "POST",
                        url: '{{Route("admin.deleteAll")}}',
                        cache: false,
                        data: 'ids=' + join_selected_values,
                        success: function (response)
                        {
                            location.reload();
                        }
                    });
                }
            }
        });


        $('.validate_single').on('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            var $this = $(this), c = confirm('Are you sure you want to validate this row?');
            if (!c) {
                return false;
            }
            $.ajax({
                type: "POST",
                url: '{{Route("admin.validatesingle")}}',
                data: {userid: $(this).attr('data-id')},
                datatype: 'JSON',
                success: function (data) {
                    location.reload();
                },
                error: function (xhr) {
                    console.log(xhr);
                }
            });
        });

        $('.validateeall').on('click', function (e) {

            var allVals = [];
            $(".sub_chk:checked").each(function () {
                allVals.push($(this).attr('data-id'));
            });
            //alert(allVals.length); return false;  
            if (allVals.length <= 0)
            {
                alert("Please select row.");
            } else {
                //$("#loading").show(); 
                WRN_PROFILE_DELETE = "Are you sure you want to validate this row?";
                var check = confirm(WRN_PROFILE_DELETE);
                if (check == true) {
                    var join_selected_values = allVals.join(",");

                    $.ajax({
                        type: "POST",
                        url: '{{Route("admin.validateAll")}}',
                        cache: false,
                        data: 'ids=' + join_selected_values,
                        success: function (response)
                        {
                            location.reload();
                        }
                    });
                }
            }
        });
        
        
        $('.resend_validation').on('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            var $this = $(this), c = confirm('Are you sure you want to resend email?');
            if (!c) {
                return false;
            }
            $.ajax({
                type: "POST",
                url: '{{Route("admin.resend")}}',
                data: {userid: $(this).attr('data-id')},
                datatype: 'JSON',
                success: function (data) {
                    alert("Email sent");
                },
                error: function (xhr) {
                    console.log(xhr);
                    alert("Error "+xhr);
                }
            });
        });

        $('.resendalluser').on('click', function (e) {

            var allVals = [];
            $(".sub_chk:checked").each(function () {
                allVals.push($(this).attr('data-id'));
            });
            //alert(allVals.length); return false;  
            if (allVals.length <= 0)
            {
                alert("Please select row.");
            } else {
                //$("#loading").show(); 
                WRN_PROFILE_DELETE = "Are you sure you want to resend to selected rows?";
                var check = confirm(WRN_PROFILE_DELETE);
                if (check == true) {
                    var join_selected_values = allVals.join(",");

                    $.ajax({
                        type: "POST",
                        url: '{{Route("admin.resendAll")}}',
                        cache: false,
                        data: 'ids=' + join_selected_values,
                        success: function (response)
                        {
                            alert("Email sent");
                        },
                error: function (xhr) {
                    console.log(xhr);
                    alert("Error "+xhr);
                }
                    });
                }
            }
        });



    });
</script>
@stop


