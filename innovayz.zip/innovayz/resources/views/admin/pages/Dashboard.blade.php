@extends('admin.layout.master')

@section('adminheadscript')
<title>Admin Dashboard</title>
@end
@section('content')
<div class="admin_container">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2">
                @include('admin.includes.leftnav')
                </div>


            <div class="col-md-10">
                <div class="user_content">
                    <div class="user_heading">
                        <!-- Page Heading -->
                        <div class="col-md-4">
                            <div class="header-tile">
                                <p><i class="fa fa-user"></i>&nbsp;&nbsp;Online Users
                                    &nbsp;&nbsp;<span class="badge">{{$ouser}}</span></p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="header-tile">
                                <p><i class="fa fa-user"></i>&nbsp;&nbsp;New Users
                                    &nbsp;&nbsp;<span class="badge">{{$newuser}}</span></p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="header-tile">
                                <p><i class="fa fa-user"></i>&nbsp;&nbsp;Total Visitors
                                    &nbsp;&nbsp;<span class="badge">{{$visitor->count}}</span></p>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="tab-content">
                        <!--All Users-->
                        <div id="all_users" class="tab-pane fade in active">
                            <div class="row">
                                <h1 class="user_title">Users : All Users</h1>
<table class="table table-hover table-bordered">
    <thead>
        <tr>
            <th>Name</th>

            <th>Email</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($alluser as $user) : ?>
            <tr>
                <td> <?php echo $user->name; ?></td>
                <td> <?php echo $user->email; ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
                            </div>
                        </div>
                       
                    </div>
                </div>

            </div>

        </div>
    </div>
    <!-- /.row -->
</div>
@stop
@section('jsfiles')
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<script src="{{asset("adminRes/js/fileuploader.js")}}"></script>
<script src="{{asset("adminRes/js/jquery.cookie.js")}}"></script>
<script src="{{asset("adminRes/js/admin.js")}}"></script>


@stop