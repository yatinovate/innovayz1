@extends('admin.layout.master')
@section('content')
<div class="container">
            <div class="row">
                <div class="col-md-4 col-md-offset-4">
                    
                    <form class="form-horizontal login_form" action="{{route('adminlogin')}}" method="post">
                        <h2 class="heading"> Admin Login </h2>
                        @if (count($errors) > 0)
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                        @endif
                        <div class="form-group">
                            <label for="email">Email address:</label>
                            <input type="email" class="form-control" name="username" id="email">
                        </div>
                        <div class="form-group">
                            <label for="pwd">Password:</label>
                            <input type="password" class="form-control" id="pwd" name="pass">
                        </div>
                        <div class="form-group">
                            <input type="hidden" name="_token" value="{{csrf_token()}}">
                        <button type="submit" class="btn btn-default btn-lg" name="login">Login</button>
                        </div>
                        
                    </form>
                </div>
            </div>
        </div>

@stop