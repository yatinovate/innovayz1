@extends('layouts.master')
@section('headscript')
<link rel="stylesheet" href="{{asset("css/search.css")}}">
<title>Search | Innovayz</title>
@endsection

@section('content')
<div class="searchRefine">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2">
                <h2>Refine Results : </h2>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <select class="form-control" id="area_select">
                        <option value="null">Area of Interest</option>
                    </select>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <select class="form-control" id="loc_select">
                        <option value="null">Location</option>
                    </select>
                </div>
            </div>

            <div class="col-md-2 text-right">
                <a id="refreshsearc" class="btn btn-info">Refresh <i class="fa fa-refresh"></i></a>
            </div>
        </div>
    </div>
</div>

<div class="searchresult">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="resultwrap">
                    @if(count($sql_res))
                    @foreach ($sql_res as $user)
                    <div class="row resultwrap_item">
                        <div class="">
                            <div class="col-md-3 text-center">
                                <img src="{{asset($user->avatar)}}" alt="{{$user->name}}" class="img-responsive" />
                            </div>
                            <div class="col-md-9">
                                <a href="{{ Route("profile.index",["user-id"=>$user->id,'user-name'=>$user->name])}}" class="search_title">{{ $user->name}} <p class="usertype">( {{ substr($user->user_type, 0, -1)}} )</p></a>
                                <ul class="araa">
                                    @foreach ($user->user_area as $error)
                                    <li><a>{{ \App\Models\User\AreaIntrest::find($error->area_int->id)->area_intrest }}</a></li>
                                    @endforeach
                                </ul><br>

                                <?php
                                if ($user->user_type == "students") {
                                    if ($user->profile_status == "step1") {
                                        $abt = "No About us";
                                    } else {
                                        $abt = $user->student->describe_yourself;
                                    }
                                } elseif ($user->user_type == "teachers") {
                                    if ($user->profile_status == "step1") {
                                        $abt = "No About us";
                                    } else {
                                        $abt = $user->teacher->describe_yourself;
                                    }
                                } elseif ($user->user_type == "colleges") {
                                    $abt = $user->college->breif;
                                }
                                ?>

                                <p class="description">{{$abt}}</p>

                                <div class=" pull-right"> 
                                    
                                    @if(Auth::check())
                                    <?php
                                    $verify = \App\Models\Profile\Followers::where('user_id', Auth::user()->id)->where('followers_id', $user->id)->first();
                                    if ($verify) {
                                        ?>
                                        <a href="{{Route("follow",["user-id"=>$user->id])}}"  class="btn btn-info">Unfollow</a>
                                        <?php
                                    } else {
                                        ?>
                                        <a href="{{Route("follow",["user-id"=>$user->id])}}"  class="btn btn-info">Follow</a>
                                    <?php } ?>
                                    
                                    @endif
                                    <a class="btn btn-info" href="{{Route("profile.index",["user-id"=>$user->id,'user-name'=>$user->name,"message"=>"true"])}}">Message</a>
                                </div>


                            </div>
                        </div>

                    </div>
                    @endforeach
                    @else
                    <p>No , search record found</p>
                    @endif


                </div>
            </div>
            <div class="col-md-3 col-md-offset-1">
                @include("includes.adblock")
            </div>
        </div>

    </div>
</div>
</div>






@stop

@section('jsfiles')
<script type="text/javascript">
    $(function ()
    {
        /* $.ajax({
         url: '{{Route("search.item")}}',
         type: 'GET',
         data: {string: '{{$para}}'},
         success: function (data) {
         $(".resultwrap").html(data);
         },
         error: function (data) {
         $(".resultwrap").html('<div class="bg_loader text-center">Select Question type</div>');
         }
         });*/
         $.ajax({
         url: '{{Route("search.item")}}',
         type: 'GET',
         data: {string: '{{$para}}',category: '{{$category}}'},
         success: function (data) {
             var areatag="";var loctag="";
             $.each(data.area, function(key,value) {
                 areatag=areatag+"<option value="+value.id+">"+value.areaname+"</option>";
             });
             $.each(data.location, function(key,value) {
                 loctag=loctag+"<option value="+value.id+">"+value.areaname+"</option>";
             });
         $("#area_select").html(areatag);
         $("#loc_select").html(loctag);
         },
         error: function (data) {
         $(".resultwrap").html('<div class="bg_loader text-center">Error Occured</div>');
         }
         });
         
        $("#area_select").change(function () {
            var areal = $(this).val();
            $.get('{{Route("search.skillitem")}}', {areau: areal, string: '{{$para}}',category: '{{$category}}'}, function (data) {
                $(".resultwrap").html(data);
            });
        });
        
        $("#loc_select").change(function () {
            var areal = $(this).val();
            $.get('{{Route("search.locitem")}}', {areau: areal, string: '{{$para}}',category: '{{$category}}'}, function (data) {
                $(".resultwrap").html(data);
            });
        });
        $("#refreshsearc").click(function(){
            location.reload();
        });
    });
</script>


@stop