@extends('layouts.master')
@section('headscript')
<link rel="stylesheet" href="{{asset("css/search.css")}}">
<link href="{{asset("css/magicsuggest-min.css")}}" rel="stylesheet">
@endsection

@section('content')
<div class="searchRefine">
    <div class="container">
        <div class="row">
            <form action="chk" method="POST" enctype="multipart/form-data">
                <input type="text" id="area_interest" name="area" value="" />
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                <input type="submit" value="save" />
            </form>
        </div>
        
    </div>
</div>








@stop

@section('jsfiles')
<script src="<?php echo asset("js/magicsuggest-min.js");?>"></script>
<script type="text/javascript">
$(function ()
{
   $('#area_interest').magicSuggest({
        required: true,
        data: '<?php echo URL::to("areaintreset");?>',
        ajaxConfig: {
            xhrFields: {
                withCredentials: true
            }
        }
    });

});
</script>



@stop