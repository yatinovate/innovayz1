@if(count($user))
@foreach ($user as $guser)
<?php
$user= App\Models\User::find($guser);
?>
<div class="row resultwrap_item">
    <div class="">
        <div class="col-md-3 text-center">
            <img src="{{asset($user->avatar)}}" alt="{{$user->name}}" class="img-responsive" />
        </div>
        <div class="col-md-9">
            <a href="{{ Route("profile.index",["user-id"=>$user->id,'user-name'=>$user->name])}}" class="search_title">{{ $user->name}} (<p class="usertype">{{ substr($user->user_type, 0, -1)}}</p>)</a>
            <ul class="araa">
                @foreach ($user->user_area as $error)
                <li><a>{{ \App\Models\User\AreaIntrest::find($error->area_int->id)->area_intrest }}</a></li>
                @endforeach
            </ul><br>

            <?php
            if ($user->user_type == "students") {
                if ($user->profile_status == "step1") {
                    $abt = "No About us";
                } else {
                    $abt = $user->student->describe_yourself;
                }
            } elseif ($user->user_type == "teachers") {
                if ($user->profile_status == "step1") {
                    $abt = "No About us";
                } else {
                    $abt = $user->teacher->describe_yourself;
                }
            } elseif ($user->user_type == "colleges") {
                $abt = $user->college->breif;
            }
            ?>

            <p class="description">{{$abt}}</p>

            <div class=" pull-right"> 
                                    
                                    @if(Auth::check())
                                    <?php
                                    $verify = \App\Models\Profile\Followers::where('user_id', Auth::user()->id)->where('followers_id', $user->id)->first();
                                    if ($verify) {
                                        ?>
                                        <a href="{{Route("follow",["user-id"=>$user->id])}}"  class="btn btn-info">Unfollow</a>
                                        <?php
                                    } else {
                                        ?>
                                        <a href="{{Route("follow",["user-id"=>$user->id])}}"  class="btn btn-info">Follow</a>
                                    <?php } ?>
                                    
                                    @endif
                                    <a class="btn btn-info" href="{{Route("profile.index",["user-id"=>$user->id,'user-name'=>$user->name,"message"=>"true"])}}">Message</a>
                                </div>


        </div>
    </div>

</div>
@endforeach
@else
<p>No , search record found</p>
@endif
