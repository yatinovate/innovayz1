@extends('layouts.master')
@section('headscript')
<meta name="_token" content="{{ csrf_token() }}">
<link rel="stylesheet" href="{{asset("css/profile.css")}}">
@stop
@section('content')

<div class="head-detail">
    <div class="container">

        <div class="row">
            
            
        </div>
    </div>
</div>

<div class="head_nav">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 col-md-offset-3" enctype="multipart/form-data" >
                
                <form action="testing123" method="post" enctype="multipart/form-data">
                    Select image to upload:
                    <input type="file" name="fileToUpload" id="fileToUpload">
                    <input type="hidden" name="_token" value="{{csrf_token()}}">
                    <input type="submit" value="Upload Image" name="submit">
                </form>
                <!-- Centered Pills -->
                
            </div>
        </div>
    </div>
</div>


@stop



@section('jsfiles')

@endsection




