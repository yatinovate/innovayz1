<div class="cd-user-modal-container"> <!-- this is the container wrapper -->
    <ul class="cd-switcher">
        <li><a href="#">Sign in</a></li>
        <li><a href="#">New account</a></li>
    </ul>

    <div id="cd-login"> <!-- log in form -->                       

        <div class="social_icons">
            <p class="sign_teft"> Sign in with : </p>
            <a class="icon-link round-corner facebook fill" href="{{ url('/social/auth/redirect', ['facebook']) }}"><i class="fa fa-facebook"></i></a>
            <a class="icon-link round-corner linkedin fill" href="{{ url('/social/auth/redirect', ['linkedin']) }}"><i class="fa fa-linkedin"></i></a>
            <a class="icon-link round-corner google fill"  href="{{ url('/social/auth/redirect', ['google']) }}"><i class="fa fa-google"></i></a>
        </div>
        <h4 class="othercourse">OR</h4>
        
        <form id="login_form" method="post" action="{{URL::to("login")}}" class="form-horizontal cd-form">
            {{ csrf_field() }}
            @include("errors.loginerror")
            <div class="form-group fieldset">                
                <input type="text" class="form-control" id="email" name="email" placeholder="Username" />
            </div>
            <div class="form-group fieldset">
                <input type="password" class="form-control full-width" id="password" name="password" placeholder="Password" />  
            </div>
            <div class="form-group fieldset">
                <div class="checkbox">
                    <label><input type="checkbox" name="remember_me" value="1"/>Remember me</label>
                </div>
            </div>
            <div class="form-group fieldset">
                <div class="pull-right log_checkbox">
                    <?php
                    if (session()->has('url.intended')) {
                        $urlinte = session('url.intended');
                    }
                    ?>
                    <input type="hidden" name="intended" value="{{ isset($urlinte) ? $urlinte : '' }}">
                    <button type="submit" class="btn btn-default sub_btn pull-right" id="signinbtn" value="Sign In">Sign In</button>
                </div>
            </div>
            <div class="clearfix"></div>
        </form>

        <p class="cd-form-bottom-message"><a id="forgetformpop" style="cursor: pointer">Forgot your password?</a></p>
        <!-- <a href="#0" class="cd-close-form">Close</a> -->
    </div> <!-- cd-login -->

    <div id="cd-signup"> <!-- sign up form -->
        <form id="signup_form" method="post" class="form-horizontal cd-form" action="{{Route("register")}}">
            {{ csrf_field() }}
            @include("errors.signuperror")
            <div class="form-group fieldset">                
                <input type="text" class="form-control" name="name" placeholder="Full Name" >
            </div>
            @if(isset($usermail))
            <div class="form-group fieldset">
                <input class="form-control full-width  has-border" type="email" placeholder="E-mail" name="email" value="{{$usermail}}" readonly="">
                </div>
                @else
                <div class="form-group fieldset">
                    <input class="form-control full-width  has-border" type="email" placeholder="E-mail" name="email" >
                </div>
                
                @endif
            
            <div class="form-group fieldset">
                <input class="form-control full-width  has-border" id="password" type="password"  placeholder="Password" name="password" >
            </div>
            <div class="form-group fieldset">
                <input class="form-control full-width  has-border" id="confirmpass" type="password"  placeholder="Confirm Password" name="confirmpass" >
            </div>
            <div class="form-group fieldset">
                <div class="row">
                    <div class="col-md-2">
                        <b style="color:#000;">User</b>
                    </div>
                    <div class="col-md-10">
                        <div class="form-inline">      
                            <div class="col-md-4">
                                <input type="radio" name="utype" value="students" />
                                <label class="radio_label">Student</label>
                            </div>
                            <div class="col-md-4">
                                <input type="radio" name="utype" checked="checked" value="teachers"/>
                                <label class="radio_label">Teacher</label>
                            </div>
                            <div class="col-md-4">

                                <input type="radio" name="utype" value="colleges" />
                                <label class="radio_label">College</label>
                            </div>
                        </div>
                    </div>
                </div>              
            </div>
            <div class="form-group fieldset">
                <div class="checkbox-inline selectContainer">
                    <input type="checkbox" name="u_check" class="checkbox" value="1"  />
                    <label class="term_label">By joining, you agree to the <a target="_blank"  href="{{Route("terms")}}"> Terms and Policy</a> of Innovayz</label>
                </div>
            </div>
            <div class="fieldset text-right">
                @if(isset($invitaioncode))
                <input type="hidden" name="invitaion" value="{{$invitaioncode}}"  />
                @else
                <input type="hidden" name="invitaion" value=""  />
                @endif
                <button type="submit" class="btn btn-info btn-lg" value="Sign up">Sign up</button>
            </div>           
        </form>

        <!-- <a href="#0" class="cd-close-form">Close</a> -->
    </div> <!-- cd-signup -->

    <div id="cd-reset-password"> <!-- reset password form -->
        <p class="cd-form-message">Lost your password? Please enter your email address. You will receive a link to create a new password.</p>
        <form id="forget_form" method="post" class="form-horizontal cd-form" action="{{Route("forget-password")}}">
            @include("errors.forgeterror")
            {{ csrf_field() }}
            <div class="form-group fieldset">
                <input type="email" class="form-control full-width  has-border" id="reset-email" name="resetpass" placeholder="Enter your Email id">
            </div>

            <div class="form-group fieldset">
                <div class="col-sm-6 pull-right log_checkbox">
                    <button type="submit" class="btn btn-default sub_btn pull-right" id="forgetbtn" name="signup1" value="Reset password">Reset password</button>
                </div>
            </div>
        </form>

        <p class="cd-form-bottom-message"><a id="backtologin" href="#">Back to log-in</a></p>
    </div> <!-- cd-reset-password -->
    <a href="#" class="cd-close-form">Close</a>
</div> <!-- cd-user-modal-container -->
