@extends('layouts.master')

@section('headscript')
<link rel="stylesheet" href="{{asset("css/complteprofile.css")}}">
<title>Set New Password | Innovayz</title>
@endsection
@section('content')
<section class="comprofile">
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default panel-primary">
                    <div class="panel-heading">
                        <h2 class="text-center">Change Your Password :</h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="panel-body">
                        <div class="col-md-8 col-md-offset-2">
                            
                        <form id="tprofile_Form" method="post" class="form-horizontal" action="{{route("setpassword")}}">
                            {{ csrf_field() }}
                                <div class="form-group">
                                    <label class="control-label col-sm-12">New Password <span>*</span></label>
                                    <div class="col-sm-12">
                                        <input type="password" class="form-control"  name="password" placeholder="Combination of upper,lower case & digit" />
                                    </div>
                                </div>
                            <div class="form-group">
                                    <label class="control-label col-sm-12">Confirm Password <span>*</span></label>
                                    <div class="col-sm-12">
                                        <input type="password" class="form-control"  name="password_confirm" placeholder="Enter password again" />
                                    </div>
                                </div>
                            <input type="hidden" name="passtoken" value="{{$token}}">
                            <input type="hidden" name="email" value="{{$email}}">
                            
                            <button type="submit" class="btn btn-info pull-right" >Change Password</button>
                        </form>
                    </div>
                    </div>
                    
                </div>
            </div>

        </div>
    </div>
</section>

@endsection


@section('jsfiles')
<script>
    $(function(){
        $('#tprofile_Form').formValidation({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            password: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    },password: {
                        message: 'Must be more than 8 characters including upper case,lower case & digit'
                    }
                }
            }, password_confirm: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    },
                    identical: {
                        field: 'password',
                        message: 'The password and its confirm are not the same'
                    },password: {
                        message: 'Must be more than 8 characters including upper case,lower case & digit'
                    }
                }
            }
        }
    }); 
    });
</script>
@endsection
