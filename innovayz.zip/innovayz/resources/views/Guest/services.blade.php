@extends('layouts.master')
@section('headscript')
<title>Welcome | Innovayz</title>
<style>
    body{
        background: #fff;
    }
    .service_wrap{
        margin: 80px 0;
    }
    .service_wrap .service_icon i{
        background: #337ab7;
        width: 150px;
        height: 150px;
        font-size: 100px;
        color: #fff;
        border-radius: 100%;
        text-align: center;
        line-height: 150px;
    }
    .service_wrap .content_item{
        margin: 20px 0;
        border-bottom: 1px solid #f2f2f2;
        padding: 40px 0;
    }
    
    .service_wrap .content_item:last-child{
        border-bottom: none;
    }
    .service_wrap .content_item h3{
        font-weight: bold;
        color: #337ab7;
        font-size: 22px;
        line-height: 39px;
        font-family: 'Vollkorn', serif;
    }
    .service_wrap .content_item p{
        color: #777;
        font-size: 14px;
        line-height: 27px;
        font-family: 'open sans', sans-serif;
    }
</style>
<link href="https://fonts.googleapis.com/css?family=Vollkorn" rel="stylesheet">
@endsection

@section('content')


<section class="service_wrap">
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                
        <div class="content_item" id="profile">
            <div class="row">
                <div class="col-md-2">
                    <div class="service_icon">
                        <i class="fa fa-user"></i>
                    </div>
                </div>
                <div class="col-md-10">
                    <div class="service_content">
                        <h3>Create your profile, update your details and expand your network</h3>
                        <p>Signing up for a profile is completely free. You can provide your personal and academic details, and as you take skill tests,
                            your score will grow and be displayed on our site, where educational institutions can see it. You can also earn rewards by
                            participating in Challenges [hyperlink], which will boost your rank. Teachers can expand their network and host virtual classrooms
                            for their students.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="content_item" id="Library">
            <div class="row">
                <div class="col-md-10">
                    <div class="service_content">
                        <h3>Upload useful resources, and browse through resources submitted by our users.</h3>
                        <p>Education is a tool – and a powerful one, at that. If you crave learning, let nothing stop you! Here are a number of free 
                            resources from around the internet, where you can read and learn to enrich your knowledge, all for free. These resources 
                            have been submitted by our students. If you have any resources, you can upload them here, to help others gain knowledge.
                        </p>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="service_icon">
                        <i class="fa fa-book"></i>
                    </div>
                </div>
                
            </div>
        </div>
        <div class="content_item" id="SkillTest">
            <div class="row">
                <div class="col-md-2">
                    <div class="service_icon">
                        <i class="fa fa-lock"></i>
                    </div>
                </div>
                <div class="col-md-10">
                    <div class="service_content">
                        <h3>Take our specially designed skill tests, to discover your skills and compare your score.</h3>
                        <p>
                            These tests are designed to help you discover your skills, and in which areas they lie. Browse through our collection of 
                            tests, take whichever one you like, and check your results to find out what your strong points are. If you have any
                            questions, you can head to the Community [hyperlink], where expert Uddeshya members will answer them for you.
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="content_item" id="Questionnaire">
            <div class="row">
                <div class="col-md-10">
                    <div class="service_content">
                        <h3>Post questions, and get them answered by experts in the field.</h3>
                        <p>
                            If you have any academic questions, you can post them here. Qualified experts (according to online score) will go through 
                            them and provide an answer as soon as possible. Other Uddeshya users can also post answers to your questions. But go 
                            through our bank of questions first, to see if your question has already been asked and answered.
                        </p>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="service_icon">
                        <i class="fa fa-question"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="content_item" id="Share">
            <div class="row">
                <div class="col-md-2">
                    <div class="service_icon">
                        <i class="fa fa-share-alt"></i>
                    </div>
                </div>
                <div class="col-md-10">
                    <div class="service_content">
                        <h3>Share</h3>
                        <p>
                            Share the tests with your friends! Because like happiness, knowledge increases when it’s distributed.
                        </p>
                    </div>
                </div>
            </div>
        </div>
            </div>
        </div>
       <!-- 
        <div class="content_item">
            <div class="row">
                <div class="col-md-2">
                    <div class="service_icon">
                        <i class="fa fa-lock"></i>
                    </div>
                </div>
                <div class="col-md-10">
                    <div class="service_content">
                        <h3>Take challenges posted by educational institutions, and earn rewards.</h3>
                        <p>
                            These challenges have been posted by renowned educational institutions and coaching centres across India, and are free for 
                            a limited period. They are designed by top-notch trainers and professors, and if you get a good percentage, you earn rewards.
                            Try them out, to see where you stand and to get better!
                        </p>
                    </div>
                </div>
            </div>
        </div>-->

        


    </div>
</section>
@stop

@section('jsfiles')
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
<script>
    $(function () {
$(window).load(function(){
    var hash = location.hash.substr(1);
    var $anchor = "#"+hash;
        $('html, body').stop().animate({
            scrollTop: ($($anchor).offset().top -190)
        }, 1250, 'easeInOutExpo');
});
    });
</script>

@stop