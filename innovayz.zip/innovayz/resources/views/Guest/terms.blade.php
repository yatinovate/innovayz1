@extends('layouts.master')

@section('content')

<div class="terms_condition">
    <div class="container">
        <div class="row">
            <div class="home_title">
                <h2>General Terms :</h2>
            </div>
            <p>
                Read all ours terms below moreover we can change our terms at any time without any prior notice. And management decision will be final in any legal issue.
            </p><br>
            <div class="home_title">
                <h2>Terms Of Service :</h2>
            </div>
            <p>
                Binary theme  provide bootstrap themes, asp .net themes , html themes, photos,  tutorials, etc. that can be downloaded for free.
                You can use our services for free to download content.
                You must not use our themes and contents that we provide to download for illegal or unethical purpose.
                We do not claim all content which we provide is fully ours, we can use other authors free/open source content and provide you to download. The original authors hold right of their work and you have to check their licenses for usage.

            </p>







            Privacy Policy :

            Your Privacy is important to us. We assure you that we do not sell your information to any third party in any circumstances unless any law / legal body requires to do so.

            Disclaimer  &  Important Info:

            We try to use free / opensource resources / plugins for our templates, still please check respective plugin/resource licenses for Personal /commercial use. Whereas our specific code/work is free to use for personal and professional/commercial use.
            If you/user/any person  found any content on this website that violates any law or have any legal issues please contact us. We will remove that content after review.
            All images/photos we used if belongs to other authors, then that photos/images are the property of other authors and if any one use it , then the person( using that image) should ask for proper license from the original author or buy that image from original author.
            We kept original authors links in there respective file/works or give credits on our pages. If any author want to remove there work from our website please contact us (via contact page) or mail us at info@binarytheme.com
            We use and thank to other authors whose plugins or resources we used to power our templates/themes . And we give credits to authors. Please write us if you found your code used inappropriately. We remove or change code to make it proper. Thanks for using our website. Thanks to all authors whose codes we use and love.
            We use images that  are free to use , if you or anyone found any image improperly used then please write us , we will remove that image if found illegally used.
            All Posts/templates are posted/uploaded by independent authors,  if you find any legal issues  then please contact us via contact us page or mail us at info@binarytheme.com we will remove that post and ban that author after review.

            License & Credits  

            License

            -Our Work is opensource and can be used for commercial and personal use . but please give us credits. That will help us to stay in this world . So please stay Fair. Thanks

            -Although we use opensource codes/ resources but still please check all plugins and other authors license if you are using for commercial purpose.

            -If any of you want to write about us then please links to our posts. This would be a help also which will let us stay in this world.

            Credits

            -First of all we like to give credits to all authors whose work we integrate to power our template .  We thanks all jquery plugin authors , bootstrap authors (Mark Otto and Jacob Thornton)  as we take inspiration from there works in our codes, font awesome author,etc. who allow opensource use of there work.

            -We left author headers in there work. More over if any author have any issue than contact us at  info@binarytheme.com

            Note: If you are a blogger or a website owner and you are linking to our content or writing about us. Please link the post or page URL of our website at least once. Don’t Link the zip files directly without mentioning our URL at least once. Linking zip files without mentioning our URL is not permitted.


        </div>
    </div>

</div>

@stop