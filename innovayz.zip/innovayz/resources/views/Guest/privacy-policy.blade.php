@extends('layouts.master')
@section('headscript')
<title>Privacy Policy | Innovayz</title>
<style>
    body{
        background: #fff
    }
    .wraper{
        margin: 80px 0;
    }
    .colored_block{
        background: #fff;
    }
    .colored_block h2{
        font-size: 18px;
        font-family: 'Vollkorn', serif;
        margin-bottom: 10px;
    }
    .colored_block ol li{
        list-style:  decimal;
        margin-left: 15px;
    }
    .colored_block ul li ol li{
        list-style:  decimal;
        margin-left: 15px;
    }
    .colored_block ul li{
        list-style:  disc;
        margin-left: 15px;
    }
    .colored_block ol li,.colored_block p,.colored_block ul li{
        font-size: 13px;
        color: #000;
        line-height: 24px;
    }
</style>

<link href="https://fonts.googleapis.com/css?family=Vollkorn" rel="stylesheet">
@endsection

@section('content')
<section class="wraper">
    <div class="container">
    <div class="row">
        <h1>PRIVACY POLICY</h1>
        <br>
        <div class="colored_block well">
            <p>
                This Privacy Policy is intended to explain what data we collect from Users of the Site. A "User" means either a Member or a non-Member
                who is simply visiting the Site (a "Visitor"). This Privacy Policy may be revised or updated at any time and we encourage you to 
                check back often to ensure that you are familiar with the most recent version and the terms of our Privacy Policy.
                You trust us with your information. This Privacy Policy is meant to help you understand what data we collect, why we collect it, 
                and what we do with it. This is important; we hope you will take time to read it carefully.
            </p>
            <p>
                This policy covers how Innovayz treats personal information that Innovayz collects and receives, including information related to
                your past use of Innovayz products and services. Personal information is information about you that is personally identifiable
                like your name, address, email address, or phone number, and that is not otherwise publicly available. This privacy policy only
                applies to Innovayz, this policy does not apply to the practices of companies that Innovayz does not own or control, or to people
                that Innovayz does not employ or manage. In addition, some companies that Innovayz may acquire have their own, preexisting privacy 
                policies which may be viewed on our acquired companies page respectively.
            </p>
        </div>
        
        
        <div class="colored_block well">
            <h2>Information That You Provide to Us</h2>
            <ol>
                <li>
                    Innovayz may collect information that you provide when you use the services, such as when you: create account; participate in events,
                    competitions, quiz or promotions; send replies, questions or comments; submit your profile us online; fill out surveys; or otherwise 
                    communicate with us through different Services. The types of personal information that you provide may include your name,
                    e-mail address, telephone number, postal address, education, interest details and other contact or identifying information 
                    that you choose to provide.
                </li>
                <li>
                    Content. Innovayz stores, processes and maintains files that you create and/or upload using the Services (as well as previous
                    versions of your files), including files that you create and other data related to your account in order to provide the service 
                    to you.
                </li>
            </ol>
        </div>
        <div class="colored_block well">
            <h2>Information That We Collect Automatically From You</h2>
            <ol>
                <li>
                    We may obtain information from other sources and combine that with information we collect through our Services. For example, if you 
                    create or log into your Google account, we will have access to certain information from that account, such as your email, name and
                    photo, in accordance with the authorization procedures determined by Google.
                </li>
                <li>
                    We may use analytics services and software provided by third parties to help us understand how users access and use the Services.
                    These tools and services place cookies, web beacons and other devices or technologies on our Services to enable them to track
                    traffic data. The data collected typically includes information such as your IP address, your Internet Service Provider, your web 
                    browser, the time spent on webpages, the links clicked and the advertisements viewed on those pages. We use this information 
                    to improve our Services and your experience, to see which areas and features of our Services are popular and to count visits.
                </li>
            </ol>
        </div>
        <div class="colored_block well">
            <h2>How We Use Your Information</h2>
            <ul>
                <li>
                    We use personal information collected through Innovayz services for purposes described in this Policy or otherwise disclosed to you on 
                or in connection with our services. For example, we may use your information to:
                </li>
                <li>
                    <ol>
                <li>
                    Operate and improve our services;
                </li>
                <li>
                    Send you information about new products, contests, features and enhancements, special offers and other events of interest from 
                    Innovayz and our select partners;
                </li>
                <li>
                    Provide and deliver the products and services you request, process transactions, and to send you related information, including 
                    confirmations and invoices;
                </li>
                <li>
                    Send you technical notices, updates, security alerts and support and administrative messages;
                </li>
                <li>
                    Respond to your comments, questions and requests and provide customer service;
                </li>
                <li>
                    Monitor and evaluate trends, usage and activities in connection with our Services;
                </li>
                <li>
                    Personalize and improve the Services and provide ads, content, communications or features that match user profiles or interests; and
                </li>
                <li>
                    Link or combine with other information we get from third parties to help understand your needs and provide you with better service.
                </li>
            </ol>
                </li>
                <li>
                    Files you create, upload, or copy to Innovayz may, if you choose, be read, copied, used and redistributed by people you know or,
                    again if you choose, by people you do not know. Information you disclose using the chat function of Innovayz may be read, copied,
                    used and redistributed by people participating in the chat. Use care when including sensitive personal information in files you
                    share or in chat sessions, such as social security numbers, financial account information, home addresses or phone numbers.
                </li>
                <li>
                    Innovayz reserves the right to review documents to help resolve problems with the Innovayz subsidiary companies or services, or
                    to ensure compliance with our Terms of Service.
                </li>
            </ul>
            
        </div>
        <div class="colored_block well">
            <h2>Information Sharing</h2>
            <p>Innovayz may share your personal information with third parties in the following limited circumstances:</p>
            <ol>
                <li>
                    With third party vendors, consultants and other service providers who are working on our behalf, who are hosting our data, and need 
                    access to your information to carry out their work for us.
                </li>
                <li>
                    With data analytics and advertising services in order to understand your preferences and to show you advertising on our site or 
                    through our service.                   
                </li>
                <li>
                    With law enforcement, courts of competent jurisdiction, or others when we have a good faith belief that access, use, preservation 
                    or disclosure of such information is reasonably necessary to (a) satisfy any applicable law, regulation, legal process or 
                    enforceable governmental request, (b) enforce applicable Terms of Service, including investigation of potential violations
                    thereof, (c) detect, prevent, or otherwise address fraud, security or technical issues,
                    or (d) protect against harm to the rights, property or safety of Innovayz, its users or the public as required or permitted by law.
                </li>
                <li>
                    With your college, teachers if you have registered with Innovayz and linked your profile to college/teacher. We may share your
                    profile information with linked colleges and teachers.
                </li>
                <li>
                    We may share with third parties certain pieces of aggregated, non-personal information, such as the number of users who used a type 
                    of document, for example, or how many users clicked on a particular advertisement. Such information does not identify you 
                    individually.
                </li>
                <li>
                    In connection with, or during negotiations of, any merger, sale of some or all of Innovayz’s assets, bankruptcy or reorganization,
                    financing or acquisition of all or a portion of Innovayz’s business to another company.
                </li>
            </ol>
        </div>
        <div class="colored_block well">
            <h2>Will There Be Changes To This Privacy Policy?</h2>
            <p>
                Innovayz may amend this Privacy Policy from time to time. Use of information we collect now is subject to the Privacy Policy in effect
                at the time such information is used. If we make material changes in the way we use Personal Information, we will notify you by posting
                an announcement on our Services or sending you an email. Users are bound by any changes to the Privacy Policy when they use the Services
                after such changes have been first posted.
            </p>
        </div>
        <div class="colored_block well">
            <h2>Changing or Deleting Your Information & Targeting Opt-Out</h2>
            <ol>
                <li>
                    User may terminate use of Innovayz at any time. 
                </li>
                <li>
                    Changing or deleting your personal information, Editing or deleting your Personal Information. If you have created an account, 
                    you may at any time review and/or update the contact information we have for you. Please note that even if you delete information
                    from your account, or deactivate it, we may retain certain information as required by law or for legitimate business purposes. 
                    We may also retain cached or archived copies of your information for a certain period of time.
                </li>
                <li>
                    Cookies. Most web browsers are set to accept cookies by default. If you prefer, you can usually choose to set your browser to remove 
                    or reject browser cookies. Removing or rejecting browser cookies does not necessarily affect third party flash cookies used in 
                    connection with our Services. For more information about how to delete or disable flash cookies please visit 
                    www.adobe.com/products/flashplayer/security. Please note that if you choose to remove or reject cookies, this could affect the 
                    availability and functionality of our Services.
                </li>
            </ol>
        </div>
        
    </div>
</div>
</section>
@stop
