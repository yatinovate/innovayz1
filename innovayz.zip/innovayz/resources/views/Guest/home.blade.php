@extends('layouts.master')
@section('headscript')
<title>Welcome | Innovayz</title>
<link rel="stylesheet" href="{{asset("guest/css/home.css")}}">
@endsection

@section('content')

<div class="home_banner">
    <div class="searchForm">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="form-section">
                        <ul class="searchnav" dataa_u="{{URL::to("searcher")}}">
                            <li class="active"><a data-toggle="tab" href="#menu1" data_value="students">Student</a></li>
                            <li><a data-toggle="tab" href="#menu2" data_value="teachers">Teacher</a></li>
                            <li><a data-toggle="tab" href="#menu3" data_value="colleges" >Institute</a></li>
                        </ul>
                       
                        <form class="form-horizontal" id="search-form" method="get" action="{{Route("search.submit")}}">
                            <div class="form-group">
                                <div class="col-md-10 col-xs-10">
                                    <input type="text" name="q" id="searchbar" class="form-control typeahead" placeholder="Search your query" autocomplete="off">
                                    <div id="result">
                                        <div class="row"></div>
                                    </div>
                                </div>
                                <div class="col-md-2 col-xs-2">
                                    <input name="category" id="searchusercategory" type="hidden" >
                                    <button type="submit" class="btn btn-default btn-lg pull-right" id="searchbutn"  value="Search"><i class="fa fa-search"></i>&nbsp;&nbsp;Search</button>
                                </div>
                            </div>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<section class="home_services">
    <div class="container">
        <div class="row">
            <div class="col-md-12 home_title">
                <h2>FEATURES</h2>
            </div>
            <div class="col-md-12">
                <div class="color_blocks">
                    <div class="blocks">
                        <div class="flip-container orange">
                            <a href="{{Route("services")}}#profile" class="flipper">
                                <div class="front"><span>Profile<br /><br /><span class="glyphicon glyphicon-user font-ico"></span></span></div>
                                <div class="back"><strong>Profile</strong><span>Explore the group details, download the ebrochure and apply. </span></div>
                            </a>
                        </div>
                        <div class="flip-container teal">
                            <a href="{{Route("services")}}#Library" class="flipper">
                                <div class="front"><span>Library<br /><br /><span class="glyphicon glyphicon-book font-ico"></span></span></div>
                                <div class="back"><strong>Library</strong><span>Online knowledge bank to store the educational documents.</span></div>
                            </a>
                        </div>


                        <div class="flip-container yellow">
                            <a href="{{Route("services")}}#SkillTest" class="flipper">
                                <div class="front"><span>Skill Test<br><br><span class="glyphicon glyphicon-list-alt font-ico"></span></span></div>
                                <div class="back"><strong>Skill Test</strong><span>Take the skill test and check the expertise. Boost your profile.</span></div>
                            </a>
                        </div>

                        <div class="flip-container blue">
                            <a href="{{Route("services")}}#Questionnaire" class="flipper">
                                <div class="front"><span>Questionnaire<br /><br /><span class="glyphicon glyphicon-question-sign font-ico"></span></span></div>
                                <div class="back"><strong>Questionnaire</strong><span>Any educational query can be asked and answered.</span></div>
                            </a>
                        </div>
                        <div class="flip-container sky">
                            <a href="{{Route("services")}}#Share" class="flipper">
                                <div class="front"><span>Share<br /><br /><span class="glyphicon glyphicon-share font-ico"></span></span></div>
                                <div class="back"><strong>Share</strong><span>Share the knowledge because it always increases when distributed.</span></div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="home_parallax">
    <div class="container">
        <div class="row">
            <div class="col-md-12 home_title">
                <h2>Our ACHIEVEMENTS</h2>
            </div>
            <?php
            $totuser= count(App\Models\User::where("activated",1)->get());
            $totquestion=count(\App\Models\Question\PostQuestion::all());
            $totalknowledge=count(App\Models\Profile\PostKnowledge::all());
            $skillchl=count(App\Models\Challenge\ChallengeTest::all()) + count(App\Models\Skill\SkillTestMain::all());
            ?>
            <div class="col-md-12">
                <div class="col-md-3 col-xs-3 text-center">
                    <div class="achiv_icon">
                        <i class="fa fa-globe"></i>
                    </div>
                    <div class="achi_text">
                        <p class="countNumb">{{$totuser}}</p>
                        <span>Total Enrollments</span>
                    </div>
                </div>
                <div class="col-md-3 col-xs-3 text-center">
                    <div class="achiv_icon">
                        <i class="fa fa-bell"></i>
                    </div>
                    <div class="achi_text">
                        <p  class="countNumb">{{$totquestion}}</p>
                        <span>Q&A Posted & Answers</span>
                    </div>
                </div>
                <div class="col-md-3 col-xs-3 text-center">
                    <div class="achiv_icon">
                        <i class="fa fa-users"></i>
                    </div>
                    <div class="achi_text">
                        <p class="countNumb">{{$skillchl}}</p>
                        <span>Skill Test & Challange Taken</span>
                    </div>
                </div>
                <div class="col-md-3 col-xs-3 text-center">
                    <div class="achiv_icon">
                        <i class="fa fa-briefcase"></i>
                    </div>
                    <div class="achi_text">
                        <p>{{$totalknowledge}}</p>
                        <span>Knowledge Posted & Shared</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<div class="home_testomonial">
    <div class='sec_bg'>
        <div class="container">
            <div class="row">
                <div class="col-md-12" data-wow-delay="0.2s">
                    <div class="carousel slide" data-ride="carousel" id="quote-carousel">
                        <!-- Bottom Carousel Indicators -->
                        <ol class="carousel-indicators">
                            <li data-target="#quote-carousel" data-slide-to="0" class="active"><img class="img-responsive " src="https://s3.amazonaws.com/uifaces/faces/twitter/brad_frost/128.jpg" alt="">
                            </li>
                            <li data-target="#quote-carousel" data-slide-to="1"><img class="img-responsive" src="https://s3.amazonaws.com/uifaces/faces/twitter/rssems/128.jpg" alt="">
                            </li>
                            <li data-target="#quote-carousel" data-slide-to="2"><img class="img-responsive" src="https://s3.amazonaws.com/uifaces/faces/twitter/adellecharles/128.jpg" alt="">
                            </li>
                        </ol>

                        <!-- Carousel Slides / Quotes -->
                        <div class="carousel-inner text-center">

                            <!-- Quote 1 -->
                            <div class="item active">
                                <div class="col-md-8 col-md-offset-2">
                                    <div class="col-md-4 ">
                                        <img class="img-responsive img-circle" src="https://s3.amazonaws.com/uifaces/faces/twitter/brad_frost/128.jpg" alt="">
                                    </div>
                                    <div class="col-md-8">
                                        <blockquote>

                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. !</p>
                                            <small>Someone famous</small>

                                        </blockquote>
                                    </div>
                                </div>

                            </div>
                            <!-- Quote 2 -->
                            <div class="item">
                                <div class="col-md-8 col-md-offset-2">
                                    <div class="col-md-4">
                                        <img class="img-responsive img-circle" src="https://s3.amazonaws.com/uifaces/faces/twitter/rssems/128.jpg" alt="">
                                    </div>
                                    <div class="col-md-8">
                                        <blockquote>

                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. !</p>
                                            <small>Someone famous</small>

                                        </blockquote>
                                    </div>
                                </div>
                            </div>
                            <!-- Quote 3 -->
                            <div class="item">
                                <div class="col-md-8 col-md-offset-2">
                                    <div class="col-md-4">
                                        <img class="img-responsive img-circle" src="https://s3.amazonaws.com/uifaces/faces/twitter/adellecharles/128.jpg" alt="">
                                    </div>
                                    <div class="col-md-8">
                                        <blockquote>

                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. !</p>
                                            <small>Someone famous</small>

                                        </blockquote>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Carousel Buttons Next/Prev -->
                        <a data-slide="prev" href="#quote-carousel" class="left carousel-control"><i class="fa fa-chevron-left"></i></a>
                        <a data-slide="next" href="#quote-carousel" class="right carousel-control"><i class="fa fa-chevron-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<section class="subscribe">
    <div class="container">
        <div class="row">
            <div class="col-md-7 col-xs-12 icon_box">
                <div class="col-lg-3 col-md-3 col-xs-2">
                    <i class="fa fa-book"></i>
                </div>
                <div class="col-lg-9 col-md-9 col-xs-10 icon_text">
                    <h3><span style="color: #48a7d4;">STAY TUNED</span> WITH US</h3>
                    <p>Subscribe now and receive weekly newsletter with educational materials, 
                        new courses, interesting posts, popular books and much more!
                    </p>
                </div>                        
            </div>
            <div class="col-md-5 col-xs-12">
                <div class="wpb_wrapper">
                    <h5>Your e-mail address</h5>
                    <div class="alert alert-success" style="display: none;">
                        <a  class="close" data-hide="alert"  aria-label="close">&times;</a>
                        <strong>Success!</strong> Indicates a successful or positive action.
                    </div>
                    <form id="Subscription" >
                        <div class="form-group">
                            <div class="md-form input-group input-group-lg">    
                                <input type="email" class="form-control" name="subscribe" id="subscribe" placeholder="Email">
                                <span class="input-group-addon btnaa">
                                    <i class="fa fa-send"></i>&nbsp;&nbsp;Subscribe
                                </span>  
                            </div>
                            <span id="subscribeeror" class="help-block"><strong></strong></span>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
@stop

@section('jsfiles')
<script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
<script src="js/jquery.counterup.min.js"></script> 
<script type="text/javascript">
$(function ()
{
    
    $('#testimonial').carousel({
        pause: true,
        interval: 100000
    });
    var $countNumb = $('.countNumb');

    if ($countNumb.length > 0) {
        $countNumb.counterUp({
            delay: 15,
            time: 1700
        });
    }
    //?url=http://localhost:8000/Profile/9
  /*  var queries = {};
  $.each(document.location.search.substr(1).split('&'),function(c,q){
    var i = q.split('=');
    queries[i[0].toString()] = i[1].toString();
  });
  if(queries['url']){
      var url=queries['url'];
      $(".signup_icon1").trigger("click");
      $(".signup_icon1").attr('dataurl',url);
      console.log(queries['url']);
  }
  */
});
</script>
@if(session()->has('url.intended'))
<script>
    $(function(){
        //$(".signup_icon1").trigger("click");
    });
</script>
@endif
<script>
    $(function () {
        
         $("[data-hide]").on("click", function(){
        $("." + $(this).attr("data-hide")).hide();
    });
    
            $(".btnaa").click(function (e) {
            e.preventDefault();
            var butn = $(this);
            var form = $("#Subscription");
            var formdata = form.serializeArray();
            form.find('input').attr('disabled', 'disabled');
            $('#subscribeeror strong').text(" ");
            $.ajax({
            type: "POST",
                    url: 'Subscription',
                    data: formdata,
                    datatype: 'JSON',
                    success: function (data) {
                    form.find('input').attr('disabled', false);
                    $(".wpb_wrapper .alert").css("display",'block');
                    $('#subscribeeror strong').text(" ");
                    },
                    error: function (xhr) {
                    butn.attr('disabled', false);
                    form.find('input').attr('disabled',false);
                    var obj = JSON.parse(xhr.responseText);
                    form.find('.form-group').removeClass('has-error');
                    $('#subscribeeror strong').text("");
                            if (obj['custerrors']) {
                    alert(obj['custerrors']);
                    }
                    $('#subscribeeror strong').text(obj['errors']['subscribe']);
                    form.find('.form-group').addClass('has-error');
                    }
            });
    });
    
        
    });
</script>

@stop