<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
    </head>
    <body style="background-color:  #ddd;">

        <table class="email_body" style="background-color:  #ddd; margin: 100px 100px; padding: 100px 100px">
            <tr>
                <td>
                    <div class="udd_logo" style="width:100%;height:100%;">
                        <img src="{{asset("images/dummy-logo.png")}}" alt="Uddeshya Logo" style="height: 50px; width: 100px"> 
                    </div>
                    <div class="email_heading" style="background-color:  #414b4f;color: #FFFFFF;padding: 2px 5px 15px 18px;">
                        <h3 style="font-size: 22px;">New answer to your question</h3>
                    </div>
                    <div class="email_content" style="background-color: #FFFFFF;margin-top: -20px;padding: 20px 20px 40px 20px;">

                       
                        <p>Dear {{$username}},</p><br>
                        <p>1 new answer to your question</p><br>
                        <p>Question Details : {{$question}}</p><br>
                        <a href="{{ URL::to('Question/QuestionList/QuestionDetail/' . $qid) }}" style="text-decoration: none;font-weight: bold;font-size: 14px;">View Answer here</a>
                    </div>

                    <div class="email_footer" style="background-color:  #414b4f;color: #FFFFFF;padding: 20px 0px 20px 20px; ">

                    </div>
                    <div class="footer_content" style="text-align: center;color: gray;font-size: 13px;">
                        <p>
                            &copy; 2016 Uddeshya India Limited. Uddeshya,  All rights are reserved.
                        </p>
                        <p>
                            This email was intended for uddeshya inc (--).
                            <a href="#" style="text-decoration: none;">Learn why we include this.</a>
                            <br> If you need assistance or have questions, 
                            please contact 
                            <a href="#" style="text-decoration: none;">Uddeshya Customer Service.</a>
                        </p>
                        <p>
                            Uddeshya is a registered business name of Uddeshya India Limited. <br>Registered in India as a private limited company,
                            Company Number: 9999999999<br> Registered Office: address, India.
                        </p>
                    </div>
                </td>
            </tr>
        </table>

    </body>
</html>
