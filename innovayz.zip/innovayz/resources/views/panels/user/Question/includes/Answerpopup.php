<form class="form-horizontal" id="postanswer" action="<?php echo Route("question.postAnswer");?>" method="post">
    <?php echo csrf_field() ?>
    <div class="form-group">
        <label class="col-sm-12 control-label qlabel"><?php echo $qution->question; ?></label>
        <div class="col-sm-12">
            <textarea class="form-control" rows="5" id="answer" name="answer" placeholder="Enter you answer"></textarea>
        </div>
    </div>
    <div class="form-group">
        <div class="col-sm-12">
            <input type="checkbox" name="notify" value="1" checked="checked">
            <label>&nbsp;you will be notify if someone reply to this question too
            </label>
        </div>
    </div>
    <input type="hidden" value="<?php echo $qution->id; ?>" name="qid" id="qesid">
    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
            <input type="submit" class="btn btn-primary pull-right" id="submit_qus" value="Post Answer">
        </div>
    </div>
</form>
<script>
    $(function () {

        $('#postanswer').formValidation({
            framework: 'bootstrap',
            icon: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                answer: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }
            }
        });
    });
</script>