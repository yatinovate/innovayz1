@extends('layouts.master')

@section('headscript')

<title>Question & Answers | InnoVayz</title>
<link href="{{asset("css/magicsuggest-min.css")}}" rel="stylesheet">
<link rel="stylesheet" href="{{asset("question/css/questionlist.css")}}">
<style>
    
/********************
**Post Question******
********************/
#postquestion .modal-header,#ansewerpop .modal-header,#postimage .modal-header,#postgroupsearch .modal-header{

    background-color: #337ab7;
    color: #fff;
    padding: 10px;
    font-size: 18px;
    font-family: open sans;
    font-weight: bold;
}

#postquestion .modal-dialog {
    width: 400px; /* or whatever you wish */
    z-index: 0;
}
#ask_questn label,#group_formjoin label
{
    text-align: left;
    margin-bottom: 10px;
    font-weight: bold;
    text-transform: capitalize;
    font-family: open sans;
    font-size: 12px;

}
#ask_questn span{
    font-size: 10px;
}
</style>
@endsection
@section('content')

<div class="container-fluid full_img">
    
</div>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-9">
                <div class="question_title">
                    <h2>Question For You
                        @if(count($userquestion) >=1 )
                        <a class="btn btn-success answermodal pull-right" data-toggle="modal" data-target="#postquestion"><i class="fa fa-plus"></i>&nbsp;Ask a Question</a>
                        @endif
                    </h2>
                    
                    <div class="text-center">
                        @include('errors.status')
                    </div>
                </div>
                <div class="questionpanel">
                    <ul class="nav nav-tabs nav-justified navtabs">
                        <li class="active"><a data-toggle="tab" href="#your_ques">Your Questions</a></li>
                        <li><a id="ansqget" data-toggle="tab" href="#ans2">Answered Question</a></li>
                        <li><a id="unansget" data-toggle="tab" href="#ans3">Unanswered Question</a></li>
                    </ul>
                    
                    <div class="tab-content">
                        <div id="your_ques" class="tab-pane fade in active">
                            @if(count($userquestion) < 1)
                            <div class="no_quesions">
                                <div class="text-center">
                                    <p>No Questions asks till now , <a class="btn btn-info answermodal" data-toggle="modal" data-target="#postquestion">Ask a Question</a></p>
                                </div>
                            </div>
                            @endif
                            @foreach ($userquestion as $currentuserquestion)
                            <div class="panel panel-primary my_panel">
                                <div class="panel-heading ">
                                    <div class="row">
                                        <div class="col-md-10">
                                            <h2><a href="{{ Route('question.q_detail',["q_code"=>$currentuserquestion->id,"q_detail"=>$currentuserquestion->question]) }}">{{$currentuserquestion->question}}</a></h2>
                                        </div>
                                        <div class="col-md-2 text-right">
                                            <span>Date : {{$currentuserquestion->created_at->format('d,M')}}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="desc_block">
                                            <p><strong>Description : </strong>{{$currentuserquestion->description}}</p>
                                        </div>
                                        <b>By : {{$currentuserquestion->user->name}}</b>
                                    </div>
                                </div>
                                <div class="panel-footer">
                                    <div class="row">
                                        <div class="col-md-10">
                                            <div class="tagcontainer">
                                                <strong>Tags : </strong>
                                                <ul>
                                                    @foreach ($currentuserquestion->question_tags as $area)
                                                    <li><a href='{{Route("question.qtagsearch",["q_code"=>$area->q_tags->id,"q_tag"=>$area->q_tags->area_intrest,])}}'>{{$area->q_tags->area_intrest}}</a></li>  
                                                    @endforeach
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-md-2 text-right">
                                            
                                        </div>
                                    </div>

                                </div>  
                            </div>
                            @endforeach
                        </div>
                        <div id="ans2" class="tab-pane fade">
                            <div class='bg_loader'><img src='{{asset('adminRes/img/ajax-loader.gif')}}' class='img-responsive'></div>
                        </div>

                        <div id="ans3" class="tab-pane fade">
                            <div class='bg_loader'><img src='{{asset('adminRes/img/ajax-loader.gif')}}' class='img-responsive'></div>                             
                        </div>
                    </div>
                </div>
        </div>
    <div class="col-md-2 col-md-offset-1">
        @include("includes.adblock")
    </div>
</div>

</div>

<div class="modal fade" id="postquestion" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content question_modal">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center">Ask Question</h4>
            </div>
            <div class="modal-body clearfix">

                <form class="form-horizontal" id="ask_questn" method="post" action="{{Route("question.post")}}">
                    {{ csrf_field() }}
                    <div class="form-group">                                              
                        <label class="col-sm-12 control-label">Enter your question</label>
                        <div class="col-sm-12">
                            <input type="text" class="form-control" id="enter_question" name="enter_question"  placeholder="Enter question">
                        </div>
                    </div>
                    <div class="form-group">  
                        <label class="col-sm-12 control-label">Question description</label>
                        <div class="col-sm-12">
                            <textarea class="form-control" name="qdescription" id="qdescription" placeholder="Enter Description"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-12 control-label">Enter your tags</label>
                        <div class="col-sm-12">
                            <input type="text" class="form-control" id="questiontags" name="questiontags" placeholder="Enter your tags">                            
                            <input type="hidden" id="questiontags1" name="questiontags1" >
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <input type="submit" class="btn btn-primary pull-right" id="submit_qus" value="Post Question">
                        </div>
                    </div>

                </form>
            </div>                                       
        </div>

    </div>
</div>
<div class="modal fade" id="ansewerpop" role="dialog">
    <div class="modal-dialog my_modal">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center">Add Answer</h4>
            </div>
            <div class="modal-body">
                <div class='bg_loader'><img src='{{asset('adminRes/img/ajax-loader.gif')}}' class='img-responsive'></div>
            </div>                                       
        </div>
    </div>
</div>
@endsection


@section('jsfiles')
<script src="{{asset("js/magicsuggest-min.js")}}"></script>
<script>
    $(function () {
        $("#ansewerpop").on('shown.bs.modal', function (e) {
            var qid = e.relatedTarget.id;
            $.get('{{Route("question.anspop")}}',{qid:qid},function(data){
                $("#ansewerpop .modal-body").html(data);
            });
        });
        $("#ansewerpop").on('hide.bs.modal', function (e) {
            $("#ansewerpop .modal-body").html("<div class='bg_loader'><img src='{{asset('adminRes/img/ajax-loader.gif')}}' class='img-responsive'></div>");
        });
        $("#ansqget").click(function () {
            $("#ans2").load('{{Route("question.ansqlist")}}');            
        });

        $("#unansget").click(function () {
            $("#ans3").load('{{Route("question.unansqlist")}}');
        });
        
var url = window.location.href;
 var activeTab = url.substring(url.indexOf("#") + 1);
 if(activeTab=="unansget"){
     $('#'+activeTab).trigger('click');
 }
        
        var ms1 = $('#questiontags').magicSuggest({
        allowFreeEntries: false,
        valueField: 'value',
        displayField: 'label',
        required: true,
        allowDuplicates: false,
        data: '{{Route("question.areaintreset")}}',
        ajaxConfig: {
            xhrFields: {
                withCredentials: true
            }
        }
    });

    $(ms1).on('selectionchange', function (e, m) {
        var asd = this.getValue();
        $("#questiontags1").val(asd);
        var asd = this.getValue();
        $('#ask_questn').find('[name="questiontags1"]').val(asd).end().formValidation('revalidateField', 'questiontags1');
    });
    $('#ask_questn').formValidation({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            enter_question: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            },qdescription: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            },
            questiontags1: {
                excluded: false,
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }

        }
    });

    });
</script>
@endsection
