<div class="titleBox">
    <label>Answers :  </label>        
</div>
<div class="actionBox">
    <ul class="commentList">    
        @foreach ($ans as $cm)
        <li>               
            <div class="col-md-2">
                <img src="{{ asset(App\Models\User::find($cm->user_id)->avatar)}}" alt="picture" class="img-responsive">
            </div>
            <div class="col-md-8">
                <p>{{$cm->answer}}</p> 
            </div>
            <div class="col-md-2">
                @if(Auth::user()->id != $cm->user_id)
                <a dataid="{{$cm->id}}" id="lisssskebtn" class="anslistdellike">
                    <span>
                        <?php
                        $likecount = count(\App\Models\Question\LikeQ::where("post_id", $cm->id)->get());
                        if ($likecount > 0) {
                            echo $likecount;
                        }
                        ?>
                    </span>&nbsp;<i class="fa fa-thumbs-up"></i>&nbsp;&nbsp;Like
                </a>
                @endif
                @if(Auth::user()->id == $cm->user_id)
                <a class="anslistdellike"><span><?php echo count(\App\Models\Question\LikeQ::where("post_id", $cm->id)->get()); ?></span>
                    &nbsp;<i class="fa fa-thumbs-up"></i></a>&nbsp;&nbsp;
                <a href="<?php echo Route("question.answerdelete", ["question-id" => $cm->id]); ?>" class="anslistdel">Delete</a>
                @endif
            </div>
            <div class="clearfix"></div>
        </li>     
        @endforeach
    </ul>      
</div>

<script>
    $(function () {
        $(".anslistdellike").on('click', function (e) {
            e.preventDefault();
            var sele = $(this);
            var qid = sele.attr('dataid');
            if (qid != null) {
                sele.find('span').html('<i class="fa fa-spinner fa-pulse fa-1x fa-fw"></i><span class="sr-only">Loading...</span>');

                $.post('<?php echo Route("question.answerlike"); ?>', {qid: qid}, function (data)
                {
                    console.log(data);
                    if (data)
                    {
                        sele.attr("disabled", "disabled");
                        sele.find("span").text(data);
                    }/*
                     else
                     {
                     $("#status").html("Already Liked!!");
                     }*/
                });
            }

        });

    });
</script>