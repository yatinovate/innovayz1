@extends('layouts.master')

@section('headscript')
<title>{{$question->question}} | InnoVayz</title>
<link href="{{asset("css/magicsuggest-min.css")}}" rel="stylesheet">
<link rel="stylesheet" href="{{asset("question/css/questionlist.css")}}">
<style>
    
/********************
**Post Question******
********************/
#postquestion .modal-header,#ansewerpop .modal-header,#postimage .modal-header,#postgroupsearch .modal-header{

    background-color: #337ab7;
    color: #fff;
    padding: 10px;
    font-size: 18px;
    font-family: open sans;
    font-weight: bold;
}

#postquestion .modal-dialog {
    width: 400px; /* or whatever you wish */
    z-index: 0;
}
#ask_questn label,#group_formjoin label
{
    text-align: left;
    margin-bottom: 10px;
    font-weight: bold;
    text-transform: capitalize;
    font-family: open sans;
    font-size: 12px;

}
#ask_questn span{
    font-size: 10px;
}
</style>
@endsection
@section('content')

<div class="container-fluid full_img">
    
</div>

<div class="container paddd-30">
    <div class="row">
        <div class="col-md-7">
            <ol class="breadcrumb">
                <li><a href="{{Route("question.myquestion")}}">My Questions</a></li>
                <li class="active">Question Detail</li>
            </ol>
            <div class="questionpanel">
                <div class="panel panel-default my_panel">
                    <div class="panel-heading">
                        <h2>{{$question->question}}</h2>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="desc_block">
                                <p><strong>Description : </strong>{{$question->description}}</p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="tagcontainer">
                                <strong>Tags : </strong>
                                <ul>
                                    @foreach ($question->question_tags as $area)
                                        <li><a href="{{Route("question.qtagsearch", ["q_code" => $area->q_tags->id, "q_tag" => $area->q_tags->area_intrest,])}}">{{$area->q_tags->area_intrest}}</a></li>
                                        @endforeach
                                </ul>
                            </div>
                            <p class="nameanswer"><strong>By : <a href="{{Route("profile.index", ["user-id" => $question->user->id, 'user-name' => $question->user->name])}}">{{$question->user->name}}</a></strong> | <a href="#detailan" id="anscount"><b>{{$anslistcount}}</b> Answers</a></p>
                        </div>

                        <div class="row">
                            <div class="post_dta">
                                <div class="col-md-2">
                                    <img src="{{ asset(Auth::user()->avatar)}}" alt="picture" class="img-responsive">
                                </div>
                                <div class="col-md-10"> 
                                    <form method="post" id="postanswer" action="{{Route("question.postAnswer")}}">
                                        {{csrf_field()}}
                                        <div class="form-group">
                                            <textarea class="form-control" rows="2" id="answer" name="answer" placeholder="Enter you answer"></textarea>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-9">
                                                <div class="form-group">
                                                    
                                                    <label id="notifytet"><input type="checkbox" name="notify" value="1" checked="checked">&nbsp;You will be notify if someone reply to this question too
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <input type="hidden" name="qid" value="{{$question->id}}">
                                                <button type="submit" id="postbtns" class="btn btn-primary">POST Answer</button>
                                            </div>
                                        </div>
                                        
                                        
                                    </form>
                                </div>     
                            </div>
                        </div>
                    </div> 
                </div>
                <div class="detailBox" id="detailan">
                    <div class='bg_loader'><img src='{{asset('adminRes/img/ajax-loader.gif')}}' class='img-responsive'></div>
                </div>

            </div>

        </div>
        <div class="col-md-3">
            <div class="dash_panel">
                <div class="row">
                    <div class="col-md-12">
                        <h2>Related Questions</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12 col-sm-12">
                        <ul class="event-list">
                            <div class='bg_loader'><img src='{{asset('adminRes/img/ajax-loader.gif')}}' class='img-responsive'></div>
                        </ul>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12 col-sm-12 text-center">
                        <a class="btn btn-info" data-toggle="modal" data-target="#postquestion">Ask a Question</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="advertise_block">
                <div class="panel-group">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <img class="img-responsive" src="{{asset("img/hh.png")}}" alt="hllo">
                        </div>
                    </div>
                    <div class="panel panel-primary">
                        <div class="panel-body">                                
                            <img class="img-responsive" src="{{asset("img/hh.png")}}" alt="hllo">
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>

</div>


<div class="modal fade" id="postquestion" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content question_modal">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center">Ask Question</h4>
            </div>
            <div class="modal-body clearfix">

                <form class="form-horizontal" id="ask_questn" method="post" action="{{Route("question.post")}}">
                    {{ csrf_field() }}
                    <div class="form-group">                                              
                        <label class="col-sm-12 control-label">Enter your question</label>
                        <div class="col-sm-12">
                            <input type="text" class="form-control" id="enter_question" name="enter_question"  placeholder="Enter question">
                        </div>
                    </div>
                    <div class="form-group">  
                        <label class="col-sm-12 control-label">Question description</label>
                        <div class="col-sm-12">
                            <textarea class="form-control" name="qdescription" id="qdescription" placeholder="Enter Description"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-12 control-label">Enter your tags</label>
                        <div class="col-sm-12">
                            <input type="text" class="form-control" id="questiontags" name="questiontags" placeholder="Enter your tags">                            
                            <input type="hidden" id="questiontags1" name="questiontags1" >
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <input type="submit" class="btn btn-primary pull-right" id="submit_qus" value="Post Question">
                        </div>
                    </div>

                </form>
            </div>                                       
        </div>

    </div>
</div>

@endsection


@section('jsfiles')
<script src="{{asset("js/magicsuggest-min.js")}}"></script>
<script>
    $(function () {

        $(".detailBox").load('{{Route("question.answerlist",["question-id"=>$question->id])}}');
        $(".dash_panel .event-list").load('{{Route("question.suggested",["qid"=>$question->id])}}');

       
            var ms1 = $('#questiontags').magicSuggest({
        allowFreeEntries: false,
        valueField: 'value',
        displayField: 'label',
        required: true,
        allowDuplicates: false,
        data: '{{Route("question.areaintreset")}}',
        ajaxConfig: {
            xhrFields: {
                withCredentials: true
            }
        }
    });

    $(ms1).on('selectionchange', function (e, m) {
        var asd = this.getValue();
        $("#questiontags1").val(asd);
        var asd = this.getValue();
        $('#ask_questn').find('[name="questiontags1"]').val(asd).end().formValidation('revalidateField', 'questiontags1');
    });
    $('#ask_questn').formValidation({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            enter_question: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            },qdescription: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            },
            questiontags1: {
                excluded: false,
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }

        }
    });
    
        $('#postanswer').formValidation({
            framework: 'bootstrap',
            icon: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                answer: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }
            }
        });

    });
</script>
@endsection