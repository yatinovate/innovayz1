@extends('layouts.master')

@section('headscript')
<title>{{$searchtag}} | Search  | InnoVayz</title>
<link rel="stylesheet" href="{{asset("question/css/questionlist.css")}}">
@endsection
@section('content')

<div class="container-fluid full_img">
    
</div>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-9">
            <section>
                <div class="question_title">
                    <h2>Search Result : {{$searchtag}}</h2>
                </div>
                  <ol class="breadcrumb">
                    <li><a href="{{Route("question.myquestion")}}">My Questions</a></li>
                    <li class="active">Question Search</li>
                </ol>
                <div class="questionpanel">
                    <div class="tab-content">
                        <div id="your_ques" class="tab-pane fade in active">
                            @if(count($questiontag) < 1)
                            <div class="no_quesions">
                                <div class="card-block text-center">
                                    <p>No Questions asks till now , <a href="{{Route("Dashboard")}}">Ask a question Now</a></p>
                                </div>
                            </div>
                            @endif
                            @foreach ($questiontag as $tag)
                            <div class="panel panel-primary my_panel">
                                <div class="panel-heading ">
                                    <div class="row">
                                        <div class="col-md-10">
                                            <h2><a href="{{ Route('question.q_detail',["q_code"=>$tag->tag_quest->id,"q_detail"=>$tag->tag_quest->question]) }}">{{$tag->tag_quest->question}}</a></h2>
                                        </div>
                                        <div class="col-md-2 text-right">
                                            <span>Date : {{$tag->tag_quest->created_at->format('d,M')}}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="desc_block">
                                            <p><strong>Description : </strong>{{$tag->tag_quest->description}}</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-footer">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <div class="tagcontainer">
                                                <strong>Tags : </strong>
                                                <ul>
                                                    @foreach ($tag->tag_quest->question_tags as $area)
                                                    <li><a href='{{Route("question.qtagsearch",["q_code"=>$area->q_tags->id,"q_tag"=>$area->q_tags->area_intrest,])}}'>{{$area->q_tags->area_intrest}}</a></li>  
                                                    @endforeach
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-md-2 text-right">
                                            @if($tag->tag_quest->hasanswer)
                                            <a href="{{ URL::route('question.q_detail', ["q_code" => $tag->tag_quest->id, "q_detail" => $tag->tag_quest->question])}}#detailan">Answer {{count($tag->tag_quest->answers)}}</a>
                                            
                                            @endif
                                            
                                        </div>
                                        <div class="col-md-2 text-right">
                                            <button type='button' class="btn btn-info answermodal" data-toggle="modal" id="{{$tag->tag_quest->id}}" data-target="#ansewerpop">Add Answer</button>
                                        </div>
                                    </div>
                                </div>  
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </section>

        </div>
        <div class="col-md-2 col-md-offset-1">
            <div class="panel-group">
                <div class="panel panel-primary">
                    <div class="panel-body">
                        <img class="img-responsive" src="{{asset("img/hh.png")}}" alt="hllo">
                    </div>
                </div>
                <div class="panel panel-primary">
                    <div class="panel-body">                                
                        <img class="img-responsive" src="{{asset("img/hh.png")}}" alt="hllo">
                    </div>
                </div>

            </div>
        </div>
    </div>

</div>

@endsection


@section('jsfiles')

<script>
    $(function () {
      $("#ansewerpop").on('shown.bs.modal', function (e) {
            var qid = e.relatedTarget.id;
            $.get('{{Route("question.anspop")}}',{qid:qid},function(data){
                $("#ansewerpop .modal-body").html(data);
            });
            //.load('{{Route("question.anspop")}}/'+qid);
        });
        $("#ansewerpop").on('hide.bs.modal', function (e) {
            $("#ansewerpop .modal-body").html("<div class='bg_loader'><img src='{{asset('adminRes/img/ajax-loader.gif')}}' class='img-responsive'></div>");
        });
    });
</script>
@endsection
<div class="modal fade" id="ansewerpop" role="dialog">
    <div class="modal-dialog my_modal">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center">Add Answer</h4>
            </div>
            <div class="modal-body">
                <div class='bg_loader'><img src='{{asset('adminRes/img/ajax-loader.gif')}}' class='img-responsive'></div>
            </div>                                       
        </div>
    </div>
</div>