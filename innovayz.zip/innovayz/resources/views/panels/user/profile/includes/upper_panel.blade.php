<div class="head-detail">
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-2">
                <div class="head-img text-center">
                    <img src="{{ asset($userdata->avatar)}}" alt="picture" class="img-responsive img-thumbnail">
                </div>
            </div>
            <div class="col-md-9">
                <div class="row">
                    <div class="col-md-9">
                        <div class="head_content">
                            <h2>{{$userdata->name }}
                            </h2>
                            <ul> 
                                <li><i class="fa fa-user"></i> {{substr($userdata->user_type , 0, -1) }}</li>
                                <?php
                                if ($userdata->user_type === 'students' || $userdata->user_type === 'teachers') {
                                    if (count($userdata->qulaifiaction)) {
                                        $highestarray = array();
                                        foreach ($userdata->qulaifiaction as $qual) {
                                            switch ($qual->specalization->qual_group) {
                                                case "":
                                                    $highestarray[] = array("id" => $qual->id, "education" => $qual->specalization->qual_group);
                                                    break;
                                                case "Graduation":
                                                    $highestarray[] = array("id" => $qual->id, "education" => $qual->specalization->qual_group);
                                                    break;
                                                case "Post Graduation":
                                                    $highestarray[] = array("id" => $qual->id, "education" => $qual->specalization->qual_group);
                                                    break;
                                            }
                                        }

                                        function compareByName($a, $b) {
                                            return strcmp($a["education"], $b["education"]);
                                        }

                                        usort($highestarray, 'compareByName');
                                        $keys = array_keys($highestarray);
                                        $lastKey = $keys[count($keys) - 1];
                                        $maxqulaification = App\Models\User\Qulaification::find($highestarray[$lastKey]["id"]);
                                        echo '<li><i class="fa fa-book"></i> ' . $maxqulaification->specalization->qulaification . ' (' . $maxqulaification->maxstream->qulaification . ')</li>';
                                    }
                                }
                                ?>                     
                                <?php
                                if (isset($contact->state) || isset($contact->city)) {
                                    ?>    
                                    <li><i class="fa fa-map-marker"></i>&nbsp;&nbsp;{{isset($contact->state) ? ucfirst($contact->state) : '' }}, {{isset($contact->city) ? ucfirst($contact->city) : '' }}
                                    </li>
                                    <?php
                                }
                                ?>

                            </ul>
                            <ul class="araa">
                                @foreach ($userdata->user_area as $error)
                                <li><a>{{ \App\Models\User\AreaIntrest::find($error->area_int->id)->area_intrest }}</a></li>
                                @endforeach
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="head_content text-right">
                            @if(Auth::check())
                            @if(Auth::user()->id!=$userdata->id)
                            <?php
                            $follow = "Follow";
                            $verify = \App\Models\Profile\Followers::where('user_id', Auth::user()->id)->where('followers_id', $userdata->id)->first();
                            if ($verify) {
                                $follow = "Unfollow";
                            }
                            ?>
                            <a href="{{Route("follow",["user-id"=>$userdata->id])}}" ><span class="btn btn-warning">{{$follow}}</span></a>
                            <a href="#" data-toggle="modal" data-target="#postquestion" id="messgeropener"><span class="btn btn-warning">Message</span></a>
                            @endif
                            @else
                            <a href="#" id='logpop'><span class="btn btn-warning btn-lg">Message</span></a>
                            @endif

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="postquestion" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content question_modal">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center">Send Message</h4>
            </div>
            <div class="modal-body clearfix">

                <form class="form-horizontal" id="ask_questn" method="post" action="{{Route("Dashboard.sendMessage")}}">
                    {{ csrf_field() }}
                    <input type="hidden" value="{{$userdata->id}}" name="userid" >
                    <div class="form-group">  
                        <label class="col-sm-12 control-label">Message</label>
                        <div class="col-sm-12">
                            <textarea class="form-control" rows="7" name="send_message"  placeholder="Enter Description"></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <input type="submit" class="btn btn-primary pull-right" value="Send Message">
                        </div>
                    </div>

                </form>
            </div>                                       
        </div>

    </div>
</div>
