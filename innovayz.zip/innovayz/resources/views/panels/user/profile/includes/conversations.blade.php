@extends('layouts.master')
@section('headscript')
<title>Messages | Innovayz</title>

<link rel="stylesheet" href="{{asset('chat/css/style.css')}}">
@stop
@section('content')
<div class="container clearfix body">
    <div class="row">
        <div class="col-md-3 people-list" id="people-list">
            @include('panels.user.profile.includes.peoplelist')
        </div>
        <div class="col-md-6 chat">
            <div class="chat-header clearfix">
                @if(isset($user))
                <img src="{{asset(@$user->avatar)}}" alt="avatar" />
                @endif
                <div class="chat-about">
                    @if(isset($user))
                    <div class="chat-with">{{@$user->name}} | {{substr(@$user->user_type , 0, -1) }}</div>
                    @else
                    <div class="chat-with">No Thread Selected</div>
                    @endif
                </div>
            </div> <!-- end chat-header -->

            <div class="chat-history">
                <ul id="talkMessages">

                    @foreach($messages as $message)
                  <?php
                   Talk::setAuthUserId(Auth::user()->id);
        $threads = Talk::makeSeen($message->id);
                  
                  ?>
                    @if($message->sender->id == auth()->user()->id)
                    <li class="clearfix" id="message-{{$message->id}}">
                        <div class="message-data align-right">
                            <img src="{{asset($message->sender->avatar)}}" alt="{{$message->sender->name}}" title="{{$message->sender->name}}">
                        </div>
                        <div class="message other-message float-right">
                            {{$message->message}}
                        </div>
                        <div class="float-right">
                            <span class="message-data-time" >{{$message->humans_time}} ago</span> &nbsp; &nbsp;                            
                        </div>
                        
                    </li>
                    @else

                    <li id="message-{{$message->id}}">
                        <div class="message-data">
                            <img src="{{asset($message->sender->avatar)}}" alt="{{$message->sender->name}}" title="{{$message->sender->name}}">
                            
                        </div>
                        <div class="message my-message">
                            {{$message->message}}
                        </div>
                        <div>
                            <span class="message-data-time">{{$message->humans_time}} ago</span>                          
                        </div>
                    </li>
                    @endif
                    @endforeach


                </ul>

            </div> <!-- end chat-history -->

            <div class="chat-message clearfix">
                <form action="" method="post" id="talkSendMessage">
                    <textarea name="message-data" id="message-data" placeholder ="Type your message" rows="3"></textarea>
                    <input type="hidden" name="_id" value="{{@request()->route('id')}}">
                    <button type="submit" class="btn btn-primary">Send</button>
                </form>

            </div> <!-- end chat-message -->
        </div>
        <div class="col-md-2">
            @include("includes.adblock")
        </div>
    </div>




</div> <!-- end container -->






@stop

@section('jsfiles')
<script src='http://cdnjs.cloudflare.com/ajax/libs/handlebars.js/3.0.0/handlebars.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/list.js/1.1.1/list.min.js'></script>
<script>
$(document).ready(function () {

    $('#talkSendMessage').on('submit', function (e) {
        e.preventDefault();
        var url, request, tag, data;
        tag = $(this);
        data = tag.serialize();

        request = $.ajax({
            method: "post",
            url: '{{Route("message.send")}}',
            data: data
        });

        request.done(function (response) {
            if (response.status == 'success') {
                $('#talkMessages').append(response.html);
                tag[0].reset();
            }
        });

    });
});



</script>

<script>
    var show = function (data) {
        alert(data.sender.name + " - '" + data.message + "'");
    };

    var msgshow = function (data) {
        var html = '<li id="message-' + data.id + '">' +
                '<div class="message-data">' +
                '<span class="message-data-name"> ' + data.sender.name + '</span>' +
                '<span class="message-data-time">1 Second ago</span>' +
                '</div>' +
                '<div class="message my-message">' +
                data.message +
                '</div>' +
                '</li>';

        $('#talkMessages').append(html);
    };

</script>
{!! talk_live(['user'=>["id"=>auth()->user()->id, 'callback'=>['msgshow']]]) !!}

@stop