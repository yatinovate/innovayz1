@extends('layouts.master')
@section('headscript')
<title>Messages | Innovayz</title>
<style>
    .allmessage_wrap{
        margin: 80px 0;
    }
    .people-list {
        background: #fff;
    }
    .people-list .search {
        padding: 20px;
    }
    .people-list input {
        border-radius: 3px;
        border: none;
        padding: 14px;
        color: white;
        background: #6A6C75;
        width: 90%;
        font-size: 14px;
    }
    .people-list .fa-search {
        position: relative;
        left: -25px;
    }
    .people-list ul li {
        padding: 20px 0;
        border-bottom: #65AAC0 solid 1px
    }
    .people-list ul li:last-child {
        border-bottom: none
    }
    .people-list img {
        width: 100%;
        height: 40px;
        width: 40px
    }
    .people-list .about {
        float: left;
        margin-top: 8px;
    }
    .people-list .about {
        padding-left: 8px;
    }
    .people-list .status {
        color: #92959E;
        font-size: 12px;
        margin: 5px 0;
    }

    .clearfix:after {
        visibility: hidden;
        display: block;
        font-size: 0;
        content: " ";
        clear: both;
        height: 0;
    }

    .name {
        color: #0099da;
        font-weight: bold;
        font-size: 16px
    }
    .panel-info>.panel-heading{
        background-color:  #65AAC0;
        color: #fff;
    }

</style>
@stop
@section('content')
<div class="allmessage_wrap">
    <div class="container">
        <div class="row">
            <div class="col-md-8" >
                <div class="panel panel-info people-list" id="people-list">
                    <div class="panel-heading text-center"><i class="fa fa-envelope-square"></i> All Messages</div>
                    <div class="panel-body">

                        <ul class="list">
                            @foreach($threads as $inbox)

                            @if(!is_null($inbox->thread))
                            <li class="clearfix">
                                <a href="{{route('message.read', ['id'=>$inbox->withUser->id])}}">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <img src="{{asset($inbox->withUser->avatar)}}" alt="avatar" />
                                        </div>
                                        <div class="col-md-10">
                                            <div class="about">
                                                <div class="name">{{$inbox->withUser->name}}</div>
                                                <div class="status">
                                                    @if(auth()->user()->id == $inbox->thread->sender->id)
                                                    <span class="fa fa-reply"></span> <span>{{$inbox->thread->message}}</span>
                                                    @else
                                                    @if($inbox->thread->is_seen)
                                                    <span>{{$inbox->thread->message}}</span>
                                                    @else
                                                    <span style="font-weight: bold;color: #000">{{$inbox->thread->message}}</span>
                                                    @endif
                                                    @endif
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                </a>
                            </li>
                            @endif
                            @endforeach

                        </ul>
                    </div>
                </div>            
            </div>
            <div class="col-md-3 col-md-offset-1">
                @include("includes.adblock")
            </div>
        </div>




    </div> <!-- end container -->

</div>

@stop

@section('jsfiles')
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/handlebars.js/3.0.0/handlebars.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/list.js/1.1.1/list.min.js'></script>
<script>
$(document).ready(function () {

    $('#talkSendMessage').on('submit', function (e) {
        e.preventDefault();
        var url, request, tag, data;
        tag = $(this);
        data = tag.serialize();

        request = $.ajax({
            method: "post",
            url: '{{Route("message.send")}}',
            data: data
        });

        request.done(function (response) {
            if (response.status == 'success') {
                $('#talkMessages').append(response.html);
                tag[0].reset();
            }
        });

    });
});



</script>

<script>
    var show = function (data) {
        alert(data.sender.name + " - '" + data.message + "'");
    };

    var msgshow = function (data) {
        var html = '<li id="message-' + data.id + '">' +
                '<div class="message-data">' +
                '<span class="message-data-name"> <a href="#" class="talkDeleteMessage" data-message-id="' + data.id + '" title="Delete Messag"><i class="fa fa-close" style="margin-right: 3px;"></i></a>' + data.sender.name + '</span>' +
                '<span class="message-data-time">1 Second ago</span>' +
                '</div>' +
                '<div class="message my-message">' +
                data.message +
                '</div>' +
                '</li>';

        $('#talkMessages').append(html);
    };

</script>
{!! talk_live(['user'=>["id"=>auth()->user()->id, 'callback'=>['msgshow']]]) !!}

@stop