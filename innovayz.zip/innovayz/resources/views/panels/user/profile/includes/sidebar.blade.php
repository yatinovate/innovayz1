<div class="panel-group" id="accordion">
    <div class="panel panel-default">
        <div class="panel-heading">
            <a href="#aboutus" data-toggle="tab"  style="color: #000"><h4 class="panel-title dash_header">About<span class="fa fa-user-md pull-right"></span></h4></a>
        </div>
    </div>
    <div class="panel panel-default">
        <div class="panel-heading">
            @if(Auth::check())
            <a href="#postactive" style="color: #000" data-toggle="tab"><h4 class="panel-title dash_header">Posts<span class="fa fa-newspaper-o pull-right"></span></h4></a>
            @else
            <a href="#postactive" style="color: #000" data-toggle="tab" id="logopener"><h4 class="panel-title dash_header">Posts<span class="fa fa-newspaper-o pull-right"></span></h4></a>
            @endif
            
        </div>
    </div>
    
    <div class="panel panel-default">
        <div class="panel-heading">
            <a href="#connectionlist" data-toggle="tab" style="color: #000"><h4 class="panel-title dash_header">Connections<span class="fa fa-users pull-right"></span></h4></a>
        </div>
    </div>
    <div class="panel panel-default">
        <div class="panel-heading">
            <a href="#elibpanel" data-toggle="tab" style="color: #000"><h4 class="panel-title dash_header">Library<span class="fa fa-book pull-right"></span></h4></a>
        </div>
    </div>
    <div class="panel panel-default">
        <div class="panel-heading">
            <a href="#questionpan" data-toggle="tab" style="color: #000"><h4 class="panel-title dash_header">Questionnaire<span class="fa fa-question-circle pull-right"></span></h4></a>
        </div>
    </div>
</div>

