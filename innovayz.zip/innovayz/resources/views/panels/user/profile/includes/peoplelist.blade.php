<div class="search">
    <h4>Messages</h4>
</div>
<ul class="list">
    @foreach($threads as $inbox)

    @if(!is_null($inbox->thread))
    <?php
        $activeclass="";
        if($inbox->withUser->id== $activeid){
            $activeclass="active";
        }
        ?>
    
    <li class="clearfix {{$activeclass}}">
        <a href="{{route('message.read', ['id'=>$inbox->withUser->id])}}">
            <img src="{{asset($inbox->withUser->avatar)}}" alt="avatar" />
            <div class="about">
                <div class="name">{{$inbox->withUser->name}}</div>
                <div class="status">
                    @if(auth()->user()->id == $inbox->thread->sender->id)
                    <span class="fa fa-reply"></span>
                    @endif
                    <span>{{substr($inbox->thread->message, 0, 20)}}</span>
                </div>
            </div>
        </a>
    </li>
    @endif
    @endforeach

</ul>