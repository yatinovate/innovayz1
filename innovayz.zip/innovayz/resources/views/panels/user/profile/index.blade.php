@extends('layouts.master')
@section('headscript')
<link rel="stylesheet" href="{{asset("Dashboard/css/dashboard.css")}}">
<title>Profile | {{$userdata->name}} | Innovayz</title>
<style>
    .post_item p{
        -ms-word-break: break-all;
        word-break: break-all;

        /* Non standard for webkit */
        word-break: break-word;

        -webkit-hyphens: auto;
        -moz-hyphens: auto;
        -ms-hyphens: auto;
        hyphens: auto;
    }
    .panel p{
        line-height: 1.9em;
        word-break: break-word;

        -webkit-hyphens: auto;
        -moz-hyphens: auto;
        -ms-hyphens: auto;
        hyphens: auto;
    }
    .panel p span{
        font-weight: bold;
    }
    .coursetile{
        margin-bottom: 10px;
        padding-bottom: 10px;
        border-bottom: 1px solid #777;
    }
    .coursetile:last-child{
        margin-bottom: 0;
        border-bottom: none;
    }
    #connectionlist .panel-body .nav-pills{
        background: #f2f2f2
    }
    #connectionlist .tab-content{
        padding: 30px 0;
    }
</style>
@stop
@section('content')
@include("panels.user.profile.includes.upper_panel")

<div class="container-fluid">
    <div class="row">
        <div class="col-md-2">
            @include("panels.user.profile.includes.sidebar")
        </div>
        <div class="col-md-6 post_section">
            @include("errors.status")
            <div class="tab-content">
                <div id="postactive" class="tab-pane fade ">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-12">
                                    <h2 class="panel-title">Posts</h2>
                                </div>
                            </div>
                        </div>
                        <div class="panel-body">
                            @if(Auth::check())
                            @if(count($postdta))
                            @foreach ($postdta as $poster)
                            <div class="post_item">
                                <div class="panel panel-default">
                                    <div class="panel-body">
                                        <?php
                        $usermain = \App\Models\User::find($poster->post->user_id);
                        ?>
                                        @if($poster->post->Taguser)
                                        
                                        @if(Auth::check())
                                        @if($poster->post->user_id!=Auth::user()->id)
                                        <?php
                                        $usermain = \App\Models\User::find($poster->post->user_id);
                                        $postusers = \App\Models\Profile\PostKnowledgeUser::where("post_id", $poster->post->id)->get();
                                        $usernames = "";
                                        foreach ($postusers as $post) {
                                            if ($post->user_id != $poster->post->user_id) {
                                               $allusers = \App\Models\User::find($post->user_id);
                                                    $usernames = $usernames . ' , <a style="color: #007acc" href="' . Route("profile.index", ["user-id" => $allusers->id, 'user-name' => $allusers->name]) . '">' . $allusers->name . '</a>'; 
                                            }
                                        }
                                        ?>
                                        <h2>{{ $usermain->name }} with {!!preg_replace('/^[,\s]+|[\s,]+$/', '', $usernames);!!}</h2>
                                        <br>
                                        @endif
                                        @else
                                        <?php
                                        $usermain = \App\Models\User::find($poster->post->user_id);
                                        $postusers = \App\Models\Profile\PostKnowledgeUser::where("post_id", $poster->post->id)->get();
                                        $usernames = "";
                                        foreach ($postusers as $post) {
                                            if ($post->user_id != $poster->post->user_id) {
                                               $allusers = \App\Models\User::find($post->user_id);
                                                    $usernames = $usernames . ' , <a style="color: #007acc" href="' . Route("profile.index", ["user-id" => $allusers->id, 'user-name' => $allusers->name]) . '">' . $allusers->name . '</a>'; 
                                            }
                                        }
                                        ?>
                                        <h2>{{ $usermain->name }} with {!!preg_replace('/^[,\s]+|[\s,]+$/', '', $usernames);!!}</h2>
                                        <br>
                                        @endif
                                        
                                        @endif                                      
                                        <h3>{{ $poster->post->Subject }}</h3>
                                        {!! urldecode($poster->post->Description) !!}
                                        @if($poster->post->attachement)<br>
                                        <a href="{{URL::to("laradrop/download/".$poster->post->attachement_id)}}">{{$poster->post->attachement}}</a>
                                        @endif
                                        
                                        <br><br>
                        <h2 style="text-align: right;">Post by: <a style="color: #007acc" href="{{Route("profile.index",["user-id" => $usermain->id, 'user-name' => $usermain->name])}}">{{ $usermain->name }}</a></h2>
                                    </div>
                                </div>
                            </div>
                            @endforeach   
                            @else
                            <p>No Posts to show</p>     
                            @endif
                            @endif
                        </div>
                    </div>
                </div>
                <div id="aboutus" class="tab-pane fade in active">
                    
                    @if($userdata->user_type=="teachers")
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-12">
                                    <h2 class="panel-title">Description</h2>
                                </div>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <p>{{$aboutint}}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    @if(count($userdata->teaching))
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-12">
                                    <h2 class="panel-title">Experience Details</h2>
                                </div>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <p><span>Total Experince</span> : {{$userdata->teacher->experience}}</p>
                                </div>
                                 <div class="col-md-6">
                                     <p><span>Grade</span> : {{$userdata->teacher->grades}}</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <p><span>Previous organization</span>  : {{$userdata->teacher->Previous_Organization}}</p>
                                </div>
                                 <div class="col-md-6">
                                     <p><span>Current organization</span> : {{$userdata->teacher->current_Organization}}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endif
                    @if(count($userdata->teaching))
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-12">
                                    <h2 class="panel-title">Teaching Subjects Details</h2>
                                </div>
                            </div>
                        </div>
                        <div class="panel-body">
                            @foreach($userdata->teaching as $teach)
                            <div class="row">
                                <div class="col-md-6">
                                    <?php
                                    $cate= \App\Models\User\QualificationList::find($teach->Category);
                                    ?>
                                    <p><span>Category</span> : {{$cate->qulaification}}</p>
                                </div>
                                <div class="col-md-6">
                                    <?php
                                    $area= App\Models\User\AreaIntrest::find($teach->Subject);
                                    ?>
                                    <p><span>Subject</span> : {{$area->area_intrest}}</p>
                                </div>
                                
                            </div>
                            @endforeach
                        </div>
                    </div>
                    @endif
                    @elseif($userdata->user_type=="colleges")
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-12">
                                    <h2 class="panel-title">Institute Details</h2>
                                </div>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <p>{{$aboutint}}</p>
                                </div>
                            </div>
                            @if(count($userdata->college))
                            <div class="row">
                                <div class="col-md-6">
                                    <p><span>Establishment year</span> : {{$userdata->college->establishment}}</p>
                                </div>
                                 <div class="col-md-6">
                                     <p><span>Affilated By</span> : {{$userdata->college->affilatedby}}</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <p><span>Address</span> : {{$contact->address}}</p>
                                </div>
                                 <div class="col-md-6">
                                     <p><span>Country</span> : {{$contact->country}}</p>
                                </div>
                                <div class="col-md-6">
                                     <p><span>State</span> : {{$contact->state}}</p>
                                </div>
                                <div class="col-md-6">
                                     <p><span>City</span> : {{$contact->city}}</p>
                                </div>
                                <div class="col-md-6">
                                     <p><span>Pin Code</span> : {{$contact->pncode}}</p>
                                </div>
                                <div class="col-md-6">
                                     <p><span>Contact No</span> : {{$contact->mobile}}</p>
                                </div>
                                <div class="col-md-6">
                                     <p><span>Skype</span> : {{$contact->skype}}</p>
                                </div>
                            </div>
                            @endif
                        </div>
                    </div>
                    @if(count($userdata->course))
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-12">
                                    <h2 class="panel-title">Course Details</h2>
                                </div>
                            </div>
                        </div>
                        <div class="panel-body">
                            @foreach($userdata->course as $course)
                            <div class="row coursetile">
                                <div class="col-md-6">
                                    <?php
                                    $coursenamead= \App\Models\User\QualificationList::find($course->course_name);
                                    ?>
                                    <p><span>Course Name</span> : {{$coursenamead->qulaification}}</p>
                                </div>
                                 <div class="col-md-6">
                                     <p><span>Duration</span> : {{$course->duration_year}} years {{$course->duration_month}} months</p>
                                </div>
                                <div class="col-md-12">
                                     <p><span>Description</span> : {{$course->course_desc}}</p>
                                </div>
                                <div class="col-md-12">
                                     <p><span>Eligibility Criteria </span> : {{$course->eligi_criteria}}</p>
                                </div>
                                <div class="col-md-6">
                                    <?php
                                    $coursename="";
                                    if($course->stream!=""){
                                        $coursenamead= \App\Models\User\QualificationList::find($course->stream);
                                        $coursename=$coursenamead->qulaification;
                                    }
                                    ?>
                                    <p><span>Specialization</span> : {{$coursename}}</p>
                                </div>
                                <div class="col-md-6">
                                    <p><span>Fee</span> : Rs.{{$course->fee}} / {{$course->fee_type}}</p>
                                </div>
                                                                     
                            </div>
                            @endforeach
                            
                        </div>
                    </div>
                    @endif
                    @elseif($userdata->user_type=="students")
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-12">
                                    <h2 class="panel-title">Description</h2>
                                </div>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <p>{{$aboutint}}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    @if(count($userdata->qulaifiaction))
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-12">
                                    <h2 class="panel-title">Qualification Details</h2>
                                </div>
                            </div>
                        </div>
                        <div class="panel-body">
                            @foreach($userdata->qulaifiaction as $teach)
                            <div class="row">
                                <div class="col-md-6">
                                    <?php
                                    $category= \App\Models\User\QualificationList::find($teach->qualification);
                                    ?>
                                    <p><span>Qualification</span> : {{$category->qulaification}}</p>
                                </div>
                                <div class="col-md-6">
                                    <?php
                                    $stream= \App\Models\User\QualificationList::find($teach->stream);
                                    ?>
                                    <p><span>Specialization</span> : {{$stream->qulaification}}</p>
                                </div>
                                <div class="col-md-12">
                                    <?php
                                    $institutte1='';
                                    if($teach->institute){
                                     
                                    $institutte= \App\Models\User\UserInstitute::find($teach->institute); 
                                    $institutte1=$institutte->institute;
                                    }
                                    ?>
                                    <p><span>Institute</span> : {{$institutte1}}</p>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                    @endif
                    @endif
                </div>
                
                <div id="questionpan" class="tab-pane fade">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-12">
                                    <h2 class="panel-title">Questionare</h2>
                                </div>
                            </div>
                        </div>
                        <div class="panel-body">
                            @if(count($questionar))
                            @foreach ($questionar as $poster)                            
                            <div class="col-md-6 user-box">
                                <div class="well well-sm">
                                    <h4><a href="{{Route("question.q_detail",["q_code"=>$poster->id,'q_detail'=>$poster->question])}}">{!! $poster->question !!}</a></h4>
                                </div>
                            </div>
                            @endforeach
                            @else
                            <p>No Questions</p>
                            @endif
                        </div>
                    </div>
                </div>
                <div id="elibpanel" class="tab-pane fade">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-12">
                                    <h2 class="panel-title">Library</h2>
                                </div>
                            </div>
                        </div>
                        <div class="panel-body">
                            @if(count($elib))
                            @foreach ($elib as $poster)                            
                            <div class="col-md-6 user-box">
                                <div class="well well-sm">
                                    <h4><a href="{{URL::to("laradrop/download/".$poster->id)}}">{!! $poster->alias !!}</a></h4>
                                </div>
                            </div>
                            @endforeach
                            @else
                            <p>No Documents</p>
                            @endif
                        </div>
                    </div>
                </div>

                <div id="connectionlist" class="tab-pane fade">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-12">
                                    <h2 class="panel-title">Connections</h2>
                                </div>
                            </div>
                        </div>
                        <div class="panel-body">
                            
                            <ul class="nav nav-pills nav-justified">
                        <li class="active"><a data-toggle="pill" href="#Followers">Followers</a></li>
                        <li><a data-toggle="pill" href="#Following">Following</a></li>
                    </ul>

                    <div class="tab-content">
                        <div id="Followers" class="tab-pane fade in active">

                            @if(count($userarray))
                            @foreach ($userarray as $poster)                            
                            <div class="col-md-6 user-box">
                                <div class="well well-sm">
                                    <div class="row">
                                        <div class="col-sm-6 col-md-4">
                                            <img src="{{asset($poster->user->avatar)}}" alt="" class="img-rounded img-responsive" />
                                        </div>
                                        <div class="col-sm-6 col-md-8">
                                            <h4><a href="{{Route("profile.index",["user-id"=>$poster->user->id,'user-name'=>$poster->user->name])}}">{!! $poster->user->name !!}</a></h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                            @else
                            <p>No Connections</p>
                            @endif
                        </div>
                        <div id="Following" class="tab-pane fade">

                            @if(count($folloingarr))
                            @foreach ($folloingarr as $poster)
                            <div class="col-md-6 user-box">
                                <div class="well well-sm">
                                    <div class="row">
                                        <div class="col-sm-6 col-md-4">
                                            <img src="{{asset($poster["avatar"])}}" alt="" class="img-rounded img-responsive" />
                                        </div>
                                        <div class="col-sm-6 col-md-8">
                                            <h4><a href="{{Route("profile.index", ["user-id" => $poster["userid"], 'user-name' => $poster["user_name"]])}}">{!! $poster["user_name"] !!}</a></h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                            @else
                            <p>No Connections</p>
                            @endif
                        </div>
                    </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        @if($userdata->user_type=="colleges")
        <div class="col-md-2" id="sugesteduser">
            <?php
            $allcuser= App\Models\User::where("user_type","colleges")->where("activated",1)->where("id","!=",$userdata->id)->take(5)->get();
            ?>
            @if(count($allcuser))
            <div class="panel panel-default">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-12">
                            <h2 class="panel-title">Similar Profiles</h2>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
                    <ul class="list-group techer_list">
                        @foreach ($allcuser as $uer)                               
                        <li class="list-group-item text-center">
                            <a href="{{Route("profile.index", ["user-id" => $uer->id, 'user-name' => $uer->name])}}"> 
                                <img src="{{asset($uer->avatar)}}" alt="picture" class="img-responsive">
                                <span>{{$uer->name}}</span>
                            </a>
                        </li>                    
                        @endforeach
                    </ul>
                </div>
            </div>
            @endif
        </div>
        @else
        <div class="col-md-2" id="sugesteduser">
            @if(count($alluser))
            <div class="panel panel-default">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-12">
                            <h2 class="panel-title">Similar Profiles</h2>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
                    <ul class="list-group techer_list">
                        <?php
                        for($ix=0;$ix<5;$ix++){
                            if(isset($alluser[$ix])){
                            $user = \App\Models\User::find($alluser[$ix]);
                            if($userdata->user_type==$user->user_type){
                            
                            ?>
                        <li class="list-group-item text-center">
                            <a href="{{Route("profile.index", ["user-id" => $user->id, 'user-name' => $user->name])}}"> 
                                <img src="{{asset($user->avatar)}}" alt="picture" class="img-responsive">
                                <span>{{$user->name}}</span>
                            </a>
                        </li>
                        <?php
                            }
                        }
                        }
                        ?>
                    </ul>
                </div>
            </div>
            @endif
        </div>
        @endif
        
        <div class="col-md-2">
            @include("includes.adblock")
        </div>

    </div>


</div>

@stop



@section('jsfiles')
<script>
    $(function () {
        $("#logopener").click(function(){
            $(".signup_icon1").trigger("click");
        });
        $("#logpop").click(function(){
            $(".signup_icon1").trigger("click");
            <?php
            $url = \Illuminate\Support\Facades\Input::fullUrl();
                session(['url.intended' => $url]);
            ?>
        });
        $('#ask_questn').formValidation({
            framework: 'bootstrap',
            icon: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                send_message: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }
            }
        });

    });
</script>
<?php
if(Illuminate\Support\Facades\Input::get("message")){
    ?>
<script>
    $(function(){
        $("#messgeropener").trigger("click");
    });
</script>
<?php
}
?>
@if(!Auth::check() && Illuminate\Support\Facades\Input::get("message"))
<?php 
$url = Illuminate\Support\Facades\Input::fullUrl();
session(['url.intended' => $url]);
?>
<script>
    $(function(){
        $(".signup_icon1").trigger("click");
    });
</script>
@endif
@endsection




