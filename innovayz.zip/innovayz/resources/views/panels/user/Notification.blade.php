@extends('layouts.master')
@section('headscript')
<link rel="stylesheet" href="{{asset("Dashboard/css/dashboard.css")}}">
<title>All Notifications | Innovayz</title>
<style>
.notify_wrap{
    margin: 80px 0;
}
.post_section{
    background: #fff;
    padding: 20px;
}
.content:hover{
    text-decoration: none;
}
</style>

@stop
@section('content')
<div class="notify_wrap">
    <div class="container">
    <div class="row">
        <div class="col-md-8 post_section">
            <h1 class="text-center">All Notification</h1><br>
            @include("errors.status")
            @if(count($notify))
            @foreach($notify as $nt)
            <a class="content" href="{{url($nt->link)}}">
                        <div class="notification-item">
                            <h4 class="item-title">{{$nt->subject}}</h4>
                            <p class="item-info">{{$nt->body}}</p>
                        </div>
                      </a>
            @endforeach
            
            
            @endif
            

        </div>
        <div class="col-md-3 col-md-offset-1">
            @include("includes.adblock")
        </div>

    </div>


</div>
</div>


@stop







