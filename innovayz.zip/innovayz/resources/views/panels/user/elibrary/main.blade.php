@extends('layouts.master')

@section('headscript')
<link rel="stylesheet" href="{{asset("Dashboard/css/elibrary.css")}}">
<link href="{{asset("vendor/jasekz/laradrop/css/styles.css")}}" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Lato:300" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="{{asset("Dashboard/css/gdrive.css")}}">
<link rel="stylesheet" href="{{asset("Dashboard/css/dashboard.css")}}">
<link href="{{asset("css/magicsuggest-min.css")}}" rel="stylesheet">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<title>E-Library | Innovayz</title>
@endsection
@section('content')

<div class="elibary">
    <div class="container">
        <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
                <div class="bhoechie-tab-menu">
                    <div class="list-group">
                        <a href="{{Route("e-library")}}" class="list-group-item active"><i class="fa fa-folder-open"></i>Library Items</a>
                        <a href="{{Route("elib.gview")}}" class="list-group-item "><i class="fa fa-google"></i>Google Drive</a>                        
                    </div>
                    @if(isset($files))
                    <a href="{{Route("gAcessDisconnect")}}" class="list-group-item list-group-item-danger">
                        <i class="fa fa-stop-circle-o"></i>
                        Disconnect Drive
                    </a>
                    @endif
                </div>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
                @include("errors.status")
                <div class="bhoechie-tab">
                    <div class="bhoechie-tab-content  {{ isset($gdocuments) ? '' : 'active' }}">
                        <div class="laradrop" laradrop-csrf-token="{{ csrf_token() }}" user-valid="{{Auth::user()->id}}"> </div><div class="clearfix">

                        </div>
                    </div>

                </div>
            </div>
            <div class="col-md-2 ">
                @include("includes.adblock")
            </div>


        </div>
    </div>
</div>

<div id="deletedialog" title="Deletion Alert">
    <p></p>
</div>
<div class="modal fade elibpop" id="addlink" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content question_modal">
            <div class="modal-header"><button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center">Add Link</h4>
            </div>
            <div class="modal-body clearfix">
                <form class="form-horizontal" method="post"  id="addlinkform">
                    {{ csrf_field() }}
                    <div class="form-group">                                              
                        <label class="col-sm-12 control-label text-left">Enter the Link</label>
                        <div class="col-sm-12">
                            <input type="text" class="form-control"  name="linkname"  placeholder="Enter the Link" />
                        </div>
                    </div>
                    <div class="form-group">                                              
                        <label class="col-sm-12 control-label text-left">Title of Web page</label>
                        <div class="col-sm-12">
                            <input type="text" class="form-control"  name="linktitle"  placeholder="Title of Web page" />
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <input type="submit" class="btn btn-primary pull-right" value="Add Link">
                        </div>
                    </div>

                </form>
            </div>                                       
        </div>

    </div>
</div>

<div class="modal fade" id="postknowledge" tabindex="-1" role="dialog" 
     aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <button type="button" class="close" 
                        data-dismiss="modal">
                    <span aria-hidden="true">&times;</span>
                    <span class="sr-only">Close</span>
                </button>
                <h4 class="modal-title" id="myModalLabel">
                    Post your Knowledge
                </h4>
            </div>

            <!-- Modal Body -->
            <div class="modal-body">
                <div class="modal-body">
                    <form class="form-horizontal" role="form" id="postform" method="post" action="{{Route("postknowledgeattachement")}}">
                        {{ csrf_field() }}
                        <div class="form-group">
                            <label  class="col-sm-12 control-label">Subject</label>
                            <div class="col-sm-12">
                                <input type="text" class="form-control" placeholder="Enter Your Subject" name="subject" id="subject"/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label  class="col-sm-12 control-label">Tagging</label>
                            <div class="col-sm-12">
                                <input type="text" class="form-control" placeholder="Tag Connections" id="tagcon" name="tagcon"/>
                                <input type="hidden" class="form-control" id="tagcon1" name="tagcon1"/>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-12 control-label">Description</label>
                            <div class="col-sm-12">
                                <textarea class="form-control" id="poster"  placeholder="Enter details of post" name="poster"></textarea>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-12 control-label">Attachement</label>
                            <div class="col-sm-12">
                                <input type="text" class="form-control" placeholder="" name="attachement" readonly="" id="attchement" />
                                <input type="hidden" class="form-control"  name="attachement_id"  id="attchement_id" />
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-offset-2 col-sm-10">
                                <button type="submit" class="btn btn-info  btn-lg pull-right" id="next-step">Post</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@section('jsfiles')
<script src="{{asset("js/magicsuggest-min.js")}}"></script>
<script type="text/javascript" src="//cdn.tinymce.com/4/tinymce.min.js"></script>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.min.js" ></script>
<script src="{{asset("vendor/jasekz/laradrop/js/enyo.dropzone.js")}}"></script>
<script>
jQuery.fn.laradrop = function (options) {
    Dropzone.autoDiscover = false;
    options = options == undefined ? {} : options;
    var fileHandler = options.fileHandler ? options.fileHandler : '{{URL::to("laradrop")}}',
            fileDeleteHandler = options.fileDeleteHandler ? options.fileDeleteHandler : '{{URL::to("laradrop/0")}}',
            fileSrc = options.fileSrc ? options.fileSrc : '{{URL::to("laradrop")}}',
            fileCreateHandler = options.fileCreateHandler ? options.fileCreateHandler : '{{URL::to("laradrop/create")}}',
            fileMoveHandler = options.fileMoveHandler ? options.fileMoveHandler : '{{URL::to("laradrop/move")}}',
            containersUrl = options.containersUrl ? options.containersUrl : '{{Route("laradrop.containers")}}',
            csrfToken = options.csrfToken,
            userid = options.csrfToken,
            csrfTokenField = options.csrfTokenField ? options.csrfTokenField : '_token',
            actionConfirmationText = options.actionConfirmationText ? options.actionConfirmationText : 'Are you sure?',
            breadCrumbRootText = options.breadCrumbRootText ? options.breadCrumbRootText : 'Root Directory',
            folderImage = options.folderImage ? options.folderImage : 'vendor/jasekz/laradrop/img/genericThumbs/folder.png',
            onInsertCallback = options.onInsertCallback ? options.onInsertCallback : null,
            onSuccessCallback = options.onSuccessCallback ? options.onSuccessCallback : null,
            onErrorCallback = options.onErrorCallback ? options.onErrorCallback : null;

    var uid = new Date().getTime();
    laradropObj = jQuery(this),
            laradropContainer = null,
            laradropPreviewContainer = null,
            dz = null,
            currentFolderId = null,
            breadCrumbs = [],
            customData = options.customData ? options.customData : {},
            views = {
                main: null,
                preview: null,
                file: null
            };

    // try html atttributes if not set in options
    if (!fileHandler && laradropObj.attr('laradrop-upload-handler')) {
        fileHandler = laradropObj.attr('laradrop-upload-handler');
    }
    if (!fileMoveHandler && laradropObj.attr('laradrop-file-move-handler')) {
        fileMoveHandler = laradropObj.attr('laradrop-file-move-handler');
    }
    if (!fileDeleteHandler && laradropObj.attr('laradrop-file-delete-handler')) {
        fileDeleteHandler = laradropObj.attr('laradrop-file-delete-handler');
    }
    if (!fileSrc && laradropObj.attr('laradrop-file-source')) {
        fileSrc = laradropObj.attr('laradrop-file-source');
    }
    if (!csrfToken && laradropObj.attr('laradrop-csrf-token')) {
        csrfToken = laradropObj.attr('laradrop-csrf-token');
    }

    if (!userid && laradropObj.attr('user-valid')) {
        userid = laradropObj.attr('user-valid');
    }
    if (!csrfTokenField && laradropObj.attr('laradrop-csrf-token-field')) {
        csrfTokenField = laradropObj.attr('laradrop-csrf-token-field');
    }
    if (!fileCreateHandler && laradropObj.attr('laradrop-file-create-handler')) {
        fileCreateHandler = laradropObj.attr('laradrop-file-create-handler');
    }
    if (!containersUrl && laradropObj.attr('laradrop-containers')) {
        containersUrl = laradropObj.attr('laradrop-containers');
    }

    // init containers, default options & data
    jQuery.ajax({
        url: containersUrl,
        type: 'GET',
        dataType: 'json',
        success: function (res) {

            // populate html templates
            views.main = res.data.main.replace('[[uid]]', uid);
            views.preview = res.data.preview;
            views.file = res.data.file;

            // setup file container
            laradropObj.append(getLaradropContainer());
            laradropContainer = jQuery('#laradrop-container-' + uid),
                    laradropPreviewsContainer = laradropContainer.find('.laradrop-previews');
            laradropPreviewsContainer.attr('id', 'laradrop-previews-' + uid);

            // 'add folder' 
            laradropContainer.find('.btn-add-folder').click(function (e) {
                e.preventDefault();
                jQuery.ajax({
                    url: fileCreateHandler + '?pid=' + currentFolderId + '&userid=' + userid,
                    type: 'POST',
                    dataType: 'json',
                    headers: {'X-CSRF-TOKEN': csrfToken},
                    success: function (res) {
                        jQuery.get(fileSrc + '?pid=' + currentFolderId + '&userid=' + userid, function (res) {
                            displayMedia(res);
                        });
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        handleError(jqXHR, textStatus, errorThrown);
                    }
                });
            });
            $('#addlinkform').formValidation({
                framework: 'bootstrap',
                icon: {
                    valid: 'glyphicon glyphicon-ok',
                    invalid: 'glyphicon glyphicon-remove',
                    validating: 'glyphicon glyphicon-refresh'
                },
                fields: {
                    linkname: {
                        validators: {
                            notEmpty: {
                                message: 'required'
                            }, uri: {
                                message: 'webpage is not valid'
                            }
                        }
                    }, linktitle: {
                        validators: {
                            notEmpty: {
                                message: 'required'
                            }
                        }
                    }
                }
            }).on('success.form.fv', function (e) {
                e.preventDefault();
                var $form = $(e.target),
                        fv = $form.data('formValidation');
                $.ajax({
                    url: fileCreateHandler + '?pid=' + currentFolderId + '&userid=' + userid,
                    type: 'POST',
                    data: $form.serialize(),
                    success: function (result) {
                        $("#addlink").modal('toggle');
                        jQuery.get(fileSrc + '?pid=' + currentFolderId + '&userid=' + userid, function (res) {
                            displayMedia(res);
                        });
                    }
                });
            });
            $('#search-form').bind('keypress keydown keyup', function (e) {
                if (e.keyCode == 13) {
                    e.preventDefault();
                }
            });

            $('#searchfiles').keyup(function (e) {
                e.preventDefault();
                var key = $(this).val();
                if (key.length === 0)
                {
                    window.location.reload();
                } else if (key.length > 1)
                {
                    $(".laradrop-body").empty();
                    jQuery.ajax({
                        url: '{{URL::to("laradrop/search")}}',
                        type: 'POST',
                        data: { searchkey: key, userid: userid },
                        dataType: 'json',
                        cache: false,
                        headers: {'X-CSRF-TOKEN': csrfToken},
                        success: function (res) {
                            $(".laradrop-body").html(res.filename);
                            laradropContainer.find('.laradrop-file-insert').click(function () {

                                var $text = jQuery(this).closest('.laradrop-thumbnail').find(".laradrop-filealias"), $textva = $text.text(),
                                        $input = $('<input type="text" value=' + $textva + ' />');
                                $text.hide().after($input);
                                $input.val($text.html()).show().focus().keypress(function (e) {
                                    var key = e.which;
                                    if (key == 13) // enter key
                                    {
                                        $input.hide();
                                        $text.html($input.val()).show();
                                        return false;
                                    }
                                })
                                        .focusout(function () {
                                            var newname = $input.val();
                                            $input.hide();
                                            $text.show();
                                            var fileId = jQuery(this).closest('.laradrop-thumbnail').attr('file-id');
                                            jQuery.ajax({
                                                url: '{{Route("laradrop.rename")}}',
                                                type: 'POST',
                                                data: 'pid=' + fileId + '&pdata=' + escape(newname),
                                                dataType: 'json',
                                                headers: {'X-CSRF-TOKEN': csrfToken},
                                                success: function (res) {
                                                    $text.html(newname);
                                                },
                                                error: function (jqXHR, textStatus, errorThrown) {
                                                    handleError(jqXHR, textStatus, errorThrown);
                                                }
                                            });

                                        });


                            });
                            laradropContainer.find('.laradrop-file-delete').click(function (e) {
                                e.preventDefault();
                                var fileId = jQuery(this).closest('.laradrop-thumbnail').attr('file-id');

                                fileDeleteHandler = fileDeleteHandler.replace(fileDeleteHandler.substr(fileDeleteHandler.lastIndexOf('/')), '/' + fileId);

                                if (!confirm(actionConfirmationText)) {
                                    return false;
                                }

                                jQuery.ajax({
                                    url: fileDeleteHandler,
                                    type: 'DELETE',
                                    dataType: 'json',
                                    headers: {'X-CSRF-TOKEN': csrfToken},
                                    success: function (res) {
                                        if (res.custerrors) {
                                            $("#deletedialog p").html(res.custerrors)
                                            $("#deletedialog").dialog();
                                        } else {
                                            jQuery.get(fileSrc + '?pid=' + currentFolderId + '&userid=' + userid, function (files) {
                                                displayMedia(files);
                                            });
                                        }
                                    },
                                    error: function (jqXHR, textStatus, errorThrown) {
                                        handleError(jqXHR, textStatus, errorThrown);
                                    }
                                });
                            });
                            laradropContainer.find('.doenloadd').click(function (e) {
                                var fileid = jQuery(this).closest('.laradrop-thumbnail').attr("file-id");
                                window.location.href = '{{URL::to("laradrop/download/")}}/' + fileid;

                            });
                            laradropContainer.find('.makepublic').click(function (e) {
                                var fireevent = $(this);
                                e.preventDefault();
                                var fileId = jQuery(this).closest('.laradrop-thumbnail').attr('file-id');
                                jQuery.ajax({
                                    url: '{{URL::to("laradrop/makepublic/")}}/' + fileId,
                                    type: 'get',
                                    dataType: 'json',
                                    headers: {'X-CSRF-TOKEN': csrfToken},
                                    success: function (res) {
                                        fireevent.text(res.texttag);
                                    },
                                    error: function (jqXHR, textStatus, errorThrown) {
                                        handleError(jqXHR, textStatus, errorThrown);
                                    }
                                });


                            });

                        },
                        error: function (jqXHR, textStatus, errorThrown) {
                            handleError(jqXHR, textStatus, errorThrown);
                        }
                    });
                }

            });
            // 'add files' 
            if (fileHandler) {
                dz = new Dropzone('#' + laradropContainer.attr('id') + ' .btn-add-files', {
                    url: fileHandler,
                    autoQueue: false,
                    previewsContainer: "#laradrop-previews-" + uid,
                    previewTemplate: getPreviewContainer(),
                    parallelUploads: 1,
                    acceptedFiles: ".pdf,.doc,.docx,.rtf,.xls,.xlsx,.txt,.jpeg,.png,.gif",
                    init: function () {
                        this.on("error", function (jqXHR, textStatus, errorThrown) {
                            if (jqXHR.accepted == false) {
                                alert(textStatus);
                            } else {
                                handleError({responseText: JSON.stringify(errorThrown)});
                            }

                        });
                        this.on("success", function (status, res) {
                            if (onSuccessCallback) {
                                eval(onSuccessCallback(res));
                            }
                        });
                        this.on("sending", function (file, xhr, data) {
                            random = Math.random().toString(36).replace('.', '');
                            data.append(csrfTokenField, csrfToken);
                            data.append('thumbId', random);
                            data.append('filename', $(file.previewElement).find('#filename').val());
                            data.append('userid', userid);
                            data.append('pid', currentFolderId);
                            data.append('customData', JSON.stringify(customData));
                        });
                        this.on("complete", function (file) {
                            dz.removeFile(file);
                            jQuery.get(fileSrc + '?pid=' + currentFolderId + '&userid=' + userid, function (res) {
                                displayMedia(res);
                            });
                        });
                        this.on("removedfile", function (file) {
                            if (dz.files.length == 0) {
                                laradropPreviewsContainer.hide();
                                $('.start').hide();
                                $("#searchtogler").show();
                            }
                        });
                        this.on("addedfile", function (obj) {
                            laradropPreviewsContainer.show();
                            $("#searchtogler").hide();
                            //alert("jj");console.log("okkk");
                            $('.start').show();
                            $(".start").click(function () {
                                dz.enqueueFiles(dz.getFilesWithStatus(Dropzone.ADDED));
                            });
                        });
                    }
                });
            }

            // get data
            jQuery.ajax({
                url: fileSrc + '?userid=' + userid,
                type: 'GET',
                dataType: 'json',
                success: function (res) {
                    breadCrumbs.push({
                        id: 0,
                        alias: breadCrumbRootText
                    });
                    displayMedia(res);
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    handleError(jqXHR, textStatus, errorThrown);
                }
            });
        },
        error: function (jqXHR, textStatus, errorThrown) {
            handleError(jqXHR, textStatus, errorThrown);
        }
    });

    function displayMedia(res) {
        var out = '',
                record = '',
                re;
        jQuery.each(res.data, function (k, v) {
            record = getThumbnailContainer(Math.random().toString(36).replace('.', ''));
            jQuery.each(v, function (k2, v2) {
                re = new RegExp("\\[\\[" + k2 + "\\]\\]", "g");
                record = record.replace(re, v2);

            });
            re = new RegExp("\\[\\[fileSrc\\]\\]", "g");
            re1 = new RegExp("\\[\\[contextmenu\\]\\]", "g");

            if (v.type === 'folder') {

                out += record.replace(re, folderImage)
                        .replace('laradrop-thumbnail', 'laradrop-thumbnail laradrop-thumbnail-image laradrop-folder')
                        .replace(re1, "");

            } else if (v.type === 'link') {

                out += record.replace(re, 'vendor/jasekz/laradrop/img/genericThumbs/link2-100x100.png')
                        .replace('laradrop-thumbnail', 'laradrop-thumbnail laradrop-thumbnail-image addlinkbtn')
                        .replace(re1, "");

            } else {

                var fileId = v.id;
                var checkpublic = v.security;
                var publicstring = "Make Private";
                if(checkpublic==1) {
                    publicstring = "Make Public";
                }
                qw = '<li><a class="label attachement" rel="tooltip" title="Add to Post" >Add to Post</a></li><li><a class="label move doenloadd" rel="tooltip" title="Download">Download</a></li>  <li><a class="label makepublic" rel="tooltip">' + publicstring + '</a></li>';
                var ff = '{{asset("' + v.filename + '")}}'
                out += record.replace(re, v.filename).replace(/laradrop\-droppable/g, '')
                        .replace(re1, qw);
            }
        });
        laradropContainer.find('.laradrop-body').html(out);


        laradropContainer.find('.attachement').click(function (e) {
            var filename = jQuery(this).closest('.laradrop-thumbnail').find(".laradrop-filealias").text();
            var fileid = jQuery(this).closest('.laradrop-thumbnail').attr("file-id");
            $('#postknowledge .modal-body #attchement').attr('value', filename);
            $('#postknowledge .modal-body #attchement_id').attr('value', fileid);
            $('#postknowledge').modal('toggle');

        });

        laradropContainer.find('.doenloadd').click(function (e) {
            var fileid = jQuery(this).closest('.laradrop-thumbnail').attr("file-id");
            window.location.href = '{{URL::to("laradrop/download/")}}/' + fileid;

        });
        laradropContainer.find('.makepublic').click(function (e) {
            var fireevent = $(this);
            e.preventDefault();
            var fileId = jQuery(this).closest('.laradrop-thumbnail').attr('file-id');
            jQuery.ajax({
                url: '{{URL::to("laradrop/makepublic/")}}/' + fileId,
                type: 'get',
                dataType: 'json',
                headers: {'X-CSRF-TOKEN': csrfToken},
                success: function (res) {
                    fireevent.text(res.texttag);
                    jQuery.get(fileSrc + '?pid=' + currentFolderId + '&userid=' + userid, function (files) {
                        displayMedia(files);
                    });
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    handleError(jqXHR, textStatus, errorThrown);
                }
            });


        });
        tinymce.init({
            selector: "#poster",
            menubar: false,
            plugins: ["advlist lists link image charmap  anchor"],
            toolbar: " styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
            setup: function (editor) {
                editor.on('change', function () {
                    tinymce.triggerSave();
                });
            }
        });
        $(document).on('focusin', function (e) {
            if ($(e.target).closest(".mce-window").length) {
                e.stopImmediatePropagation();
            }
        });

        laradropContainer.find('.laradrop-file-insert').click(function () {

            var $text = jQuery(this).closest('.laradrop-thumbnail').find(".laradrop-filealias"), $textva = $text.text(),
                    $input = $('<input type="text" value=' + $textva + ' />');
            $text.hide().after($input);
            $input.val($text.html()).show().focus().keypress(function (e) {
                var key = e.which;
                if (key == 13) // enter key
                {
                    $input.hide();
                    $text.html($input.val()).show();
                    return false;
                }
            })
                    .focusout(function () {
                        var newname = $input.val();
                        $input.hide();
                        $text.show();
                        var fileId = jQuery(this).closest('.laradrop-thumbnail').attr('file-id');
                        jQuery.ajax({
                            url: '{{Route("laradrop.rename")}}',
                            type: 'POST',
                            data: 'pid=' + fileId + '&pdata=' + encodeURIComponent(newname),
                            dataType: 'json',
                            headers: {'X-CSRF-TOKEN': csrfToken},
                            success: function (res) {
                                jQuery.get(fileSrc + '?pid=' + currentFolderId + '&userid=' + userid, function (files) {
                                    displayMedia(files);
                                });
                            },
                            error: function (jqXHR, textStatus, errorThrown) {
                                handleError(jqXHR, textStatus, errorThrown);
                            }
                        });

                    });


        });

        laradropContainer.find('.laradrop-file-delete').click(function (e) {
            e.preventDefault();
            var fileId = jQuery(this).closest('.laradrop-thumbnail').attr('file-id');

            fileDeleteHandler = fileDeleteHandler.replace(fileDeleteHandler.substr(fileDeleteHandler.lastIndexOf('/')), '/' + fileId);

            if (!confirm(actionConfirmationText)) {
                return false;
            }

            jQuery.ajax({
                url: fileDeleteHandler,
                type: 'DELETE',
                dataType: 'json',
                headers: {'X-CSRF-TOKEN': csrfToken},
                success: function (res) {
                    if (res.custerrors) {
                        $("#deletedialog p").html(res.custerrors)
                        $("#deletedialog").dialog();
                    } else {
                        jQuery.get(fileSrc + '?pid=' + currentFolderId + '&userid=' + userid, function (files) {
                            displayMedia(files);
                        });
                    }

                },
                error: function (jqXHR, textStatus, errorThrown) {
                    handleError(jqXHR, textStatus, errorThrown);
                }
            });
        });

        laradropContainer.find('.laradrop-folder img').click(function () {
            var folder = jQuery(this).closest('.laradrop-folder');
            currentFolderId = folder.attr('file-id');
            breadCrumbs.push({
                id: currentFolderId,
                alias: folder.find('.laradrop-filealias').text()
            });

            jQuery.get(fileSrc + '?pid=' + currentFolderId + '&userid=' + userid, function (res) {
                displayMedia(res);
            });
        });
        laradropContainer.find('.addlinkbtn img').click(function () {


            var folder = jQuery(this).closest('.addlinkbtn');
            var alias = folder.find('.laradrop-filealias').text();
            currentFolderId = folder.attr('file-id');
            window.open('{{URL::to("laradrop/show-link/")}}/' + currentFolderId, alias);
        });

        displayBreadCrumbs();

        laradropContainer.find('.laradrop-draggable').draggable({
            cancel: ".non-draggable",
            revert: "invalid",
            containment: "document",
            helper: "clone",
            cursor: "move",

            cursorAt: {top: 30, left: 15},
            helper: function (event) {
                return $("<div class='panel panel-info' >&nbsp; &#8631; &nbsp;</div>");
            }
        });

        laradropContainer.find('.laradrop-droppable').droppable({
            accept: ".laradrop-draggable",
            hoverClass: "laradrop-droppable-hover",
            activeClass: "laradrop-droppable-highlight",
            drop: function (event, ui) {
                var draggedId = ui.draggable.attr('file-id'),
                        droppedId = jQuery(this).attr('file-id');

                jQuery.ajax({
                    url: fileMoveHandler,
                    type: 'POST',
                    dataType: 'json',
                    headers: {'X-CSRF-TOKEN': csrfToken},
                    data: {'draggedId': draggedId, 'droppedId': droppedId, 'customData': JSON.stringify(customData)},
                    success: function (res) {
                        jQuery.get(fileSrc + '?pid=' + currentFolderId + '&userid=' + userid, function (res) {
                            displayMedia(res);
                        });
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        handleError(jqXHR, textStatus, errorThrown);
                    }
                });
            }
        });

    }

    function displayBreadCrumbs() {
        laradropContainer.find('.laradrop-breadcrumbs').remove();
        var crumbs = '<div class="laradrop-breadcrumbs">',
                length = breadCrumbs.length;

        jQuery.each(breadCrumbs, function (k, v) {
            if (k + 1 == length) {
                crumbs += '<span >' + v.alias + '</span>';
            } else {
                crumbs += '<a href="#" class="laradrop-breadcrumb laradrop-droppable" file-id="' + v.id + '" >' + v.alias + '</a><span class="arrow">&raquo; &nbsp;</span>';
            }
        });
        crumbs += '</div>';
        laradropContainer.find('.laradrop-breadcrumbs-container').prepend(crumbs);

        laradropContainer.find('.laradrop-breadcrumb').click(function (e) {
            e.preventDefault();
            currentFolderId = jQuery(this).attr('file-id');
            var newCrumbs = [];
            jQuery.each(breadCrumbs, function (k, v) {
                newCrumbs.push(v);
                if (v.id == currentFolderId) {
                    return false;
                }
            });
            breadCrumbs = newCrumbs;

            jQuery.get(fileSrc + '?pid=' + currentFolderId + '&userid=' + userid, function (res) {
                displayMedia(res);
            });
        });
    }

    function handleError(jqXHR, textStatus, errorThrown) {

        if (onErrorCallback) {
            eval(onErrorCallback(jqXHR, textStatus, errorThrown));
        } else {
            alert(errorThrown);
        }
    }

    function getLaradropContainer() {
        return views.main;
    }

    function getThumbnailContainer(id) {
        return views.file;
    }

    function getPreviewContainer() {
        return views.preview;
    }

    return laradropObj;
}

</script>
<script>
    jQuery(document).ready(function () {
        jQuery('.laradrop').laradrop();
    });

</script>


<script>
    $(document).ready(function () {



        var ms1 = $('#tagcon').magicSuggest({
            allowFreeEntries: false,
            valueField: 'value',
            displayField: 'label',
            required: true,
            allowDuplicates: false,
            data: '{{Route("groups.getuser")}}',
            ajaxConfig: {
                xhrFields: {
                    withCredentials: true
                }
            }
        });

        $(ms1).on('selectionchange', function (e, m) {
            var asd = this.getValue();
            $("#tagcon1").val(asd);
        });
        $('#group_form').formValidation({
            framework: 'bootstrap',
            icon: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                group_name: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                },
                'group_persons1[]': {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }

            }
        });
        $('#tprofile_Form').formValidation({
            framework: 'bootstrap',
            icon: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                linkname: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }, linktitle: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }
            }
        });

        $('#postform').formValidation({
            framework: 'bootstrap',
            icon: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                subject: {
                    validators: {
                        notEmpty: {
                            message: 'required'
                        }
                    }
                }
            }
        });
    });
</script>


@endsection

