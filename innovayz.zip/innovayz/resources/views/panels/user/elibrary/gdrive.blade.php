@extends('layouts.master')

@section('headscript')
<link rel="stylesheet" href="{{asset("Dashboard/css/elibrary.css")}}">
<link href="{{asset("vendor/jasekz/laradrop/css/styles.css")}}" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Lato:300" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="{{asset("Dashboard/css/gdrive.css")}}">
<link rel="stylesheet" href="{{asset("Dashboard/css/dashboard.css")}}">
<title>Gdrive Library | Innovayz</title>
@endsection
@section('content')

<div class="elibary">
    <div class="container">
        <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
                <div class="bhoechie-tab-menu">
                    <div class="list-group">
                        <a href="{{Route("e-library")}}" class="list-group-item">
                            <i class="fa fa-folder-open"></i>
                            Library Items
                        </a>
                        <a href="{{Route("elib.gview")}}"  class="list-group-item active">
                            <i class="fa fa-google"></i>
                            Google Drive
                        </a>                        
                    </div>
                    @if(isset($files))
                    <a href="{{Route("gAcessDisconnect")}}" class="list-group-item list-group-item-danger">
                        <i class="fa fa-stop-circle-o"></i>
                        Disconnect Drive
                    </a>
                    @endif
                </div>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
                @include("errors.status")
                <div class="bhoechie-tab">
                    <div class="bhoechie-tab-content active">
                        @if(isset($files))
                        <div id="files">

                            @foreach($files as $file)
                            <div class="file col-md-4">
                                <div class="well">
                                    <div class="filesheader">
                                        <span class="file-modified">{{ \App\Logic\DateHelper::format($file->modifiedTime) }}</span>
                                        <div class="dropdown ">
                                            <button class="dropdown-toggle" type="button" data-toggle="dropdown">
                                                <span class="caret"></span></button>
                                            <ul class="dropdown-menu">
                                                <li><a href="{{ $file->webViewLink }}" target="_blank">View</a></li>
                                                @if(!empty($file->webContentLink))
                                                <li><a href="{{ $file->webContentLink }}" target="_blank">Download</a></li>
                                                @endif
                                            </ul>
                                        </div>
                                    </div>

                                    <img src="{{ $file->iconLink }}" alt="{{ $file->name }}" class="img-responsive">
                                    <div class="file-title">
                                        <h4>{{ $file->name }}</h4>


                                    </div>
                                </div>

                            </div>
                            @endforeach
                        </div>
                        @else
                        <img src="{{asset("img/Gdrive.jpg")}}" alt="GDrive" class="img-responsive">
                        <div class="grivetext">
                            <div class="col-md-6 col-md-offset-3">
                                <div class="grivetext">
                                    <a href="{{Route("elib.gaccess")}}" class="btn btn-lg btn-info">Connect with Google Drive</a>
                                </div>
                            </div>
                        </div>
                        @endif
                        <div class="clearfix"></div>
                    </div>

                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
            </div>


        </div>
    </div>
</div>



@endsection
