@extends('layouts.master')
@section('headscript')
<title>Step 1 | College Profile Update Wizard</title>
<link rel="stylesheet" href="{{asset("css/profile_steps.css")}}">
@endsection
@section('content')
<div class="container">
    <div class="row">
        <section>
            <div class="wizard">
                <div class="wizard-inner">
                    <div class="connecting-line"></div>
                    <ul class="nav nav-tabs" role="tablist">

                        <li role="presentation" class="active">
                            <a href="#step1" data-toggle="tab" aria-controls="step1" role="tab" title="Step 1">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-user"></i>
                                </span>
                            </a>
                            <p>College Details</p>
                        </li>

                        <li role="presentation" class="disabled">
                            <a href="#step2" data-toggle="tab" aria-controls="step2" role="tab" title="Step 2">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-education"></i>
                                </span>
                            </a>
                            <p>Course Details</p>
                        </li>
                        <li role="presentation" class="disabled">
                            <a href="#step3" data-toggle="tab" aria-controls="step3" role="tab" title="Step 3">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-envelope"></i>
                                </span>
                            </a>
                            <p>Contact Details</p>
                        </li>


                    </ul>
                </div>
                <div class="wizard_form_wraper">
                    @if (session('issues'))
                    <div class="alert alert-danger">
                        {{ session('issues') }}
                    </div>
                    @endif
                    <form id="tprofile_Form" method="post" role='form' class="form-horizontal" action="{{Route('college.updatesave1')}}">
                        {{ csrf_field() }}
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Type<span>*</span></label>
                                    <div class="col-sm-12">
                                        <select name="col_type" id="col_type" class="form-control">
                                            <option value="null">Select Type</option>
                                            <option value="school">School</option>
                                            <option value="collge">College</option>
                                            <option value="institute">Institute</option>
                                            <option value="others">Others</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Establishment Year<span>*</span></label>                                
                                    <div class="col-sm-12">
                                        <input type="number" class="form-control" placeholder="Establishment Year" id="estab_yr" name="estab_yr" value="{{ $dta->establishment}}"/>
                                    </div>
                                </div>
                                @if($dta->affilatedby)
                                <div class="form-group" id="affiltogle" >
                                    <label class="control-label col-sm-12" for="area_interest">Affiliated By<span>*</span></label>                                
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="affilatedby" name="affilatedby" placeholder="Affiliated By"  value="{{$dta->affilatedby}}"/>                                        
                                    </div>
                                </div>
                                @else
                                <div class="form-group" id="affiltogle" style="display: none">
                                    <label class="control-label col-sm-12" for="area_interest">Affiliated By<span>*</span></label>                                
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="affilatedby" name="affilatedby" placeholder="Affiliated By"/>                                        
                                    </div>
                                </div>
                                @endif
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">

                                <div class="form-group">
                                    <label class="control-label col-sm-12">Description<span>*</span></label>
                                    <div class="col-sm-12">
                                        <textarea class="form-control"  rows="10" id="description" name="description" placeholder="Description" >{{ $dta->breif}}</textarea>                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row formfooter">
                            <div class="col-md-8">

                            </div>
                            <div class="col-md-4">                                
                                <button type="submit" class=" btn btn-primary profile-btn pull-right btn-lg" id="next-step">Next</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>

@endsection

@section('jsfiles')

<script>
$(function () {
    $("#col_type option[value='{{$dta->select_category}}']").prop('selected', true);
    $("#col_type").change(function () {
        $("#affiltogle").hide();
        var curtnt = $(this).val();
        if (curtnt == 'collge' || curtnt == 'school') {
            $("#affiltogle").show();
        } else {
            $("#affilatedby").val("");
        }
    });
    $('#tprofile_Form').formValidation({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            col_type: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            },
            estab_yr: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    },
                    regexp: {
                        message: 'number can only contain the digits, spaces, -, (, ), + and .',
                        regexp: /^[0-9\s\-()+\.]+$/
                    }
                }
            },
            affilatedby: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            },
            description: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }
        }
    });





});
</script>
@endsection
