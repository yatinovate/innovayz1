@extends('layouts.master')
@section('headscript')
<title>Step 2 | College Profile Update Wizard</title>
<link rel="stylesheet" href="{{asset("css/profile_steps.css")}}">
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<style>
    .voca{
        margin-bottom: 30px;
    }
</style>

@endsection
@section('content')
<div class="container">
    <div class="row">
        <section>
            <div class="wizard">
                <div class="wizard-inner">
                    <div class="connecting-line"></div>
                    <ul class="nav nav-tabs" role="tablist">

                        <li role="presentation" class="visited disabled">
                            <a data-toggle="tab" aria-controls="step1" role="tab" title="Step 1">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-user"></i>
                                </span>
                            </a>
                            <p>College Details</p>
                        </li>

                        <li role="presentation" class="active">
                            <a data-toggle="tab" aria-controls="step2" role="tab" title="Step 2">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-education"></i>
                                </span>
                            </a>
                            <p>Course Details</p>
                        </li>
                        <li role="presentation" class="disabled">
                            <a data-toggle="tab" aria-controls="step3" role="tab" title="Step 3">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-envelope"></i>
                                </span>
                            </a>
                            <p>Contact Details</p>
                        </li>


                    </ul>
                </div>
                <div class="wizard_form_wraper">
                    @if (session('issues'))
                    <div class="alert alert-danger">
                        {{ session('issues') }}
                    </div>
                    @endif


                    <form id="tprofile_Form" method="post" role='form' class="form-horizontal" action="{{Route('college.updatesave2')}}">
                        {{ csrf_field() }}
                        @if(count($course_list))
                        @foreach($course_list as $exist_course)
                        <input type="hidden" name="course_id[]" value="{{$exist_course->id }}" />
                        <div class="row">

                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Course Name<span>*</span></label>
                                    <div class="col-sm-12">
                                        <select name="col_name[]" id="col_name" class="form-control" disabled="">
                                            <option value="">Select Course</option>
                                            @foreach($course as $as)
                                            <option value="{{$as->id}}" <?php if ($exist_course->course_name == $as->id) echo 'selected'; ?>>{{$as->qulaification}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-sm-12">Duration<span>*</span></label>
                                    <div class="col-sm-6">
                                        <select name="col_yr[]" id="col_yr" class="form-control">
                                            <option value="">Select Year</option>
                                            <option value="0" <?php if ($exist_course->duration_year == '0') echo 'selected'; ?>>0 year</option>
                                            <option value="1" <?php if ($exist_course->duration_year == '1') echo 'selected'; ?>>1 year</option>
                                            <option value="2" <?php if ($exist_course->duration_year == '2') echo 'selected'; ?>>2 year</option>
                                            <option value="3" <?php if ($exist_course->duration_year == '3') echo 'selected'; ?>>3 year</option>
                                            <option value="4" <?php if ($exist_course->duration_year == '4') echo 'selected'; ?>>4 year</option>
                                            <option value="5" <?php if ($exist_course->duration_year == '5') echo 'selected'; ?>>5 year</option>
                                            <option value="6" <?php if ($exist_course->duration_year == '6') echo 'selected'; ?>>6 year</option>
                                            <option value="7" <?php if ($exist_course->duration_year == '7') echo 'selected'; ?>>7 year</option>
                                            <option value="8" <?php if ($exist_course->duration_year == '8') echo 'selected'; ?>>8 year</option>
                                            <option value="9" <?php if ($exist_course->duration_year == '9') echo 'selected'; ?>>9 year</option>
                                            <option value="10" <?php if ($exist_course->duration_year == '10') echo 'selected'; ?>>10 year</option>
                                        </select>
                                    </div>
                                    <div class="col-sm-6">
                                        <select name="col_month[]" id="col_month" class="form-control">
                                            <option value="">Select Month</option>
                                            <option value="0"  <?php if ($exist_course->duration_month == '0') echo 'selected'; ?> >0 Month</option>
                                            <option value="1"  <?php if ($exist_course->duration_month == '1') echo 'selected'; ?> >1 Month</option>
                                            <option value="2" <?php if ($exist_course->duration_month == '2') echo 'selected'; ?>>2 Month</option>
                                            <option value="3" <?php if ($exist_course->duration_month == '3') echo 'selected'; ?>>3 Month</option>
                                            <option value="4" <?php if ($exist_course->duration_month == '4') echo 'selected'; ?>>4 Month</option>
                                            <option value="5" <?php if ($exist_course->duration_month == '5') echo 'selected'; ?>>5 Month</option>
                                            <option value="6" <?php if ($exist_course->duration_month == '6') echo 'selected'; ?>>6 Month</option>
                                            <option value="7" <?php if ($exist_course->duration_month == '7') echo 'selected'; ?>>7 Month</option>
                                            <option value="8" <?php if ($exist_course->duration_month == '8') echo 'selected'; ?>>8 Month</option>
                                            <option value="9" <?php if ($exist_course->duration_month == '9') echo 'selected'; ?>>9 Month</option>
                                            <option value="10" <?php if ($exist_course->duration_month == '10') echo 'selected'; ?>>10 Month</option>
                                            <option value="11" <?php if ($exist_course->duration_month == '11') echo 'selected'; ?>>11 Month</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Course Description</label>
                                    <div class="col-sm-12">
                                        <textarea class="form-control"  rows="5" id="course_desc" name="course_desc[]" placeholder="Course Description" >{{$exist_course->course_desc}}</textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Stream<span>*</span></label>
                                    <div class="col-sm-12 ui-widget">
                                        <?php 
                                        $qulaificsyream="";
                                        if($exist_course->stream!=""){
                                            $query = App\Models\User\QualificationList::find($exist_course->stream);
                                            $qulaificsyream=$query->qulaification;
                                        }
                                         ?>
                                        <input type="text" class="form-control" name="col_stream[]" id="col_stream" value="{{$qulaificsyream}}" disabled=""/>

                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Course Fee<span>*</span></label>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control" id="col_feee" name="col_feee[]" placeholder="Course Fee" value="{{$exist_course->fee}}"/>
                                    </div>
                                    <div class="col-sm-6">
                                        <select name="fee_type[]" id="fee_type" class="form-control">
                                            <option value="">Select Fee</option>
                                            <option value="Total Fee" <?php if ($exist_course->fee_type == 'Total Fee') echo 'selected'; ?> >Total Fee</option>
                                            <option value="Monthly Fee" <?php if ($exist_course->fee_type == 'Monthly Fee') echo 'selected'; ?>>Monthly Fee</option>
                                            <option value="Quarterly Fee" <?php if ($exist_course->fee_type == 'Quarterly Fee') echo 'selected'; ?>>Quarterly Fee</option>
                                            <option value="Half Yearly Fee" <?php if ($exist_course->fee_type == 'Half Yearly Fee') echo 'selected'; ?>>Half Yearly Fee</option>
                                            <option value="Yearly Fee" <?php if ($exist_course->fee_type == 'Yearly Fee') echo 'selected'; ?>>Yearly Fee</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Eligibility Criteria</label>
                                    <div class="col-sm-12">
                                        <textarea class="form-control"  rows="5" id="course_eligibility" name="course_eligibility[]" placeholder="Eligibility Criteria">{{$exist_course->eligi_criteria}}</textarea>
                                    </div>
                                </div>

                            </div>

                            <div class="col-md-12" id="asdf">
                                <br>
                            </div>

                            <div class="col-md-12">
                                <hr>
                            </div>
                        </div>
                        @endforeach
                        @endif

                        <div class="row formfooter">
                            <div class="col-md-8">
                                <div class="row">
                                    <div class="col-md-5">
                                        <h2 class="profile_title"><a href="{{Route("college.update2addcourse")}}">Add New Course</a></h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">                                
                                <button type="submit" class=" btn btn-primary profile-btn pull-right btn-lg" id="next-step">Next</button>
                            </div>
                        </div>


                    </form>
                </div>

            </div>
        </section>
    </div>
</div>

@endsection

@section('jsfiles')
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<script>
$(function () {


    $('#tprofile_Form').formValidation({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            'col_name[]': {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            },
            'col_yr[]': {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            },
            'col_month[]': {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }
            , 'col_stream[]': {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }, 'col_feee[]': {
                validators: {
                    notEmpty: {
                        message: 'required'
                    },
                    numeric: {
                        message: 'The value is not a number',
                        // The default separators
                        thousandsSeparator: '',
                        decimalSeparator: '.'
                    }
                }
            }, 'fee_type[]': {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }

        }
    });
});
</script>

@endsection
