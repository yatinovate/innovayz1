@extends('layouts.master')
@section('headscript')
<title>{{Auth::user()->name}} | Update Profile</title>
<link rel="stylesheet" href="{{asset("css/profile_steps.css")}}">
<link rel="stylesheet" href="{{asset("css/pikaday.css")}}">
<link href="{{asset("css/magicsuggest-min.css")}}" rel="stylesheet">
<style>

.wizard .nav-tabs > li {
    width: 25%;
}
</style>
@endsection
@section('content')
<div class="container">
    <div class="row">
        <section>
            <div class="wizard">
                <div class="wizard-inner">
                    <div class="connecting-line"></div>
                    <ul class="nav nav-tabs" role="tablist">

                        <li role="presentation" class="active">
                            <a data-toggle="tab" aria-controls="step1" role="tab" title="Step 1">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-user"></i>
                                </span>
                            </a>
                            <p>Personal Information</p>
                        </li>

                        <li role="presentation" class="disabled">
                            <a data-toggle="tab" aria-controls="step2" role="tab" title="Step 2">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-education"></i>
                                </span>
                            </a>
                            <p>Qualification Details</p>
                        </li>
                        <li role="presentation" class="disabled">
                            <a data-toggle="tab" aria-controls="step3" role="tab" title="Step 3">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-envelope"></i>
                                </span>
                            </a>
                            <p>Teaching Details</p>
                        </li>
                        <li role="presentation" class="disabled">
                            <a data-toggle="tab" aria-controls="step4" role="tab" title="Step 4">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-envelope"></i>
                                </span>
                            </a>
                            <p>Contact Details</p>
                        </li>


                    </ul>
                </div>
                <div class="wizard_form_wraper">
                    @if (session('issues'))
                    <div class="alert alert-danger">
                        {{ session('issues') }}
                    </div>
                    @endif
                    <form id="tprofile_Form" method="post" role='form' class="form-horizontal" action="{{Route('teacher.updatesave1')}}">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Gender<span>*</span></label>
                                    <div class="col-sm-12">
                                        <div class="form-inline">
                                            <div class="col-md-3">
                                                <input type="radio" name="gender" id="male" value="Male" <?php if ($dta->gender == 'Male') echo 'checked'; ?>>
                                                <label for="male" class="">&nbsp;&nbsp;Male</label>
                                            </div>
                                            <div class="col-md-3">
                                                <input type="radio" name="gender" id="female" value="Female"  <?php if ($dta->gender == 'Female') echo 'checked'; ?>>
                                                <label for="female" class="">&nbsp;&nbsp;Female</label>
                                            </div>
                                            <div class="col-md-6"></div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-sm-12" for="datepicker">Date of Birth<span>*</span></label>                                
                                    <div class="col-sm-12">
                                        <div class="input-group">
                                            <input type="text" class="form-control"  id="profile_dob" name="profile_dob"  autocomplete="off" value="{{ $dta->dob}}" readonly="">
                                            <span class="input-group-addon" id="date_trig"><i class="fa fa-calendar"></i></span>
                                        </div>
                                    </div>

                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-12" for="area_interest">Area of Interest<span>*</span></label>         
                                    <div class="col-sm-12">
                                        <div class="tag_container">
                                            @foreach($area as $ar)
                                            <a data-id="{{$ar->id}}">{{$ar->area_int->area_intrest}}&nbsp;<i class="fa fa-close"></i></a>
                                            @endforeach
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="area_interest" name="area_interest" placeholder="Area of Interest" required=""/>
                                        <input type="hidden" id="area_interest1" name="area_interest1" >
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">

                                <div class="form-group">
                                    <label class="control-label col-sm-12" for="desc_yourself">Describe Yourself<span>*</span></label>
                                    <div class="col-sm-12">
                                        <textarea class="form-control"  rows="10" name="desc_yourself" placeholder="Describe Yourself">{{ $dta->describe_yourself}}</textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row formfooter">
                            <div class="col-md-8">

                            </div>
                            <div class="col-md-4">
                                <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
                                <button type="submit" class=" btn btn-primary profile-btn pull-right btn-lg" id="next-step">Next</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>

@endsection

@section('jsfiles')
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.1/moment.min.js"></script>
<script src="{{asset("js/pikaday.js")}}"></script>
<script src="{{asset("js/magicsuggest-min.js")}}"></script>
<script>
$(function () {

    if ( $('html').hasClass('no-touch') ) {
    var pickerStart1 = new Pikaday({
      field: $("#profile_dob")[0],
      trigger: $("#date_trig")[0],
      format: 'DD/MM/YYYY',
      firstDay: 1,
      maxDate: new Date(),
       yearRange: [moment().year()-50, moment().year()],
       onSelect: function () {
                var asd = this.getMoment().format('DD/MM/YYYY');
            $('#tprofile_Form')
                .find('[name="profile_dob"]')
                    .val(asd)
                    .end()
                .formValidation('revalidateField', 'profile_dob');
            }
    });
  
} else {
  $("#profile_dob").attr('type', 'date');
}
    var ms = $('#area_interest').magicSuggest({
        required: true,
        data: '{{Route("profile.updateareaintrest")}}',
        ajaxConfig: {
            xhrFields: {
                withCredentials: true
            }
        }
    });
$(ms).on('selectionchange', function(e,m){
     var asd = this.getValue();
            $('#tprofile_Form')
                .find('[name="area_interest1"]')
                    .val(asd);
});
$(document).delegate('.tag_container a', 'click', function(){
     var id = $(this).data("id");
       $.get('{{Route("profile.deltearea")}}', {id: id})
                .done(function (data) {
                    $(".tag_container").html(data);
                });
});

    

    $('#tprofile_Form').formValidation({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            desc_yourself: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    },stringLength: {
                        max: 250,
                        message: 'It must be less than 250 characters'
                    }
                }
            }, profile_dob: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }, gender: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }
        }
    });

});
</script>
@endsection

