@extends('layouts.master')
@section('headscript')
<title>Step 2 | Teacher Profile Update</title>
<link rel="stylesheet" href="{{asset("css/profile_steps.css")}}">
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<style>
    .wizard .nav-tabs > li {
    width: 25%;
}
</style>
@endsection
@section('content')
<div class="container">
    <div class="row">
        <section>
            <div class="wizard">
                <div class="wizard-inner">
                    <div class="connecting-line"></div>
                    <ul class="nav nav-tabs" role="tablist">

                        <li role="presentation" class="disabled visited">
                            <a data-toggle="tab" aria-controls="step1" role="tab" title="Step 1">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-user"></i>
                                </span>
                            </a>
                            <p>Personal Information</p>
                        </li>

                        <li role="presentation" class="active">
                            <a data-toggle="tab" aria-controls="step2" role="tab" title="Step 2">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-education"></i>
                                </span>
                            </a>
                            <p>Qualification Details</p>
                        </li>
                        <li role="presentation" class="disabled">
                            <a data-toggle="tab" aria-controls="step3" role="tab" title="Step 3">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-envelope"></i>
                                </span>
                            </a>
                            <p>Teaching Details</p>
                        </li>
                        <li role="presentation" class="disabled">
                            <a data-toggle="tab" aria-controls="step4" role="tab" title="Step 4">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-envelope"></i>
                                </span>
                            </a>
                            <p>Contact Details</p>
                        </li>


                    </ul>
                </div>
                <div class="wizard_form_wraper">
                    @if (session('issues'))
                    <div class="alert alert-danger">
                        {{ session('issues') }}
                    </div>
                    @endif
                    <form id="tprofile_Form" method="post" role='form' class="form-horizontal" action="{{Route("teacher.savenewqual")}}">
                        {{csrf_field()}}
                        <div class="row">
                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 ">
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Study Place<span>*</span></label>
                                    <div class="col-sm-12">
                                        <select class="form-control" name="study_place[]">
                                            <option value="">Study Place</option>
                                            <option value="Institute">Institute</option>
                                            <option value="University">University</option>
                                            <option value="College">College</option>
                                            <option value="School">School</option>
                                        </select>
                                    </div>
                                </div>
                            </div>  
                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 ">
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Qualification<span>*</span></label>
                                    <div class="col-sm-12">
                                        <select class="form-control" name="qualification[]" id="qualification1">
                                            <?php
                                            $albums = array();
                                            foreach ($qlist as $list) {
                                                array_push($albums, $list);
                                            }
                                            $album_type = '';
                                            foreach ($albums as $album) {
                                                if ($album_type != $album->qual_group) {
                                                    if ($album_type != '') {
                                                        echo '</optgroup>';
                                                    }
                                                    echo '<optgroup label="' . $album->qual_group . '">';
                                                }
                                                echo '<option value="' . $album->id . '">' . htmlspecialchars($album->qulaification) . '</option>';
                                                $album_type = $album->qual_group;
                                            }
                                            if ($album_type != '') {
                                                echo '</optgroup>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 ">
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Specialization<span>*</span></label>
                                    <div class="col-sm-12">
                                        <select class="form-control" name="stream[]" id="stream1">
                                            <option value="">Select Specialization</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 ">
                                <div class="form-group" >
                                    <label class="control-label col-sm-12">Institute Name<span>*</span></label>
                                    <div class="col-sm-12 ui-widget">
                                        <input type="text" class="form-control institute" autocomplete="off"  name="institute[]" placeholder="Institute Name"/>
                                        <input type="hidden" name="institute1[]" id="institute1" />
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12 text-right">
                                <a class="qaulddr pull-right" datacount=""><i class="fa fa-plus-circle" ></i> Add More Qualification Details</a>
                            </div>
                            <div class="col-md-12" id="asdf">
                                <br>
                            </div>

                        </div>
                        <div class="row formfooter">
                            <div class="col-md-8">
                                
                            </div>
                            <div class="col-md-4">
                                <button type="submit" class=" btn btn-primary profile-btn pull-right btn-lg" id="next-step">Next</button>
                            </div>
                        </div>


                    </form>
                    <div class="voca hide" id="newrow">
                        <div class="col-md-12">
                            <hr>
                        </div>


                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 ">
                            <div class="form-group">
                                <label class="control-label col-sm-12">Study Place<span>*</span></label>
                                <div class="col-sm-12">
                                    <select class="form-control" name="study_place[]">
                                        <option value="">Study Place</option>
                                        <option value="Institute">Institute</option>
                                        <option value="University">University</option>
                                        <option value="College">College</option>
                                        <option value="School">School</option>
                                    </select>
                                </div>
                            </div>
                        </div>  
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 ">
                            <div class="form-group">
                                <label class="control-label col-sm-12">Qualification<span>*</span></label>
                                <div class="col-sm-12">
                                    <select class="form-control" name="qualification[]">
                                        <option value="">Select qualification</option>
                                        @foreach($qlist as $as)
                                        <option value="{{$as->id}}">{{$as->qulaification}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 ">
                            <div class="form-group">
                                <label class="control-label col-sm-12">Specialization<span>*</span></label>
                                <div class="col-sm-12">
                                    <select class="form-control" name="stream[]" id="stream1">
                                        <option value="">Select Specialization</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 ">
                            <div class="form-group" >
                                <label class="control-label col-sm-12">Institute Name<span>*</span></label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control institute" autocomplete="off"  name="institute[]" placeholder="Institute Name"/>
                                    <input type="hidden" name="institute1[]" id="institute1" />
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 text-right" >
                            <a class="delqual pull-right" datacount=""><i class="fa fa-trash" ></i> Delete Qualification Details</a>
                        </div>
                    </div>
                </div>

            </div>
        </section>
    </div>
</div>

@endsection

@section('jsfiles')
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>

<script>
$(function () {
    
    $(".institute").autocomplete({
        source: '{{Route("profile.getinstitute")}}',
        select: function (event, ui) {
            $('#institute1').val(ui.item.id);
        }
    });

   $('#qualification1').change(function (e) {
        var selectvalue = $(this).val();
        $('#stream1').html('<option value="">Loading...</option>');
        $.get('{{Route("profile.getuserstream")}}',{ qualificationid: selectvalue},function (output) {
                $('#stream1').html(output);
            });
    });

    $('#tprofile_Form').formValidation({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            'study_place[]': {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            },
            'qualification[]': {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            },
            'stream[]': {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            },
            'institute[]': {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }
        }
    }).on('click', '.qaulddr', function () {
        var $template = $('#newrow'),
                $clone = $template
                .clone()
                .removeClass('hide')
                .removeAttr('id')
                .insertBefore("#asdf"),
                $option = $clone.find('[name="study_place[]"]'),
                $option1 = $clone.find('[name="qualification[]"]'),
                $option2 = $clone.find('[name="stream[]"]'),
                $option3 = $clone.find('[name="institute[]"]'),
                $option4 = $clone.find('[name="institute1[]"]');

        // Add new field
        $('#tprofile_Form').formValidation('addField', $option);
        $('#tprofile_Form').formValidation('addField', $option1);
        $('#tprofile_Form').formValidation('addField', $option2);
        $('#tprofile_Form').formValidation('addField', $option3);
        $($option1).change(function (e) {
            var selectvalue = $(this).val();
            $clone.find('[name="stream[]"]').html('<option value="">Loading...</option>');
             $.get('{{Route("profile.getuserstream")}}',{ qualificationid: selectvalue},function (output) {
                $clone.find('[name="stream[]"]').html(output);
            });
        });

         $option3.autocomplete({
        source: '{{Route("profile.getinstitute")}}',
        select: function (event, ui) {
            $($option4).val(ui.item.id);
        }
    });
    }).on('click', '.delqual', function () {
        var $row = $(this).parent().parents('.voca'),
                $option = $row.find('[name="study_place[]"]'),
                $option1 = $row.find('[name="qualification[]"]'),
                $option2 = $row.find('[name="stream[]"]'),
                $option3 = $row.find('[name="institute[]"]');
        // Remove element containing the option
        $row.remove();
        // Remove field
        $('#tprofile_Form').formValidation('removeField', $option);
        $('#tprofile_Form').formValidation('removeField', $option1);
        $('#tprofile_Form').formValidation('removeField', $option2);
        $('#tprofile_Form').formValidation('removeField', $option3);
    });
});
</script>


@endsection
