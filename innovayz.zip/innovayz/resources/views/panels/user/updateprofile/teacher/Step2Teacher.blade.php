@extends('layouts.master')
@section('headscript')
<title>Step 2 | Teacher Profile Update</title>
<link rel="stylesheet" href="{{asset("css/profile_steps.css")}}">
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<style>
.profile_title
{
    color: #222;
    text-align: left;
    font-family: open sans;
    font-size: 20px;
    text-transform: capitalize;
    display: inline-block;
    font-weight: 600;
    margin: 5px;
    text-decoration: none;
}
.profile_title a
{
    text-decoration: none;
    color: #222;
}
.profile_title a:hover
{
    text-decoration: none;
    color: #222;
}
.wizard .nav-tabs > li {
    width: 25%;
}
</style>


@endsection
@section('content')
<div class="container">
    <div class="row">
        <section>
            <div class="wizard">
                <div class="wizard-inner">
                    <div class="connecting-line"></div>
                    <ul class="nav nav-tabs" role="tablist">

                        <li role="presentation" class="disabled visited">
                            <a data-toggle="tab" aria-controls="step1" role="tab" title="Step 1">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-user"></i>
                                </span>
                            </a>
                            <p>Personal Information</p>
                        </li>

                        <li role="presentation" class="active">
                            <a data-toggle="tab" aria-controls="step2" role="tab" title="Step 2">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-education"></i>
                                </span>
                            </a>
                            <p>Qualification Details</p>
                        </li>
                        <li role="presentation" class="disabled">
                            <a data-toggle="tab" aria-controls="step3" role="tab" title="Step 3">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-envelope"></i>
                                </span>
                            </a>
                            <p>Teaching Details</p>
                        </li>
                        <li role="presentation" class="disabled">
                            <a data-toggle="tab" aria-controls="step4" role="tab" title="Step 4">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-envelope"></i>
                                </span>
                            </a>
                            <p>Contact Details</p>
                        </li>


                    </ul>
                </div>
                <div class="wizard_form_wraper">
                    @if (session('issues'))
                    <div class="alert alert-danger">
                        {{ session('issues') }}
                    </div>
                    @endif
                    <form id="tprofile_Form" method="post" role='form' class="form-horizontal"  action="{{Route('teacher.updatesave2')}}">
                        {{csrf_field()}}
                       @if(count($qual))
                        @foreach($qual as $exist_course)
                        <input type="hidden" name="course_id[]" value="{{$exist_course->id }}" />
                        <div class="row">

                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Study Place<span>*</span></label>
                                    <div class="col-sm-12">
                                        <select class="form-control" name="study_place[]" id="study_place1">
                                            <option value="">Study Place</option>
                                            <option value="Institute" <?php if ($exist_course->study_place == 'Institute') echo 'selected'; ?>>Institute</option>
                                            <option value="University" <?php if ($exist_course->study_place == 'University') echo 'selected'; ?>>University</option>
                                            <option value="College" <?php if ($exist_course->study_place == 'College') echo 'selected'; ?>>College</option>
                                            <option value="School" <?php if ($exist_course->study_place == 'School') echo 'selected'; ?>>School</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Qualification<span>*</span></label>
                                    <div class="col-sm-12">
                                        <select class="form-control" name="qualification[]" id="qualification1">
                                            <?php
                                            $albums = array();
                                            foreach ($qlist as $list) {
                                                array_push($albums, $list);
                                            }
                                            $album_type = '';
                                            foreach ($albums as $album) {
                                                if ($album_type != $album->qual_group) {
                                                    if ($album_type != '') {
                                                        echo '</optgroup>';
                                                    }
                                                    echo '<optgroup label="' . $album->qual_group . '">';
                                                }
                                                $asd='';
                                                if ($exist_course->qualification == $album->id) $asd= 'selected'; 
                                                echo '<option value="' . $album->id . '"  '.$asd.'>' . htmlspecialchars($album->qulaification) . '</option>';
                                                $album_type = $album->qual_group;
                                            }
                                            if ($album_type != '') {
                                                echo '</optgroup>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Specialization<span>*</span></label>
                                    <div class="col-sm-12">
                                        <select class="form-control" name="stream[]">
                                            <option value="">Select Stream</option>{{$exist_course->specalization->qulaification}}
                                            @foreach (\App\Models\User\QualificationList::where('category',$exist_course->qualification)->get() as $list)
                                            <option value="{{$list->id}}" <?php if ($exist_course->stream == $list->id) echo 'selected'; ?>>{{$list->qulaification}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                <div class="form-group" >
                                    <label class="control-label col-sm-12">Institute Name<span>*</span></label>
                                    <div class="col-sm-12">
                                        <div class="col-sm-12 ui-widget">
                                             <?php
                                             $insvalue='';
                                       $institute = App\Models\User\UserInstitute::find($exist_course->institute);
                                       if($institute){
                                           $insvalue=$institute->institute;
                                       }
                                        ?>
                                            <input type="text" class="form-control institute" autocomplete="off"  name="institute[]" placeholder="Institute Name" value="{{$insvalue}}">
                                            <input type="hidden" name="institute1[]" id="institute1" value="{{$exist_course->institute}}" />
                                        </div>
                                    </div>
                                </div>
                            </div>



                            <div class="col-md-12" id="asdf">
                                <br>
                            </div>

                            <div class="col-md-12">
                                <hr>
                            </div>
                        </div>
                        @endforeach
                        @endif
                        <div class="row">
                            <h2 class="profile_title pull-right "><a href="{{Route("teacher.addqulai")}}">Add New Qualifiaction</a></h2>
                        </div>
                        <div class="row formfooter">
                            <div class="col-md-8">

                            </div>
                            <div class="col-md-4">
                                <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
                                <button type="submit" class=" btn btn-primary profile-btn pull-right btn-lg" id="next-step">Next</button>
                            </div>
                        </div>
                    </form>
                </div>

            </div>
        </section>
    </div>
</div>

@endsection
@section('jsfiles')
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>

<script>
    $(function () {
        
        $('#tprofile_Form').formValidation({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            'study_place[]': {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            },
            'qualification[]': {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            },
            'stream[]': {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }
            , 'institute[]': {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }

        }
    });
      $(".institute").autocomplete({
        source: '{{Route("profile.getinstitute")}}',
        select: function (event, ui) {
            var cur=$(this);
            cur.parent().find('[name="institute1[]"]').val(ui.item.id);
        }
    });
    
   $('#tprofile_Form [name="qualification[]"]').change(function (e) {
       var qual=$(this);
        var selectvalue = $(this).val();
        $('#stream1').html('<option value="">Loading...</option>');
        $.get('{{Route("profile.getuserstream")}}',{ qualificationid: selectvalue},function (output) {
            qual.parent().parent().parent().parent().find('[name="stream[]"]').html(output);
                //$('#stream1').html(output);
            });
    });
    


    });
</script>
@endsection

