@extends('layouts.master')
@section('headscript')
<title>Step 3 | Update Teacher Profile</title>
<link rel="stylesheet" href="{{asset("css/profile_steps.css")}}">
<style>

    .wizard .nav-tabs > li {
        width: 25%;
    }

</style>
@endsection
@section('content')
<div class="container">
    <div class="row">
        <section>
            <div class="wizard">
                <div class="wizard-inner">
                    <div class="connecting-line"></div>
                    <ul class="nav nav-tabs" role="tablist">

                        <li role="presentation" class="visited disabled">
                            <a data-toggle="tab" aria-controls="step1" role="tab" title="Step 1">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-user"></i>
                                </span>
                            </a>
                            <p>Personal Information</p>
                        </li>

                        <li role="presentation" class="visited disabled">
                            <a data-toggle="tab" aria-controls="step2" role="tab" title="Step 2">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-education"></i>
                                </span>
                            </a>
                            <p>Qualification Details</p>
                        </li>
                        <li role="presentation" class="active">
                            <a data-toggle="tab" aria-controls="step3" role="tab" title="Step 3">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-envelope"></i>
                                </span>
                            </a>
                            <p>Teaching Details</p>
                        </li>
                        <li role="presentation" class="disabled">
                            <a data-toggle="tab" aria-controls="step4" role="tab" title="Step 4">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-envelope"></i>
                                </span>
                            </a>
                            <p>Contact Details</p>
                        </li>


                    </ul>
                </div>
                <div class="wizard_form_wraper">
                    @if (session('issues'))
                    <div class="alert alert-danger">
                        {{ session('issues') }}
                    </div>
                    @endif
                    <form id="tprofile_Form" method="post" role='form' class="form-horizontal" action="{{Route('teacher.saveupdate3')}}">
                        {{csrf_field()}}
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-12 ">Experience<span>*</span></label> 
                                    <div class="col-md-12">
                                        <select class="form-control" name="select_experience">
                                            <option value="">Select Experience</option>
                                            <option value="2" <?php if ($dta->experience == '2') echo 'selected'; ?>>2</option>
                                            <option value="3" <?php if ($dta->experience == '3') echo 'selected'; ?>>3</option>
                                            <option value="4" <?php if ($dta->experience == '4') echo 'selected'; ?>>4</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Current Organization<span>*</span></label> 
                                    <div class="col-md-12">
                                        <input type="text" class="form-control" name="currentorg" placeholder="Current Organization" value="{{$dta->current_Organization}}" />
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Previous Organization<span>*</span></label> 
                                    <div class="col-md-12">
                                        <input type="text" class="form-control" name="preorg" placeholder="Previous Organization" value="{{$dta->Previous_Organization}}" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Grades<span>*</span></label> 
                                    <div class="col-sm-12">
                                        <select class="form-control" name="select_grades">
                                                <option value="">select your grades</option>
                                                <option value="2" <?php if ($dta->experience == '2') echo 'selected'; ?>>2</option>
                                                <option value="3" <?php if ($dta->experience == '3') echo 'selected'; ?>>3</option>
                                            <option value="4" <?php if ($dta->experience == '4') echo 'selected'; ?>>4</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                                 @if(count($skilss))
                        @foreach($skilss as $exist_course)
                        <input type="hidden" name="course_id[]" value="{{$exist_course->id }}" />
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                        <div class="form-group">
                                            <label class="control-label col-sm-12">Subject<span>*</span></label> 
                                            <div class="col-sm-12">
                                                <select class="form-control" id="select_subject" name="select_subject[]">
                                                    <option value="">Select Subject</option>
                                                    @foreach($areaint as $as)
                                                    <option value="{{$as->id}}" <?php if ($exist_course->Subject == $as->id) echo 'selected'; ?> >{{$as->area_intrest}}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>        
                                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                        <div class="form-group">
                                            <label class="control-label col-sm-12">Category<span>*</span></label> 
                                            <div class="col-sm-12">
                                                <select class="form-control" id="select_category1" name="select_category[]">
                                                    <option value="">Select category</option>
                                                    @foreach($qlist as $as)
                                                        <option value="{{$as->id}}" <?php if ($exist_course->Category == $as->id) echo 'selected'; ?> >{{$as->qulaification}}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12" id="asdf">
                                        <br>
                                    </div>
                                  
                                </div>
                        
                        @endforeach
                        @endif
                            </div>
                        </div>
                        <div class="row formfooter">
                            <div class="col-md-8">
                                <div class="row">
                                    <div class="col-md-5">
                                        <h2 class="profile_title">profile completion</h2>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="progress active">
                                            <div class="progress-bar  progress-bar-info progress-bar-striped" style="width: 50%" role="progressbar" aria-valuenow="50" aria-valuemin="50" aria-valuemax="100">
                                                50%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <button type="submit" class=" btn btn-primary profile-btn pull-right btn-lg" id="next-step">Next</button>
                            </div>
                        </div>
                    </form>
                    <div class="voca hide" id="newrow">
                        <div class="col-md-12">
                            <hr>
                        </div>                                
                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                            <div class="form-group">
                                <label class="control-label col-sm-12">Subject<span>*</span></label> 
                                <div class="col-sm-12">
                                    <select class="form-control" id="select_subject" name="select_subject[]">
                                        <option value="">Select Subject</option>
                                        @foreach($areaint as $as)
                                        <option value="{{$as->id}}">{{$as->area_intrest}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>        
                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                            <div class="form-group">
                                <label class="control-label col-sm-12">Category<span>*</span></label> 
                                <div class="col-sm-12">
                                    <select class="form-control" id="select_category1" name="select_category[]">
                                        <option value="">Select category</option>
                                        @foreach($qlist as $as)
                                        <option value="{{$as->id}}">{{$as->qulaification}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-12 text-right" >
                            <a class="delqual pull-right" datacount=""><i class="fa fa-trash" ></i> Delete Qualification Details</a>
                        </div>
                    </div>
                </div>

            </div>
        </section>
    </div>
</div>

@endsection

@section('jsfiles')

<script>
$(function () {

    $('#tprofile_Form').formValidation({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            select_experience: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            },
            currentorg: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            },
            preorg: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            },
            select_grades: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            },
            'select_subject[]': {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            },
            'select_category[]': {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }
        }
    }).on('click', '.qaulddr', function () {
        var $template = $('#newrow'),
                $clone = $template
                .clone()
                .removeClass('hide')
                .removeAttr('id')
                .insertBefore("#asdf"),
                $option = $clone.find('[name="select_subject[]"]'),
                $option1 = $clone.find('[name="select_category[]"]')

        // Add new field
        $('#tprofile_Form').formValidation('addField', $option);
        $('#tprofile_Form').formValidation('addField', $option1);
    })

            // Remove button click handleraler
            .on('click', '.delqual', function () {
                var $row = $(this).parent().parents('.voca'),
                        $option = $row.find('[name="select_subject[]"]'),
                        $option1 = $row.find('[name="select_category[]"]');
                // Remove element containing the option
                $row.remove();
                // Remove field
                $('#tprofile_Form').formValidation('removeField', $option);
                $('#tprofile_Form').formValidation('removeField', $option1);
            });
});
</script>
@endsection
