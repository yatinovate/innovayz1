@extends('layouts.master')
@section('headscript')
<title>Step 3 | College Profile Wizard</title>
<link rel="stylesheet" href="{{asset("css/profile_steps.css")}}">

@endsection
@section('content')
<div class="container">
    <div class="row">
        <section>
            <div class="wizard">
                <div class="wizard-inner">
                    <div class="connecting-line"></div>
                    <ul class="nav nav-tabs" role="tablist">

                        <li role="presentation" class="visited disabled">
                            <a data-toggle="tab" aria-controls="step1" role="tab" title="Step 1">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-user"></i>
                                </span>
                            </a>
                            <p>College Details</p>
                        </li>

                        <li role="presentation" class="visited disabled">
                            <a data-toggle="tab" aria-controls="step2" role="tab" title="Step 2">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-education"></i>
                                </span>
                            </a>
                            <p>Course Details</p>
                        </li>
                        <li role="presentation" class="active">
                            <a data-toggle="tab" aria-controls="step3" role="tab" title="Step 3">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-envelope"></i>
                                </span>
                            </a>
                            <p>Contact Details</p>
                        </li>


                    </ul>
                </div>
                <div class="wizard_form_wraper">
                    @if (session('issues'))
                    <div class="alert alert-danger">
                        {{ session('issues') }}
                    </div>
                    @endif
                    <form id="tprofile_Form" method="post" role='form' class="form-horizontal" action="{{Route("profile.contact")}}">
                        {{ csrf_field() }}
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-sm-12" for="address">Address<span>*</span></label>    
                                    <div class="col-md-12">
                                        <textarea name="address" rows="8" id="address"  placeholder="Address" class="form-control"></textarea>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-sm-12" for="mobile">Phone No</label>    
                                    <div class="col-md-12">
                                        <input type="text" name="mobile" id="mobile"  placeholder="Mobile" class="form-control" >
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label class="control-label col-sm-12" for="skype">Skype Id</label>    
                                    <div class="col-md-12">
                                        <input type="text" name="skype" id="skype"  placeholder="skype" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-12 " for="uddhear">How did you hear about Innovayz<span>*</span></label> 
                                    <div class="col-md-12">
                                        <select class="form-control" id="uddhear" name="uddhear">

                                            <option value="">Select Options</option>
                                            <option value="Internet Search">Internet Search</option>
                                            <option value="Advertisment">Advertisment</option>
                                            <option value="Newspaper">Newspaper</option>
                                            <option value="Magazine">Magazine</option>
                                            <option value="Facebook">Facebook</option>
                                            <option value="Radio">Radio</option>
                                            <option value="Email">Email</option>
                                            <option value="Friends">Friends</option>
                                            <option value="Events">Events</option>
                                            <option value="Poster">Poster</option>
                                            <option value="Text Message">Text Message</option>
                                            <option value="Teachers">Teachers</option>
                                            <option value="Others">Others</option>

                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label class="control-label col-sm-12 " for="country">Country</label> 
                                    <div class="col-md-12">
                                        <input type="text" id="country" name="country" readonly="" placeholder="Country" class="form-control" value="India">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label class="control-label col-sm-12 " for="state">State</label> 
                                    <div class="col-md-12">
                                        <?php
                                        $states= \App\Models\User\CityState::select('city_state')->distinct()->orderBy('city_state', 'ASC')->get();
                                        ?>
                                        <select class="form-control" id="state" name="state">
                                            <option value="null">Select State</option>
                                            @foreach($states as $st)
                                            <option value="{{$st->city_state}}">{{$st->city_state}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label class="control-label col-sm-12 " for="city">City<span>*</span></label> 
                                    <div class="col-md-12">
                                        <select class="form-control" name="city" id="city">
                                            <option value="">Select City</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label class="control-label col-sm-12 " for="pncode">Pincode</label> 
                                    <div class="col-md-12">
                                        <input type="text" class="form-control"  name="pncode" id="pncode" placeholder="Pincode" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group">
                                <label class="control-label col-sm-12 " for="state"></label> 
                                <div class="col-sm-12 form-inline">
                                    <div class="checkbox" >
                                        <label class="checkbox-label">
                                            <input type="checkbox" id="accept-terms" name="recieveudates" value="1" />
                                            &nbsp;&nbsp;Would you like to receive the updates for the respective area of interest
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row formfooter">
                            <div class="col-md-8">
                                <div class="row">
                                    <div class="col-md-5">
                                        <h2 class="profile_title">profile completion</h2>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="progress active">
                                            <div class="progress-bar  progress-bar-info progress-bar-striped" style="width: 75%" role="progressbar" aria-valuenow="75" aria-valuemin="75" aria-valuemax="100">
                                                75%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="row">
                                    <div class="col-md-4 col-md-offset-4 text-right">
                                        <a href="{{Route('Dashboard')}}" class=" btn btn-primary profile-btn btn-lg" id="next-step">Skip</a>
                                    </div>
                                    <div class="col-md-4">
                                        <button type="submit" class=" btn btn-primary profile-btn pull-right btn-lg" id="next-step">Next</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

            </div>
        </section>
    </div>
</div>

@endsection

@section('jsfiles')
<script>
$(function () {
    $("#state").change(function(){
         var areal = $(this).val();
            $.get('{{Route("profile.getCity")}}', {areau: areal}, function (data) {
                $("#city").html(data);
            });
    });
    $('#tprofile_Form').formValidation({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            address: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            },
            mobile: {
                validators: {
                    regexp: {
                        message: 'The phone number can only contain the digits, spaces, -, (, ), + and .',
                        regexp: /^[0-9\s\-()+\.]+$/
                    },
                    phone: {
                        message: 'Please enter a valid phone no',
                        country: 'IN'
                    }, lessThan: {
                        value: 9999999999,
                        message: 'Please enter a valid phone no'
                    },
                    countries: {
                        IN: 'India',
                        US: 'USA'
                    }
                }
            },
            uddhear: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }, city: {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }
        }
    });


});
</script>
@endsection
