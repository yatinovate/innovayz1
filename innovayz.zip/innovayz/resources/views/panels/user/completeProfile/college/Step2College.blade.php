@extends('layouts.master')
@section('headscript')
<title>Step 2 | College Profile Wizard</title>
<link rel="stylesheet" href="{{asset("css/profile_steps.css")}}">
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<style>
    .voca{
        margin-bottom: 30px;
    }
</style>
@endsection
@section('content')
<div class="container">
    <div class="row">
        <section>
            <div class="wizard">
                <div class="wizard-inner">
                    <div class="connecting-line"></div>
                    <ul class="nav nav-tabs" role="tablist">

                        <li role="presentation" class="visited disabled">
                            <a data-toggle="tab" aria-controls="step1" role="tab" title="Step 1">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-user"></i>
                                </span>
                            </a>
                            <p>College Details</p>
                        </li>

                        <li role="presentation" class="active">
                            <a data-toggle="tab" aria-controls="step2" role="tab" title="Step 2">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-education"></i>
                                </span>
                            </a>
                            <p>Course Details</p>
                        </li>
                        <li role="presentation" class="disabled">
                            <a data-toggle="tab" aria-controls="step3" role="tab" title="Step 3">
                                <span class="round-tab">
                                    <i class="glyphicon glyphicon-envelope"></i>
                                </span>
                            </a>
                            <p>Contact Details</p>
                        </li>


                    </ul>
                </div>
                <div class="wizard_form_wraper">
                    @if (session('issues'))
                    <div class="alert alert-danger">
                        {{ session('issues') }}
                    </div>
                    @endif


                    <form id="tprofile_Form" method="post" role='form' class="form-horizontal" action="{{Route('college.savestep2')}}">
                        {{ csrf_field() }}
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Course Name<span>*</span></label>
                                    <div class="col-sm-12">
                                        <select name="col_name[]" id="col_name" class="form-control">
                                            <option value="">Select Course</option>
                                            @foreach($course as $as)
                                            <option value="{{$as->id}}">{{$as->qulaification}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-sm-12">Duration<span>*</span></label>
                                    <div class="col-sm-6">
                                        <select name="col_yr[]" id="col_yr" class="form-control">
                                            <option value="">Select Year</option>
                                            <option value="0">0 year</option>
                                            <option value="1">1 year</option>
                                            <option value="2">2 year</option>
                                            <option value="3">3 year</option>
                                            <option value="4">4 year</option>
                                            <option value="5">5 year</option>
                                            <option value="6">6 year</option>
                                            <option value="7">7 year</option>
                                            <option value="8">8 year</option>
                                            <option value="9">9 year</option>
                                            <option value="10">10 year</option>
                                        </select>
                                    </div>
                                    <div class="col-sm-6">
                                        <select name="col_month[]" id="col_month" class="form-control">
                                            <option value="">Select Month</option>
                                            <option value="0">0 Month</option>
                                            <option value="1">1 Month</option>
                                            <option value="2">2 Month</option>
                                            <option value="3">3 Month</option>
                                            <option value="4">4 Month</option>
                                            <option value="5">5 Month</option>
                                            <option value="6">6 Month</option>
                                            <option value="7">7 Month</option>
                                            <option value="8">8 Month</option>
                                            <option value="9">9 Month</option>
                                            <option value="10">10 Month</option>
                                            <option value="11">11 Month</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Course Description</label>
                                    <div class="col-sm-12">
                                        <textarea class="form-control"  rows="5" id="course_desc" name="course_desc[]" placeholder="Course Description" ></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Stream<span>*</span></label>
                                    <div class="col-sm-12 ui-widget">
                                        
                                        <input type="text" class="form-control institute" autocomplete="off"  name="col_stream[]" id="col_stream" placeholder="Stream" />
                                        <input type="hidden"   name="col_stream1[]" id="col_stream1" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Course Fee<span>*</span></label>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control" id="col_feee" name="col_feee[]" placeholder="Course Fee"/>
                                    </div>
                                    <div class="col-sm-6">
                                        <select name="fee_type[]" id="fee_type" class="form-control">
                                            <option value="">Select Fee</option>
                                            <option value="Total Fee">Total Fee</option>
                                                <option value="Monthly Fee">Monthly Fee</option>
                                                <option value="Quarterly Fee">Quarterly Fee</option>
                                                <option value="Half Yearly Fee">Half Yearly Fee</option>
                                                <option value="Yearly Fee">Yearly Fee</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Eligibility Criteria</label>
                                    <div class="col-sm-12">
                                        <textarea class="form-control"  rows="5" id="course_eligibility" name="course_eligibility[]" placeholder="Eligibility Criteria" ></textarea>
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-12 text-right">
                                <a class="qaulddr pull-right" datacount=""><i class="fa fa-plus-circle" ></i> Add More Course</a>
                            </div>
                            <div class="col-md-12" id="asdf">
                                <br>
                            </div>                           

                        </div>

                        <div class="row formfooter">
                            <div class="col-md-8">
                                <div class="row">
                                    <div class="col-md-5">
                                        <h2 class="profile_title">profile completion</h2>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="progress active">
                                            <div class="progress-bar  progress-bar-info progress-bar-striped" style="width: 55%" role="progressbar" aria-valuenow="55" aria-valuemin="55" aria-valuemax="100">
                                                55%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <button type="submit" class=" btn btn-primary profile-btn pull-right btn-lg" id="next-step">Next</button>
                            </div>
                        </div>


                    </form>
                    <div class="voca hide" id="newrow">
                        <div class="col-md-12">
                            <hr>
                        </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label class="control-label col-sm-12">Course Name<span>*</span></label>
                                        <div class="col-sm-12">
                                            <select name="col_name[]" id="col_name" class="form-control">
                                                <option value="">Select Course</option>
                                                @foreach($course as $as)
                                                <option value="{{$as->id}}">{{$as->qulaification}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="control-label col-sm-12">Duration<span>*</span></label>
                                        <div class="col-sm-6">
                                            <select name="col_yr[]" id="col_yr" class="form-control">
                                                <option value="">Select Year</option>
                                                <option value="0">0 year</option>
                                                <option value="1">1 year</option>
                                                <option value="2">2 year</option>
                                                <option value="3">3 year</option>
                                                <option value="4">4 year</option>
                                                <option value="5">5 year</option>
                                                <option value="6">6 year</option>
                                                <option value="7">7 year</option>
                                                <option value="8">8 year</option>
                                                <option value="9">9 year</option>
                                                <option value="10">10 year</option>
                                            </select>
                                        </div>
                                        <div class="col-sm-6">
                                            <select name="col_month[]" id="col_month" class="form-control">
                                                <option value="">Select Month</option>
                                                <option value="0">0 Month</option>
                                                <option value="1">1 Month</option>
                                                <option value="2">2 Month</option>
                                                <option value="3">3 Month</option>
                                                <option value="4">4 Month</option>
                                                <option value="5">5 Month</option>
                                                <option value="6">6 Month</option>
                                                <option value="7">7 Month</option>
                                                <option value="8">8 Month</option>
                                                <option value="9">9 Month</option>
                                                <option value="10">10 Month</option>
                                                <option value="11">11 Month</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label col-sm-12">Course Description</label>
                                        <div class="col-sm-12">
                                            <textarea class="form-control"  rows="5" id="course_desc" name="course_desc[]" placeholder="Course Description" ></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label class="control-label col-sm-12">Stream<span>*</span></label>
                                        <div class="col-sm-12 ui-widget">
                                            <input type="text" class="form-control institute" autocomplete="off"  name="col_stream[]" id="col_stream" placeholder="Stream" />
                                            <input type="hidden"   name="col_stream1[]" id="col_stream1" />                                     
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label col-sm-12">Course Fee<span>*</span></label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" id="col_feee" name="col_feee[]" placeholder="Course Fee"/>
                                        </div>
                                        <div class="col-sm-6">
                                            <select name="fee_type[]" id="fee_type" class="form-control">
                                                <option value="">Select Fee</option>
                                                <option value="Total Fee">Total Fee</option>
                                                <option value="Monthly Fee">Monthly Fee</option>
                                                <option value="Quarterly Fee">Quarterly Fee</option>
                                                <option value="Half Yearly Fee">Half Yearly Fee</option>
                                                <option value="Yearly Fee">Yearly Fee</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label col-sm-12">Eligibility Criteria</label>
                                        <div class="col-sm-12">
                                            <textarea class="form-control"  rows="5" id="course_eligibility" name="course_eligibility[]" placeholder="Eligibility Criteria" ></textarea>                                            
                                        </div>
                                    </div>

                                </div>
                        <div class="col-md-12 text-right" >
                            <a class="delqual pull-right" datacount=""><i class="fa fa-trash" ></i> Delete Course</a>
                        </div>
                            </div>
                </div>

            </div>
        </section>
    </div>
</div>

@endsection

@section('jsfiles')
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>

<script>
$(function () {
    
$('#col_name').change(function (e) {
            var selectvalue = $(this).val();
            if (!selectvalue == "") {
                $(".institute").autocomplete({
    source: '{{URL::to("profile/wizard/college/getstream")}}/'+selectvalue,
    select: function (event, ui) {
         $('#col_stream1').val(ui.item.id); 
     }
});   
            } 
        });




    $('#tprofile_Form').formValidation({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            'col_name[]': {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            },
            'col_yr[]': {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            },
            'col_month[]': {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }
            , 'col_stream[]': {
                validators: {
                    notEmpty: {
                        message: 'required'
                    },regexp: {
                        regexp: /^[a-z\s]+$/i,
                        message: 'invalid input'
                    }
                }
            }, 'col_feee[]': {
                validators: {
                    notEmpty: {
                        message: 'required'
                    },
                    numeric: {
                            message: 'The value is not a number',
                            // The default separators
                            thousandsSeparator: '',
                            decimalSeparator: '.'
                        }
                }
            }, 'fee_type[]': {
                validators: {
                    notEmpty: {
                        message: 'required'
                    }
                }
            }

        }
    }).on('click', '.qaulddr', function () {
        var $template = $('#newrow'),
                $clone = $template
                .clone()
                .removeClass('hide')
                .removeAttr('id')
                .insertBefore("#asdf"),
                $option = $clone.find('[name="col_name[]"]'),
                $option1 = $clone.find('[name="col_yr[]"]'),
                $option2 = $clone.find('[name="col_month[]"]'),
                $option3 = $clone.find('[name="course_desc[]"]'),
                $option4 = $clone.find('[name="col_stream[]"]'),
                $option5 = $clone.find('[name="col_feee[]"]'),
                $option6 = $clone.find('[name="fee_type[]"]'),
                $option7 = $clone.find('[name="course_eligibility[]"]');

        // Add new field
        $('#tprofile_Form').formValidation('addField', $option);
        $('#tprofile_Form').formValidation('addField', $option1);
        $('#tprofile_Form').formValidation('addField', $option2);
        $('#tprofile_Form').formValidation('addField', $option3);
        $('#tprofile_Form').formValidation('addField', $option4);
        $('#tprofile_Form').formValidation('addField', $option5);
        $('#tprofile_Form').formValidation('addField', $option6);
        $('#tprofile_Form').formValidation('addField', $option7);
        $($option).change(function (e) {
            var selectvalue = $(this).val();
            if (!selectvalue == "") {
                $(".institute").autocomplete({
    source: '{{URL::to("profile/wizard/college/getstream")}}/'+selectvalue,
    select: function (event, ui) {
         $clone.find('[name="col_stream1[]"]').val(ui.item.id); 
     }
});   
            } 
        });
     
    
    })

            // Remove button click handleraler
            .on('click', '.delqual', function () {
                var $row = $(this).parent().parents('.voca'),
                        $option = $row.find('[name="col_name[]"]'),
                        $option1 = $row.find('[name="col_yr[]"]'),
                        $option2 = $row.find('[name="col_month[]"]'),
                        $option3 = $row.find('[name="course_desc[]"]'),
                        $option4 = $row.find('[name="col_stream[]"]'),
                        $option5 = $row.find('[name="col_feee[]"]'),
                        $option6 = $row.find('[name="fee_type[]"]'),
                        $option7 = $row.find('[name="course_eligibility[]"]');

                // Remove element containing the option
                $row.remove();

                // Remove field
                $('#tprofile_Form').formValidation('removeField', $option);
                $('#tprofile_Form').formValidation('removeField', $option1);
                $('#tprofile_Form').formValidation('removeField', $option2);
                $('#tprofile_Form').formValidation('removeField', $option3);
                $('#tprofile_Form').formValidation('removeField', $option4);
                $('#tprofile_Form').formValidation('removeField', $option5);
                $('#tprofile_Form').formValidation('removeField', $option6);
                $('#tprofile_Form').formValidation('removeField', $option7);
            });
});
</script>

@endsection
