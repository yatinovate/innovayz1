@extends('layouts.master')

@section('headscript')
<link rel="stylesheet" href="{{asset("css/complteprofile.css")}}">
<title>Social User | Innovayz</title>
@endsection
@section('content')
<section class="comprofile">
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h2 class="text-center">Register as :</h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="panel-body">
                        <div class="col-md-6 col-md-offset-3">
                        <form id="tprofile_Form" method="post" class="form-horizontal" action="{{route("socilaprofileuser")}}">
                            {{ csrf_field() }}
                                <div class="form-group">
                                    <label class="control-label col-sm-12">User Type<span>*</span></label>
                                    <div class="col-sm-12">
                                        <div class="form-inline">      
                                            <div class="col-md-4">
                                                <input type="radio" name="utype" value="students" />
                                                <label class="radio_label">Student</label>
                                            </div>
                                            <div class="col-md-4">
                                                <input type="radio" name="utype" checked="checked" value="teachers"/>
                                                <label class="radio_label">Teacher</label>
                                            </div>
                                            <div class="col-md-4">

                                                <input type="radio" name="utype" value="colleges" />
                                                <label class="radio_label">College</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        </form>
                    </div>
                    </div>
                    <div class="panel-footer">
                        <button type="submit" class="btn btn-info pull-right" id="next-step">Next</button>
                        <div class="clearfix"></div>    
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

@endsection


@section('jsfiles')

<script>
$(function () {


    $("#next-step").click(function (e) {
        $("#tprofile_Form").submit();

    });

});
</script>
@endsection
