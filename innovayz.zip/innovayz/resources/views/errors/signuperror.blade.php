@if(session()->has('signuperror'))
    <div class="alert alert-danger fade in error_block">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        {{ Session::get('signuperror')}}
    </div>
@endif

@if(session()->has('signupsuccess'))
    <div class="alert alert-success fade in error_block">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        {{ Session::get('signupsuccess')}}
    </div>
@endif
@if(session()->has('errors'))
    <div class="alert alert-danger fade in error_block">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <ul>
            @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif