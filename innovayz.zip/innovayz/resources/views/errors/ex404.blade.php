@extends('layouts.master')
@section('headscript')
<link href="{{asset("css/error.css")}}" rel="stylesheet" type="text/css">
@stop
@section('content')
<div class="error_wraper">
    <div class="container">


        <div class="row">
            <div class="col-md-9">
                <div class="error_cont">
                    <h2><img src="{{asset("images/error.png")}}" >404</h2>
                    <h3>Oops... page not found!</h3><br>
                   

                    

                </div>

            </div>
            <div class="col-md-3">
                @include("includes.adblock")
            </div>

        </div>
    </div>
</div>


@stop



@section('jsfiles')

@endsection




