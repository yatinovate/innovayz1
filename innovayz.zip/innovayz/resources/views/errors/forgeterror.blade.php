@if(session()->has('forgeterror'))
    <div class="alert alert-danger fade in error_block">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        {{ Session::get('forgeterror')}}
    </div>
@endif

@if(session()->has('forgetsucess'))
    <div class="alert alert-success fade in error_block">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        {{ Session::get('forgetsucess')}}
    </div>
@endif