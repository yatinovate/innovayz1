<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMultiOptionSkillsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('multi_option_skills', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('skill_tests_id')->unsigned()->index();
            $table->foreign('skill_tests_id')->references('id')->on('skill_test_mains')->onDelete('cascade');   
            $table->string('points');
            $table->string('question');
            $table->string('ans_a');
            $table->string('ans_b');
            $table->string('ans_c');
            $table->string('ans_d');
            $table->string('correct_ans');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('multi_option_skills');
    }
}
