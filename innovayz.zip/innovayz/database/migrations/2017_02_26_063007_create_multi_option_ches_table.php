<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMultiOptionChesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('multi_option_ches', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('challenge_id')->unsigned()->index();
            $table->foreign('challenge_id')->references('id')->on('challenge_tests')->onDelete('cascade');            
            $table->string('points');
            $table->string('question');
            $table->string('ans_a');
            $table->string('ans_b');
            $table->string('ans_c');
            $table->string('ans_d');
            $table->string('correct_ans');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('multi_option_ches');
    }
}
