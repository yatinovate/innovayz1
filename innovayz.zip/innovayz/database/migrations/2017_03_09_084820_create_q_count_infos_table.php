<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateQCountInfosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('q_count_infos', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('skill_tests_id')->unsigned()->index();
            $table->foreign('skill_tests_id')->references('id')->on('skill_test_mains')->onDelete('cascade');   
            $table->integer('question_id');
            $table->integer('actual_question_id');
            $table->string('qtype');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('q_count_infos');
    }
}
