<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUploadCsvsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('upload_csvs', function (Blueprint $table) {
            $table->increments('id');
            $table->string('csvname');
            $table->string('isActive');
            $table->integer('skill_tests_id')->unsigned()->index();
            $table->foreign('skill_tests_id')->references('id')->on('skill_test_mains')->onDelete('cascade');   
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('upload_csvs');
    }
}
