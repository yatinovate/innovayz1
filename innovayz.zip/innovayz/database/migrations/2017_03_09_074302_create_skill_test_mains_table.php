<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSkillTestMainsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('skill_test_mains', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('user_id')->unsigned()->index();
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->string('skill_test_name');
            $table->integer('category');
            $table->integer('subject');
            $table->string('description');
            $table->string('start_date');
            $table->string('end_date');
            $table->integer('questn_count');
            $table->integer('duration');    
            $table->integer('qnoprocess')->default(0);    
            $table->integer('publish')->default(0);
            $table->integer('archive')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('skill_test_mains');
    }
}
