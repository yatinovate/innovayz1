<?php

namespace App\Listeners;

use App\Events\NotifyUsers;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class NotifyUserListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public $userid;
    public $subject;
    public $body;
    public $link;
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  NotifyUsers  $event
     * @return void
     */
    public function handle(NotifyUsers $event)
    {
        $this->userid = $event->userid;
        $this->subject = $event->subject;
        $this->body = $event->body;        
        $this->link = $event->link;  
        
        $notify = new \App\Models\User\NotificationSystem();
        $notify->user_id = $this->userid;
        $notify->subject = $this->subject;
        $notify->body = $this->body;
        $notify->link = $this->link;
        $notify->save();
    }
}
