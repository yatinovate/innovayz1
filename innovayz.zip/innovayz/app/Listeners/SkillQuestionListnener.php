<?php

namespace App\Listeners;

use App\Events\SkillTester;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class SkillQuestionListnener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
     protected $skillid;
    protected $testid;
    protected $qtype;
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  SkillTester  $event
     * @return void
     */
    public function handle(SkillTester $event)
    {
        $this->skillid = $event->skillid;
        $this->testid=$event->testid;
        $this->qtype=$event->qtype;
        
        $qprocess = \App\Models\Skill\SkillTestMain::find($this->skillid);
        
        $prevq = $qprocess->qnoprocess;
        $qprocess->qnoprocess = $prevq + 1;
        $qprocess->save();
        $qcount = new \App\Models\Skill\QCountInfo();
        $qcount->skill_tests_id = $this->skillid;
        $qcount->question_id = $prevq + 1;
        $qcount->actual_question_id = $this->testid;
        $qcount->qtype = $this->qtype;
        $qcount->save();
    }
}
