<?php

namespace App\Listeners;

use App\Events\ChallengeTester;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class ChallengeListnener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    protected $skillid;
    protected $testid;
    protected $qtype;
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  ChallengeTester  $event
     * @return void
     */
    public function handle(ChallengeTester $event)
    {
        $this->skillid = $event->skillid;
        $this->testid=$event->testid;
        $this->qtype=$event->qtype;
        
        $qprocess = \App\Models\Challenge\ChallengeTest::find($this->skillid);
        
        $prevq = $qprocess->qnoprocess;
        $qprocess->qnoprocess = $prevq + 1;
        $qprocess->save();
        $qcount = new \App\Models\Challenge\QCountInfoCh();
        $qcount->challenge_id = $this->skillid;
        $qcount->question_id = $prevq + 1;
        $qcount->actual_question_id = $this->testid;
        $qcount->qtype = $this->qtype;
        $qcount->save();
    }
}
