<?php

namespace App\Listeners;

use App\Events\CsvUploaded;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use League\Csv\Reader;

class CsvUploadListner {

    /**
     * Create the event listener.
     *
     * @return void
     */
    protected $skillid;
    protected $upload_id;
    protected $uploadclass;

    public function __construct() {
        //
    }

    /**
     * Handle the event.
     *
     * @param  CsvUploaded  $event
     * @return void
     */
    public function handle(CsvUploaded $event) {
        $this->skillid = $event->skillid;
        $this->upload_id = $event->upload_id;
        $this->uploadclass = $event->uploadclass;

        if ($this->uploadclass == 'UploadCsv') {
            $uplfile = \App\Models\Skill\UploadCsv::find($this->upload_id);
            $reader = Reader::createFromPath('uploads/' . $uplfile->csvname);
            $results = $reader->fetch();
            foreach ($results as $row) {
                $esd = $this->QuizClassfinder($row[0]);
                $myclass = '\App\\Models\\Skill\\' . $esd;

                if ($esd == 'MultiChoice') {
                    $test = new $myclass();
                    $test->skill_tests_id = $this->skillid;
                    $test->points = $row[7];
                    $test->question = $row[1];
                    $test->ans_a = $row[2];
                    $test->ans_b = $row[3];
                    $test->ans_c = $row[4];
                    $test->ans_d = $row[5];
                    $test->correct_ans = $row[6];
                    $test->save();

                    $qprocess = \App\Models\Skill\SkillTestMain::find($this->skillid);
                    $prevq = $qprocess->qnoprocess;
                    $qprocess->qnoprocess = $prevq + 1;
                    $qprocess->save();
                    $qcount = new \App\Models\Skill\QCountInfo();
                    $qcount->skill_tests_id = $this->skillid;
                    $qcount->question_id = $prevq + 1;
                    $qcount->actual_question_id = $test->id;
                    $qcount->qtype = 'MultiChoice';
                    $qcount->save();
                } else if ($esd == 'MultiOptionSkill') {
                    $test = new $myclass();
                    $test->skill_tests_id = $this->skillid;
                    $test->points = $row[7];
                    $test->question = $row[1];
                    $test->ans_a = $row[2];
                    $test->ans_b = $row[3];
                    $test->ans_c = $row[4];
                    $test->ans_d = $row[5];
                    $test->correct_ans = $row[6];
                    $test->save();
                    $qprocess = \App\Models\Skill\SkillTestMain::find($this->skillid);
                    $prevq = $qprocess->qnoprocess;
                    $qprocess->qnoprocess = $prevq + 1;
                    $qprocess->save();
                    $qcount = new \App\Models\Skill\QCountInfo();
                    $qcount->skill_tests_id = $this->skillid;
                    $qcount->question_id = $prevq + 1;
                    $qcount->actual_question_id = $test->id;
                    $qcount->qtype = 'MultiOptionSkill';
                    $qcount->save();
                } else if ($esd == 'TrueFalseSkill') {
                    $test = new $myclass();
                    $test->skill_tests_id = $this->skillid;
                    $test->points = $row[7];
                    $test->question = $row[1];
                    $test->correct_ans = $row[6];
                    $test->save();
                    $qprocess = \App\Models\Skill\SkillTestMain::find($this->skillid);
                    $prevq = $qprocess->qnoprocess;
                    $qprocess->qnoprocess = $prevq + 1;
                    $qprocess->save();
                    $qcount = new \App\Models\Skill\QCountInfo();
                    $qcount->skill_tests_id = $this->skillid;
                    $qcount->question_id = $prevq + 1;
                    $qcount->actual_question_id = $test->id;
                    $qcount->qtype = 'TrueFalseSkill';
                    $qcount->save();
                }
            }
        } else if ($this->uploadclass == 'UploadCsvCh') {
            $uplfile = \App\Models\Challenge\UploadCsvCh::find($this->upload_id);
            $reader = Reader::createFromPath('uploads/' . $uplfile->csvname);
            $results = $reader->fetch();
            foreach ($results as $row) {
                $esd = $this->QuizClassfinder1($row[0]);
                $myclass = '\App\\Models\\Challenge\\' . $esd;

                if ($esd == 'MultiChoiceCh') {
                    $test = new $myclass();
                    $test->challenge_id = $this->skillid;
                    $test->points = $row[7];
                    $test->question = $row[1];
                    $test->ans_a = $row[2];
                    $test->ans_b = $row[3];
                    $test->ans_c = $row[4];
                    $test->ans_d = $row[5];
                    $test->correct_ans = $row[6];
                    $test->save();

                    $qprocess = \App\Models\Challenge\ChallengeTest::find($this->skillid);
                    $prevq = $qprocess->qnoprocess;
                    $qprocess->qnoprocess = $prevq + 1;
                    $qprocess->save();
                    $qcount = new \App\Models\Challenge\QCountInfoCh();
                    $qcount->challenge_id = $this->skillid;
                    $qcount->question_id = $prevq + 1;
                    $qcount->actual_question_id = $test->id;
                    $qcount->qtype = 'MultiChoiceCh';
                    $qcount->save();
                } else if ($esd == 'MultiOptionCh') {
                    $test = new $myclass();
                    $test->challenge_id = $this->skillid;
                    $test->points = $row[7];
                    $test->question = $row[1];
                    $test->ans_a = $row[2];
                    $test->ans_b = $row[3];
                    $test->ans_c = $row[4];
                    $test->ans_d = $row[5];
                    $test->correct_ans = $row[6];
                    $test->save();
                    $qprocess = \App\Models\Challenge\ChallengeTest::find($this->skillid);
                    $prevq = $qprocess->qnoprocess;
                    $qprocess->qnoprocess = $prevq + 1;
                    $qprocess->save();
                    $qcount = new \App\Models\Challenge\QCountInfoCh();
                    $qcount->challenge_id = $this->skillid;
                    $qcount->question_id = $prevq + 1;
                    $qcount->actual_question_id = $test->id;
                    $qcount->qtype = 'MultiOptionCh';
                    $qcount->save();
                } else if ($esd == 'TrueFalseSkillCh') {
                    $test = new $myclass();
                    $test->challenge_id = $this->skillid;
                    $test->points = $row[7];
                    $test->question = $row[1];
                    $test->correct_ans = $row[6];
                    $test->save();
                    $qprocess = \App\Models\Challenge\ChallengeTest::find($this->skillid);
                    $prevq = $qprocess->qnoprocess;
                    $qprocess->qnoprocess = $prevq + 1;
                    $qprocess->save();
                    $qcount = new \App\Models\Challenge\QCountInfoCh();
                    $qcount->challenge_id = $this->skillid;
                    $qcount->question_id = $prevq + 1;
                    $qcount->actual_question_id = $test->id;
                    $qcount->qtype = 'TrueFalseSkillCh';
                    $qcount->save();
                }
            }
        }
    }

    public function QuizClassfinder($param) {
        $vars = "";
        switch ($param) {
            case 'MC':
                $vars = "MultiChoice";
                break;
            case 'SC':
                $vars = "MultiOptionSkill";
                break;
            case 'TF':
                $vars = "TrueFalseSkill";
                break;
        }
        return $vars;
    }

    public function QuizClassfinder1($param) {
        $vars = "";
        switch ($param) {
            case 'MC':
                $vars = "MultiChoiceCh";
                break;
            case 'SC':
                $vars = "MultiOptionCh";
                break;
            case 'TF':
                $vars = "TrueFalseSkillCh";
                break;
        }
        return $vars;
    }

}
