<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Requests;
use DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use Illuminate\Support\Facades\Input;
use \App\Traits\ActivationTrait;
use App\Models\User\AreaIntrest;
use App\Models\User\User_Area;
use App\Models\User\UserInstitute;
use App\Models\User\User_Stream;
use App\Models\User\Courses;
use App\Models\User\QualificationList;
use App\Models\Campaign;
use Illuminate\Support\Facades\Auth;

class AdminAuth extends Controller {
    use ActivationTrait;

    public function AdminDashboard() {
        $alluser = User::all();
        $ouser = 0;
        foreach ($alluser as $user) {
            if ($user->isOnline()) {
                $ouser++;
            }
        }
        $number = DB::table('users')->count();
        $skills = DB::select('select * from area_intrests');
        $visitor=DB::table('visitors')->select('count')->first();
        return view('admin.pages.Dashboard', ['alluser'=> $alluser,'newuser' => $number, 'ouser' => $ouser, 'skills' => $skills,'visitor'=>$visitor]);
    }
    protected function viewonlineUser() {
        $ouser = User::all();
        return view('admin.user.online', compact('ouser'));
    }
    protected function viewNewUser() {
        $data = User::orderBy('created_at', 'DESC')->paginate(3);
        return view('admin.user.newuserpagination', compact('data'));
    }
    
    /** add user ****/

    protected function viewadduser() {
        return view('admin.user.addUser');
    }

    public function adduser(Request $request) {
        try {
            $users = new User();
            $users->name = $request["full_name"];
            $users->email = $request["email"];
            $users->password = bcrypt($request["password"]);
            $users->user_type = $request["optradio"];
            $users->token = str_random(64);
            $users->activated = true;
            if ($users->save()) {
                if ($users->user_type == 'admin') {
                    $role = User\Role::whereName('administrator')->first();
                    $users->assignRole($role);
                } else {
                    $role = User\Role::whereName('user')->first();
                    $users->assignRole($role);
                }
                return redirect()->back()->with("status","success")->with("message","user added");
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("status","danger")->with("message","error occured");
        }
    }
    /**** validae user****/
    protected function validateUser() {
        $alluser = User::where("activated",'=','')->get();
        return view('admin.user.validUser', compact('alluser'));
    }
    public function deleteUser() {
        try {
            $users = Input::get('userid');
            $deluser = User::destroy($users);
            if ($deluser) {
                return response()->json(['success' => true], 200);
            }
        } catch (Exception $ex) {
            return response()->json(['success' => false, 'msg' => $ex->getMessage()], 400);
        }
    }
    public function deleteAll(Request $request) {
        try {
            $users = $request['ids'];
            $users = explode(',',$users);
            foreach ($users as $id) {
                $delgroup = User::destroy($id);
            }
             return response()->json(['success' => true,'msg'=>$users], 200);
        } catch (Exception $ex) {
            return response()->json(['success' => false, 'msg' => $ex->getMessage()], 400);
        }
    }
    public function validateSingle() {
        try {
            $users = Input::get('userid');
            $delgroup = User::find($users);
            $delgroup->activated = 1;            
            $delgroup->save();
            if ($delgroup) {
                return response()->json(['success' => true], 200);
            }
        } catch (Exception $ex) {
            return response()->json(['success' => false, 'msg' => $ex->getMessage()], 400);
        }
    }
    public function validateAll(Request $request) {
        try {
            $users = $request['ids'];
            $users = explode(',', $users);
            foreach ($users as $id) {
                $delgroup = User::find($id);
                $delgroup->activated = 1;
                $delgroup->save();
            }
            return response()->json(['success' => true, 'msg' => $users], 200);
        } catch (Exception $ex) {
            return response()->json(['success' => false, 'msg' => $ex->getMessage()], 400);
        }
    }
    public function resend() {
        try {
            $users = Input::get('userid');
            $delgroup = User::find($users);
            $this->initiateEmailActivation($delgroup);
            return response()->json(['success' => true], 200);
        } catch (Exception $ex) {
            return response()->json(['success' => false, 'msg' => $ex->getMessage()], 400);
        }
    }
    public function resendAll(Request $request) {
        try {
            $users = $request['ids'];
            $users = explode(',', $users);
            foreach ($users as $id) {
                $delgroup = User::find($id);
                $this->initiateEmailActivation($delgroup);
            }
            return response()->json(['success' => true], 200);
        } catch (Exception $ex) {
            return response()->json(['success' => false, 'msg' => $ex->getMessage()], 400);
        }
    }
/*****unvalidate end***/

    /**** skillvalidate***/
    protected function set_skills() {
        $skills =AreaIntrest::where("isValid","=","0")->get();
        return view('admin.setting.skills_setting', compact('skills'));
    }
    public function Skilldelete() {
        try {
            $users = Input::get('userid');
            $delgroup = AreaIntrest::destroy($users);
            if ($delgroup) {
                return response()->json(['success' => true], 200);
            }
        } catch (Exception $ex) {
            return response()->json(['success' => false, 'msg' => $ex->getMessage()], 400);
        }
    }
    public function SkilldeleteAll(Request $request) {
        try {
            $users = $request['ids'];
            $users = explode(',',$users);
            foreach ($users as $id) {
                $delgroup = AreaIntrest::destroy($id);
            }
            if($delgroup){
                return response()->json(['success' => true,'msg'=>$users], 200);
            }
        } catch (Exception $ex) {
            return response()->json(['success' => false, 'msg' => $ex->getMessage()], 400);
        }
    }
    public function validateSkills() {
        try {
            $users = Input::get('userid');
            $delgroup = AreaIntrest::find($users);
            $delgroup->isValid = 1;
            $delgroup->save();
            if ($delgroup) {
                $user_area = new User_Area();
                $user_area->user_id = $delgroup->user_id;
                $user_area->area_intrests_id = $delgroup->id;
                if ($user_area->save()) {
                    return response()->json(['success' => true], 200);
                }
            }
        } catch (Exception $ex) {
            return response()->json(['success' => false, 'msg' => $ex->getMessage()], 400);
        }
    }

    public function validateSkillsAll(Request $request) {
        try {
            $users = $request['ids'];
            $users = explode(',', $users);
            foreach ($users as $id) {
                $delgroup = AreaIntrest::find($id);
                $delgroup->isValid = 1;
                $delgroup->save();
                if ($delgroup) {
                    $user_area = new User_Area();
                    $user_area->user_id = $delgroup->user_id;
                    $user_area->area_intrests_id = $delgroup->id;
                    $checker = $user_area->save();
                }
            }
            if ($checker) {
                return response()->json(['success' => true], 200);
            }
        } catch (Exception $ex) {
            return response()->json(['success' => false, 'msg' => $ex->getMessage()], 400);
        }
    }
    /****end skillvalidate***/
    
    /****Institute validate***/
    protected function un_inst() {
        $inst = UserInstitute::where("isValid","=","0")->get();
        return view('admin.setting.institute_setting', compact('inst'));
    }
    public function validateInstitute() {
        try {
            $users = Input::get('userid');
            $delgroup = UserInstitute::find($users);
            $delgroup->isValid = 1;
            $delgroup->save();
            $qual= User\Qulaification::find($delgroup->qualification_id);
            $qual->institute=$users;
            $chkr=$qual->save();
            if ($chkr) {
                return response()->json(['success' => true], 200);
            }
        } catch (Exception $ex) {
            return response()->json(['success' => false, 'msg' => $ex->getMessage()], 400);
        }
    }
     public function validateInstituteAll(Request $request) {
        try {
            $users = $request['ids'];
            $users = explode(',',$users);
            foreach ($users as $id) {
                $delgroup = UserInstitute::find($id);

            $delgroup->isValid = 1;
            $delgroup->save();
            $qual= User\Qulaification::find($delgroup->qualification_id);
            $qual->institute=$id;
            $qual->save();
            
            }
             return response()->json(['success' => true,'msg'=>$users], 200);
        } catch (Exception $ex) {
            return response()->json(['success' => false, 'msg' => $ex->getMessage()], 400);
        }
    }
    public function InstituteDelete() {
        try {
            $users = Input::get('userid');
            $delgroup = UserInstitute::destroy($users);
            if ($delgroup) {
                return response()->json(['success' => true], 200);
            }
        } catch (Exception $ex) {
            return response()->json(['success' => false, 'msg' => $ex->getMessage()], 400);
        }
    }
    public function InstituteDeleteAll(Request $request) {
        try {
            $users = $request['ids'];
            $users = explode(',',$users);
            foreach ($users as $id) {
                $delgroup = UserInstitute::destroy($id);
            }
             return response()->json(['success' => true,'msg'=>$users], 200);
        } catch (Exception $ex) {
            return response()->json(['success' => false, 'msg' => $ex->getMessage()], 400);
        }
    }
    /****end Institute validate***/
    
    /****Stream validate***/
    protected function set_stream() {
        $stream = User_Stream::all();
        return view('admin.setting.stream_setting', compact('stream'));
    }
    public function validateStream() {
        try {
            $users = Input::get('userid');
            $delgroup = User_Stream::find($users);
            if ($delgroup) {
                $addqual= QualificationList::insertGetId(['category' => $delgroup->category, 'qulaification' => $delgroup->qualification]);
                $user_area = Courses::find($delgroup->course_id);
                $user_area->stream = $addqual;
                $checker = $user_area->save();
                if ($checker) {
                    $delgroup->delete();
                    return response()->json(['success' => true], 200);
                }
            }
        } catch (Exception $ex) {
            return response()->json(['success' => false, 'msg' => $ex->getMessage()], 400);
        }
    }
        public function validateStreamAll(Request $request) {
        try {
            $users = $request['ids'];
            $users = explode(',', $users);
            foreach ($users as $id) {
                $delgroup = User_Stream::find($id);
                if ($delgroup) {
                    $addqual = QualificationList::insertGetId(['category' => $delgroup->category, 'qulaification' => $delgroup->qualification]);
                    $user_area = Courses::find($delgroup->course_id);
                    $user_area->stream = $addqual;
                    $checker = $user_area->save();
                    if ($checker) {
                        $delgroup->delete();
                    }
                }
            }
            return response()->json(['success' => true], 200);
        } catch (Exception $ex) {
            return response()->json(['success' => false, 'msg' => $ex->getMessage()], 400);
        }
    }
    public function Streamdelete() {
        try {
            $users = Input::get('userid');
            $delgroup =User_Stream::destroy($users);
            if ($delgroup) {
                return response()->json(['success' => true], 200);
            }
        } catch (Exception $ex) {
            return response()->json(['success' => false, 'msg' => $ex->getMessage()], 400);
        }
    }

    public function StreamdeleteAll(Request $request) {
         try {
            $users = $request['ids'];
            $users = explode(',',$users);
            foreach ($users as $id) {
                $delgroup = User_Stream::destroy($id);
            }
            if($delgroup){
                return response()->json(['success' => true], 200);
            }
        } catch (Exception $ex) {
            return response()->json(['success' => false, 'msg' => $ex->getMessage()], 400);
        }
    }
    

    /****end Stream validate***/
    
    
    /****campaign validate***/
    
    protected function create_camp() {
        return view('admin.campaign.create_campaign');
    }
    public function getSkillsCampaign() {
        $search = \Illuminate\Support\Facades\Input::get("query");
        $searchf = "%{$search}%";
        $query = \App\Models\User\AreaIntrest::where("area_intrest", "like", $searchf)->where("isValid", "=", 1)->get();
        if ($query) {
            foreach ($query as $flight) {                
                $data[] = array('value' => $flight->id, 'label' => $flight->area_intrest);
            }    //return json data
            echo json_encode($data);
        }
    }
    public function getSkillsquizCampaign() {
        $search = \Illuminate\Support\Facades\Input::get("query");
        $searchf = "%{$search}%";
        $query = \App\Models\Skill\SkillTestMain::where("skill_test_name", "like", $searchf)->where("publish", "=", 1)->get();
        if ($query) {
            foreach ($query as $flight) {
                $data[] = array('value' => Route("student.skillinstruction", ["skill-id" => $flight->id, "refrence" => "campaign"]), 'label' => $flight->skill_test_name);
            }    //return json data
            echo json_encode($data);
        }
    }
    public function savecampaign(Request $request) {
        try {
            $users = new Campaign();
            $users->campaign_name = $request["campaign_name"];
            $users->campaign_desc = $request["description"];
            $users->access_skill = $request["skillfires1"];
            $users->type_format = $request["e_type"];
            $users->email_subject = $request["em_sub"];
            $users->email_body = $request["emailbody"];
            if ($users->save()) {
                return redirect()->route("admin.manageCampaign")->with("status", "success")->with("message", "Campaign added");
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", "error occured");
        }
    }
    public function manageCampaign() {
        $campaign = Campaign::orderBy('created_at', 'desc')->get();
        return view("admin.campaign.manage", compact('campaign'));
    }
     public function deleteCampaign() {
            $skillid = Input::get("campaign-id");
        $skilltest = Campaign::destroy($skillid);
        return redirect()->back();
    }

    public function publishCampaign() {
        $skillid = Input::get("skillid");
        $campaign = Campaign::find($skillid);
        $status = $campaign->publish;
        if ($status == 0) {
            $access=$campaign->access_skill;
             $campaign->publish = 1;
            $campaign->save();
            echo 'Unpublish';
            if($access){
                $userarea= User_Area::where("area_intrests_id",$access)->get();
                foreach($userarea as $area){
                    $user= User::find($area->user_id);
                     try {
                         $user->notify(new \App\Notifications\Campaign($user->name, $campaign->email_subject, $campaign->email_body));
                    } catch (\Swift_TransportException $ex) {
                       return response()->json(['success' => false, 'errors' => "Server Down Try again later !!"], 400);
                    }
                }
            } else {
                try {
                    $users = User::where("activated", 1)->get();
                    foreach($users as $user) {
                        $user->notify(new \App\Notifications\Campaign($user->name, $campaign->email_subject, $campaign->email_body,$campaign->quiz_link));
                    }
                } catch (\Swift_TransportException $ex) {
                    return redirect()->back()->with("status", "danger")->with("message", "Server Down Try again later !!");
                }
            }
           
        } else {
            $campaign->publish = 0;
            $campaign->save();
            echo 'Publish';
        }
    }
    public function checkCampaign() {
        $skillid = Input::get("skill_id");
        $campaign = Campaign::find($skillid);
            $access=$campaign->access_skill;
            if($access){
                try {
                    $user=Auth::user();
                         $user->notify(new \App\Notifications\Campaign($user->name, $campaign->email_subject, $campaign->email_body, $campaign->quiz_link));
                         return redirect()->back()->with("status", "success")->with("message", "Check your login email");
                    } catch (\Swift_TransportException $ex) {
                       return redirect()->back()->with("status", "danger")->with("message", "Server Down Try again later !!");
                    }
            } else {
                try {
                    $user=Auth::user();
                    $user->notify(new \App\Notifications\Campaign($user->name, $campaign->email_subject, $campaign->email_body,$campaign->quiz_link));
                    return redirect()->back()->with("status", "success")->with("message", "Check your login email");
                } catch (\Swift_TransportException $ex) {
                    return redirect()->back()->with("status", "danger")->with("message", "Server Down Try again later !!");
                }
            }
    }
    public function editCampaign() {
        $campid= Input::get("campaign-id");
        $campaign= Campaign::find($campid);
        return view("admin.campaign.edit_campaign", compact("campaign"));
    }
    public function updateCampaign(Request $request) {
        $camp=$request["campid"];
        try{
            $campaign= Campaign::find($camp);
            $campaign->campaign_name = $request["campaign_name"];
            $campaign->campaign_desc = $request["description"];            
            $campaign->email_subject = $request["em_sub"];
            $campaign->email_body = $request["emailbody"];
            
            if ($campaign->save()) {
                return redirect()->route("admin.manageCampaign")->with("status", "success")->with("message", "Campaign Updated");
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", "error occured");
        }        
    }


    /****end campaign validate***/
    
    /*****Ad Block****/
    public function createAdblock() {
        return view("admin.adblock.add");
    }
    public function saveAdblock(Request $request) {
        try {
            $file = Input::file('add_image');
            echo $file;
            if (isset($file)) {
                $timestamp = str_replace([' ', ':'], '-', \Carbon\Carbon::now()->toDateTimeString());
                $name = $timestamp . '-' . $file->getClientOriginalName();
                $file->move(public_path() . '/Advertisement/', $name);
                $campaign = new \App\Models\Adblock();
                $campaign->ad_name = $request["add_name"];
                $campaign->ad_link = $request["add_link"];
                $campaign->ad_image = $name;
                if ($campaign->save()) {
                    return redirect()->back()->with("status", "success")->with("message", "Addblock Added");
                }
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", "error occured");
        }
    }
    public function manageADblock() {
        $campaign = \App\Models\Adblock::orderBy('created_at', 'desc')->get();
        return view("admin.adblock.manage", compact('campaign'));
    }
     public function deleteADblock() {
            $skillid = Input::get("campaign-id");
            $addblock= \App\Models\Adblock::find($skillid);
            \Illuminate\Support\Facades\File::delete("Advertisement/".$addblock->ad_image);
        $skilltest = $addblock->delete();
        return redirect()->back();
    }
    

    /*****end Ad Block****/
    
    
    
    
    public function s_delete() {
        try {
            $users = \Illuminate\Support\Facades\Input::get('userid');
            $delgroup = User::destroy($users);
            if ($delgroup) {
                return response()->json(['success' => true], 200);
            }
        } catch (Exception $ex) {
            return response()->json(['success' => false, 'msg' => $ex->getMessage()], 400);
        }
    }
    
    
    


    
  
    

}
