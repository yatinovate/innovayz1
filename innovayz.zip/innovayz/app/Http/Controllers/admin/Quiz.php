<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Event;
use App\Models\Skill\SkillTestMain;
use Auth;
use Illuminate\Support\Facades\Input;
use App\Models\Skill\MultiOptionSkill;
use App\Models\Skill\MultiChoice;
use App\Models\Skill\TrueFalseSkill;
use Illuminate\Support\Facades\Session;

class Quiz extends Controller {

    public function makeQuiz() {
        return view('admin.quiz.makequiz');
    }

    public function createview() {
        $qual = \App\Models\User\QualificationList::where('category', '')->get();
        return view('admin.quiz.quizcreate', compact("qual"));
    }

    public function postcreateview(Request $request) {
        try {
            $test = new SkillTestMain();
            $test->user_id = Auth::user()->id;
            $test->skill_test_name = $request['skill_name'];
            $test->category = $request['skill_cat'];
            $myString = $request->get('skill_sub1');
            $myArray = explode(',', $myString);
            $rowcount = count($myArray);
            for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                $bio = \App\Models\User\AreaIntrest::where('area_intrest', $myArray[$ix])->where('isValid', 1)->first();
                if ($bio) {
                    $test->subject = $bio->id;
                }
            }
            $test->description = $request['skill_desc'];
            $test->start_date = $request['skill_start_date'];
            $test->end_date = $request['skill_end_date'];
            $test->questn_count = $request['skill_qno'];
            $test->duration = $request['skill_time'];
            $test->save();
            return redirect()->route("admin.quizwizard", ["testid" => $test->id, "test-name" => $test->skill_test_name]);
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", "error occured try agaon later !!.");
        }
    }

    public function skillWizard() {
        $testid = Input::get("testid");
        $skilltest = SkillTestMain::find($testid);
        
        $totalq = $skilltest->questn_count;
        $progressq = $skilltest->qnoprocess;
        if ($progressq == $totalq) {
            return redirect()->route("admin.manage");
        } else {
            return view('admin.quiz.skillWizard', compact('skilltest'));
        }
    }

    public function qtype() {
         $questype = Input::get("qtype");
        $skillid = Input::get("skillid");
        if ($questype === 'mo') {
            return view('admin.quiz.include.multi_option', compact("skillid"));
        } else if ($questype === 'mcq') {
            return view('admin.quiz.include.multi_choice',compact("skillid"));
        } else if ($questype === 'tf') {
            return view('admin.quiz.include.true_false',compact("skillid"));
        }
    }

    public function getQuestionView($testid) {
        $qary1 = array();
        $qary = array();
        $sktest = \App\Model\Quiz\SkillTest::find($testid);
        for ($x = 1; $x <= $sktest->qnoprocess; $x++) {
            $qqq = \App\Model\Quiz\QCountInfo::where('skill_test_id', $sktest->id)->where('question_id', $x)->first();
            $qary[] = $qqq->actual_question_id;
            $qary1[] = $qqq->qtype;
        }

        return view('admin.quiz.include.questionUpdator', ['sktest' => $sktest, 'qary' => array_combine($qary, $qary1)]);
    }

    public function postMulti_option(Request $request) {
        try {
            $test = MultiOptionSkill::firstOrNew(array('id' => $request['ques_id']));
            $test->skill_tests_id = $request['skill_id'];
            $test->points = $request['points'];
            $test->question = $request['question'];
            $test->ans_a = $request['ans_a'];
            $test->ans_b = $request['ans_b'];
            $test->ans_c = $request['ans_c'];
            $test->ans_d = $request['ans_d'];
            $test->correct_ans = $request['correct_ans'];
            $checkr = $test->save();
            if ($checkr) {
                Event::fire(new \App\Events\SkillTester($request['skill_id'], $test->id, 'MultiOptionSkill'));
                return redirect()->back()->with("status", "success")->with("message", "Question added");
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", "error occured");
        }
    }

    public function postMulti_optionUpdate(Request $request) {
        try {
            $test = MultiOptionSkill::firstOrNew(array('id' => $request['quesid']));
            $test->skill_tests_id = $request['skill_id'];
            $test->points = $request['points'];
            $test->question = $request['question'];
            $test->ans_a = $request['ans_a'];
            $test->ans_b = $request['ans_b'];
            $test->ans_c = $request['ans_c'];
            $test->ans_d = $request['ans_d'];
            $test->correct_ans = $request['correct_ans'];
            $checkr = $test->save();
            if ($checkr) {
                return redirect()->back()->with("status", "success")->with("message", "Question Updated");
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", "error occured");
        }
    }

    public function postMulti_choice(Request $request) {
        try {
            $test = MultiChoice::firstOrNew(array('id' => $request['ques_id']));
            $test->skill_tests_id = $request['skill_id'];
            $test->points = $request['points'];
            $test->question = $request['question'];
            $test->ans_a = $request['ans_a'];
            $test->ans_b = $request['ans_b'];
            $test->ans_c = $request['ans_c'];
            $test->ans_d = $request['ans_d'];
            $test->correct_ans =trim($request['correct_ans'],",");
            $checkr = $test->save();
            if ($checkr) {
                Event::fire(new \App\Events\SkillTester($request['skill_id'], $test->id, 'MultiChoice'));
                return redirect()->back()->with("status", "success")->with("message", "Question added");
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", "error occured");
        }
    }

    public function postMulti_choiceUpdate(Request $request) {
        try {
            $test = MultiChoice::firstOrNew(array('id' => $request['quesid']));
            $test->skill_tests_id = $request['skill_id'];
            $test->points = $request['points'];
            $test->question = $request['question'];
            $test->ans_a = $request['ans_a'];
            $test->ans_b = $request['ans_b'];
            $test->ans_c = $request['ans_c'];
            $test->ans_d = $request['ans_d'];
            $test->correct_ans =trim($request['correct_ans'],",");
            $checkr = $test->save();
            if ($checkr) {
                return redirect()->back()->with("status", "success")->with("message", "Question Updated");
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", "error occured");
        }
    }

    public function postTrue_false(Request $request) {
        try {
            $test = TrueFalseSkill::firstOrNew(array('id' => $request['ques_id']));
            $test->skill_tests_id = $request['skill_id'];
            $test->points = $request['points'];
            $test->question = $request['question'];
            $test->correct_ans = $request['correct_ans'];
            $checkr = $test->save();
            if ($checkr) {
                Event::fire(new \App\Events\SkillTester($request['skill_id'], $test->id, 'TrueFalseSkill'));
                return redirect()->back()->with("status", "success")->with("message", "Question added");
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", "error occured");
        }
    }

    public function postTrue_falseUpdate(Request $request) {
        try {
            $test = TrueFalseSkill::firstOrNew(array('id' => $request['quesid']));
            $test->skill_tests_id = $request['skill_id'];
            $test->points = $request['points'];
            $test->question = $request['question'];
            $test->correct_ans = $request['correct_ans'];
            $checkr = $test->save();
            if ($checkr) {
                return redirect()->back()->with("status", "success")->with("message", "Question Updated");
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", "error occured");
        }
    }
    public function updateQuestion() {
        $qid = Input::get("qid");
        $skillid = Input::get("skillid");
        $question = \App\Models\Skill\QCountInfo::where("skill_tests_id", $skillid)->where("question_id", $qid)->first();
        if (!$question) {
            return response()->json(['success' => FALSE], 400);
        } else {
            $ques = $question->actual_question_id;
            $mycalss = 'App\\Models\\Skill\\' . $question->qtype;
            $upview = $this->updateviewGetter($question->qtype);
            $quesfinder = $mycalss::find($ques);
            return view('admin.quiz.include.' . $upview, compact("quesfinder"));
        }
    }

    public function updateviewGetter($param) {
        if ($param == 'MultiOptionSkill') {
            return 'multi_optionUpdate';
        } else if ($param == 'TrueFalseSkill') {
            return 'true_falseUpdate';
        } else if ($param == 'MultiChoice') {
            return 'multi_choiceUpdate';
        }
    }

    public function previewTest() {

        $quiz = SkillTestMain::find(Input::get("skill_id"));
        $question = \App\Models\Skill\QCountInfo::where('skill_tests_id', Input::get("skill_id"))->get();
        return view("admin.quiz.preview", ['quiz' => $quiz, 'qinfo' => $question]);
    }

    public function manage() {
        $skills = SkillTestMain::orderBy('created_at', 'desc')->get();
        return view("admin.quiz.manage", compact('skills'));
    }

    public function publish() {
        $skillid = Input::get("skillid");
        $skills = SkillTestMain::find($skillid);
        $status = $skills->publish;
        if ($status == 0) {
            $skills->publish = 1;
            $skills->save();
            echo 'Unpublish';
            $this->notifysubjectusers($skills);
        } else {
            $skills->publish = 0;
            $skills->save();
            echo 'Publish';
        }
    }
 public function notifysubjectusers($skills) { 
        $subject = $skills->subject;
        $users = \App\Models\User\User_Area::where("area_intrests_id", $subject)->get();
        foreach ($users as $user) {
            $muser = \App\Models\User::find($user->user_id);
            if ($muser->user_type == "students") {
                try{
                Event::fire(new \App\Events\NotifyUsers($user->user_id, 'A new Skill Test is created for you', 'A new Skill Test "' . $skills->skill_test_name . '" has been started of subject ' . $skills->area->area_intrest . ' from ' . $skills->start_date . ' to ' . $skills->end_date . ' for you. This would help you to analyze your in depth knowledge and your rank about where you lies in contest. ', Route("student.activeskill")));
                
                $muser->notify(new \App\Notifications\SkillNotify($user->name, $skills->skill_test_name,$skills->area->area_intrest,$skills->start_date,$skills->end_date));
                } catch (\Swift_TransportException $ex) {
                        return redirect()->back()->with("status", "danger")->with("message", "Server Down Try again later !!");
                    }
            }
        }
    }
    public function archive() {
        $skillid = Input::get("skillid");
        $skills = SkillTestMain::find($skillid);
        $status = $skills->archive;
        if ($status == 0) {
            $skills->archive = 1;
            $skills->save();
            echo 'Archive';
        } else {
            $skills->archive = 0;
            $skills->save();
            echo 'Unarchive';
        }
    }
    
    public function addQuestion(Request $request) {
        try {
            $test = SkillTestMain::find($request['skillidq']);
            $prevq = $test->questn_count;
            $test->questn_count = $prevq + $request['add_question'];
            $checkr = $test->save();
            if ($checkr) {
                return redirect()->route("admin.editQuestion", ["skillid" => $request['skillidq']]);
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", "error occured");
        }
    }
    public function editQuestion() {
        $skillid= Input::get("skillid");
        $skilltest = SkillTestMain::find($skillid);
        $question = \App\Models\Skill\QCountInfo::where('skill_tests_id', $skilltest)->get();

        return view("admin.quiz.updateskill", compact('skilltest'), compact('question'));
    }
        public function deleteTest() {
            $skillid = Input::get("skill-id");
        $skilltest = SkillTestMain::destroy($skillid);
        return redirect()->back();
    }

    public function post_upload(Request $request) {
        if ($request->ajax()) {
            try {
                $file = Input::file('upload_csv');
                $destinationPath = 'uploads';
                $extension = $file->getClientOriginalExtension();
                $fileName = 'uploadquiz' . rand(11111, 99999) . '.' . $extension; // renameing image
                $upload_success = $file->move($destinationPath, $fileName); // uploading file to given path
                if ($upload_success) {
                    Session::set('csvname', $fileName);
                    return response()->json(['success' => true], 200);
                } else {
                    return response()->json('error', 400);
                }
            } catch (Exception $e) {
                echo $e->getMessage();
            }
        }
    }

    public function createviewCSV() {
        $reader = \League\Csv\Reader::createFromPath('uploads/' . Session::get('csvname'));
        $results = $reader->setOffset(1)->fetchAll();
        $qcount = count($results);
        $qual = \App\Models\User\QualificationList::where('category', '')->get();
        return view('admin.quiz.uploadquizcreate', compact("qual"), compact("qcount"));
    }
    public function postcreateviewCSV(Request $request) {
        try {
            $test = new SkillTestMain();
            $test->user_id = Auth::user()->id;
            $test->skill_test_name = $request['skill_name'];
            $test->category = $request['skill_cat'];
            $myString = $request->get('skill_sub1');
            $myArray = explode(',', $myString);
            $rowcount = count($myArray);
            for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                $bio = \App\Models\User\AreaIntrest::where('area_intrest', $myArray[$ix])->where('isValid', 1)->first();
                if ($bio) {
                    $test->subject = $bio->id;
                }
            }
            $test->description = $request['skill_desc'];
            $test->start_date = $request['skill_start_date'];
            $test->end_date = $request['skill_end_date'];
            $test->questn_count = $request['skill_qno'];
            $test->duration = $request['skill_time'];
            if($test->save())
            {
                $csv = new \App\Models\Skill\UploadCsv();
                $csv->csvname = Session::get('csvname');
                $csv->isActive = 0;
                $csv->skill_tests_id = $test->id;
                if ($csv->save()) {
                    Event::fire(new \App\Events\CsvUploaded($test->id, $csv->id, 'UploadCsv'));                    
                    return redirect()->route("admin.editQuestion", ["skillid" =>$test->id]);
                } 
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("issues", "error occured try agaon later !!.");
        }
    }
}
