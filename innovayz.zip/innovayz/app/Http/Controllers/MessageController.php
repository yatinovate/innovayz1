<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Nahid\Talk\Facades\Talk;
use Auth;
use View;
use App\Models\User;

class MessageController extends Controller
{
    protected $authUser;
    
     public function __construct()
    {
        //$this->middleware('auth');
        //Talk::setAuthUserId(Auth::user()->id);

        View::composer('panels.user.profile.includes.peoplelist', function($view) {
            $threads = Talk::threads();
            $view->with(compact('threads'));
        });
    }
   /* public function __construct()
    {
        echo Auth::user()->id;
       // Talk::setAuthUserId(Auth::user()->id);

        /*View::composer('partials.peoplelist', function($view) {
            $threads = Talk::threads();
            $view->with(compact('threads'));
        });*/
   // }*/

    public function chatHistory($id)
    {
         Talk::setAuthUserId(Auth::user()->id);

        View::composer('panels.user.profile.includes.peoplelist', function($view) {
            $threads = Talk::threads();
            $view->with(compact('threads'));
        });
        $conversations = Talk::getMessagesByUserId($id);
        $user = '';
        $messages = [];
        if(!$conversations) {
            $user = User::find($id);
        } else {
            $user = $conversations->withUser;
            $messages = $conversations->messages;
        }

        return view('panels.user.profile.includes.conversations',['messages'=>$messages,'user'=>$user,"activeid"=>$id]);
    }

    public function ajaxSendMessage(Request $request)
    {
        if ($request->ajax()) {
            $rules = [
                'message-data'=>'required',
                '_id'=>'required'
            ];

            $this->validate($request, $rules);

            $body = $request->input('message-data');
            $userId = $request->input('_id');
             Talk::setAuthUserId(auth()->user()->id);
            if ($message = Talk::sendMessageByUserId($userId, $body)) {
                $html = view('panels.user.profile.includes.newMessage', compact('message'))->render();
                return response()->json(['status'=>'success', 'html'=>$html], 200);
            }
        }
    }

    public function ajaxDeleteMessage(Request $request, $id)
    {
        if ($request->ajax()) {
            if(Talk::deleteMessage($id)) {
                return response()->json(['status'=>'success'], 200);
            }

            return response()->json(['status'=>'errors', 'msg'=>'something went wrong'], 401);
        }
    }

    public function getallMessage() {
        Talk::setAuthUserId(Auth::user()->id);
        $threads = Talk::threads();
        return view('panels.user.profile.includes.allmessages',compact('threads'));
    }
}
