<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests;
use DB;
use URL;
use Illuminate\Support\Facades\File;
use App\Models\User;
use Illuminate\Support\Facades\Input;
use App\Models\Challenge\ChallengeTest;
use App\Models\Challenge\ResultChallenge;
use App\Models\Challenge\ActiveChallenge;
use App\Models\User\InviteUser;
use Illuminate\Support\Facades\Mail;

class DashboardController extends Controller {

    public function Dashboard() {
        $asdf = Auth::user()->user_area;
        $usercontact = \App\Models\User\Contact::where('user_id', '=', Auth::user()->id)->first();
        $elib = count(\Illuminate\Support\Facades\DB::table('laradrop_files')->where('user_id', Auth::user()->id)->whereNotIn('type', ['', 'folder'])->get());
        $userdata = new \App\Logic\Dashboard\UserData();
        $skillcount = $userdata->countskill();
        $chlcount = $userdata->countchall();
        $questncount = $userdata->countquestion();

        $stucount = $userdata->studentCount();
        $teachstucount = $userdata->teacherCount();
        $collstucount = $userdata->collegeCount();
        $suggested = $userdata->suugestedcooncetion();
        $postdat = \App\Models\Profile\PostKnowledgeUser::where('user_id', Auth::user()->id)->orderby("created_at", "desc")->get();
        return view('Dashboard.Dashboard', ['asdf' => $asdf, 'contact' => $usercontact, 'ecount' => $elib, 'skillcount' => $skillcount,
            'chlcount' => $chlcount, 'questncount' => $questncount, 'suggested' => $suggested, 'postdta' => $postdat,
            "stucount" => $stucount, "teachstucount" => $teachstucount, "collstucount" => $collstucount]);
    }

    public function getConnection() {
        $asdf = Auth::user()->user_area;
        $usercontact = \App\Models\User\Contact::where('user_id', '=', Auth::user()->id)->first();
        $elib = count(\Illuminate\Support\Facades\DB::table('laradrop_files')->where('user_id', Auth::user()->id)->whereNotIn('type', ['', 'folder'])->get());
        $userdata = new \App\Logic\Dashboard\UserData();
        $skillcount = $userdata->countskill();
        $chlcount = $userdata->countchall();
        $questncount = $userdata->countquestion();
        $stucount = $userdata->studentCount();
        $teachstucount = $userdata->teacherCount();
        $collstucount = $userdata->collegeCount();
        $suggested = $userdata->suugestedcooncetion();

        $users = \App\Models\Profile\Followers::where("followers_id", Auth::user()->id)->get();
        $utype = Input::get("utype");
        $userarray = array();
        foreach ($users as $us) {
            $folwer = User::find($us->user_id);
            if ($folwer->user_type == $utype) {
                $userarray[] = array('userid' => $folwer->id, 'user_name' => $folwer->name, 'avatar' => $folwer->avatar);
            }
        }
        
        $folloingarr = array();
        $followersusers = \App\Models\Profile\Followers::where("user_id", Auth::user()->id)->get();
        foreach ($followersusers as $us) {
            $folwer = User::find($us->followers_id);
            if ($folwer->user_type == $utype) {
                $folloingarr[] = array('userid' => $folwer->id, 'user_name' => $folwer->name, 'avatar' => $folwer->avatar);
            }
        }
        return view('Dashboard.Connections', ['asdf' => $asdf, 'contact' => $usercontact, 'ecount' => $elib, 'skillcount' => $skillcount, 'chlcount' => $chlcount, 'questncount' => $questncount,
            "stucount" => $stucount, "teachstucount" => $teachstucount, "collstucount" => $collstucount, 'con_type' => $utype,'folloingarr' => $folloingarr,  'userarray' => $userarray, 'suggested' => $suggested]);
    }

    public function update_avatar(Request $request) {
        if ($request->hasFile('avatar')) {
            $avatar = $request->file('avatar');
            $filename = time() . '.' . $avatar->getClientOriginalExtension();
            $folder = Auth::user()->name . '-' . rand(2, 1234);
            $path = 'userdata/' . $folder;
            //\Intervention\Image\Facades\Image::make($avatar)->resize(300, 300)->save( public_path('/user/avatars/' . $filename ) );

            $user = Auth::user();
            $user->avatar = $path . '/' . $filename;
            if ($user->save()) {
                if (!File::exists($path)) {
                    File::makeDirectory($path, 0777, true, true);
                }
                \Intervention\Image\Facades\Image::make($avatar)->resize(300, 300)->save(public_path($path . '/' . $filename));
            }
        }
        return redirect()->back();
    }

    public function matchTagShow() {
        $usertag = array();
        $user_area = Auth::user()->user_area;
        if (count($user_area) >= 1) {
            foreach ($user_area as $area) {
                $questiontag = \App\Models\Question\QTags::where("tagid", $area->area_int->id)->orderBy('created_at', 'DESC')->get();
                if ($questiontag) {
                    foreach ($questiontag as $tag) {
                        if ($tag->tag_quest->user_id != Auth::user()->id) {
                            $usertag[] = $tag->post_question_id;
                        }
                    }
                }
            }
        }
        return $usertag;
    }

    public function getQuetions() {
        $questid = array_unique($this->matchTagShow());
        rsort($questid);
        if (empty($questid)) {
            echo '<li  class="text-center" ><a><br>No questions found</a></li>';
        } else {
            $dataitems = sizeof($questid);
            $datacounter = 5;
            if ($dataitems <= 5) {
                $datacounter = $dataitems;
            }
            for ($ix = 0; $ix < $datacounter; $ix++) {
                $area1 = \App\Models\Question\PostQuestion::where('id', $questid[$ix])->orderBy('created_at', 'DESC')->first();
                if ($area1->user_id != Auth::user()->id) {
                    echo '<li><a href="' . Route('question.q_detail', ["q_code" => $area1->id, "q_detail" => $area1->question]) . '">
                                    <time datetime="' . $area1->created_at->format('d/m/Y') . '">
                                        <span class="day">' . $area1->created_at->format('d') . '</span>
                                        <span class="month">' . $area1->created_at->format('M') . '</span>                
                                    </time>
                                    <div class="info">
                                        <p class="desc">' . $area1->question . '</p>
                                    </div>
                            </a></li>';
                }
            }
        }
    }

    public function postInvite(Request $request) {
        try {
            $checkuser = User::where("email", $request["email"])->first();
            if ($request["email"] == Auth::user()->email) {
                return redirect()->back()->with('status', 'danger')->with('message', 'You cannot send invitation to yourself');
            } else if ($checkuser) {
                $user1 = User::find(Auth::user()->id);
                $user2 = $checkuser;
                $verify = \App\Models\Profile\Followers::where('user_id', $user1->id)->where('followers_id', $user2->id)->first();
                if ($verify) {
                    return redirect()->back()->with('status', 'warning')->with('message', 'Already in follower list');
                } else {
                    $user1->following()->save($user2);
                    try {
                        $user2->notify(new \App\Notifications\FollowerNotify($user2->name, $user1->name));
                    } catch (\Swift_TransportException $ex) {
                        return redirect()->back()->with("status", "danger")->with("message", "Server Down Try again later !!");
                    }
                    return redirect()->route("profile.index", ["user-id" => $user2->id, 'user-name' => $user2->name]);
                }
            } else {
                $invite = new InviteUser();
                $invite->user_id = Auth::user()->id;
                $invite->email = $request["email"];
                $invite->token = \Illuminate\Support\Facades\Hash::make($request["invitemail"]);
                if ($invite->save()) {
                    Mail::queue('vendor.notifications.invite', ['user' => $invite,"username"=>Auth::user()->name], function ($message) use($invite) {
                        $message->from('yatin.cse@gmail.com', Auth::user()->first_name);
                        $message->to($invite->email)->subject('InnoVayz :: Invitation to Connect on InnoVayz');
                    });
                    return redirect()->back()->with('status', 'success')->with('message', 'Invitation Sent');
                }
            }
        } catch (Exception $ex) {
            return redirect()->back()->with('status', 'danger')->with('message', 'Error Occured');
        }
    }

    public function getChallenge() {
        $challcount = count(\App\Models\Challenge\ChallengeTest::all());
        $totuser = count(\App\Models\Challenge\ActiveChallenge::all());
        return view('challenge.student.SkillView', ['challengecount' => $challcount, 'totaluser' => $totuser]);
    }

    public function getchallengeView() {
        $chckr = array();
        $user_area = Auth::user()->user_area;
        $dt = new \DateTime();
        if (count($user_area)) {
            foreach ($user_area as $area) {
                $areainta = $area->area_int;
                /* $questiontag = ChallengeTest::where("subject", $areainta->id)->where("publish", 1)->where("start_date", '<=', $dt->format('m/d/Y'))
                  ->where("end_date", '>=', $dt->format('m/d/Y'))->orderBy('created_at', 'DESC')->get(); */
                $questiontag = ChallengeTest::where("subject", $areainta->id)->where("publish", 1)
                                ->where("end_date", '>=', $dt->format('m/d/Y'))->orderBy('created_at', 'DESC')->get();
                $acta = "";
                $btntext = 'Start';
                foreach ($questiontag as $challenge) {
                    $checkgrpchall = \App\Models\Challenge\GroupChallenge::where("challenge_id", $challenge->id)->first();
                    if (!$checkgrpchall) {
                        $chckr[] = $challenge->id;
                        $asd = $this->checkActivate($challenge->id);
                        if ($asd == null) {
                            if ($challenge->start_date > $dt->format('m/d/Y')) {
                                $now = \Carbon\Carbon::now();
                                $length = \Carbon\Carbon::parse($challenge->start_date)->diffForHumans($now);
                                $btntext = 'Activate by ' . $length;
                                $acta = "disabled";
                            } else {
                                $btntext = 'Start';
                                $acta = "";
                            }
                        } else {
                            $btntext = $asd;
                            $acta = "disabled";
                        }
                        $high = ResultChallenge::where("challenge_id", $challenge->id)->max('points');
                        if (!$high) {
                            $high = 0;
                        }
                        $passuser = $this->challengePassCount($challenge->id);
                        // <h3>' . $challenge->skill_test_name . '&nbsp;(' . DB::table("qualificationlist")->where("category", $challenge->category)->first()->qulaification . ')</h3>                        
                        $totuser = count(ResultChallenge::where("challenge_id", $challenge->id)->get());
                        echo '<div class="col-md-6">
                    <div class="skill_card">
                        <h3>' . $challenge->skill_test_name . '</h3>                        
                        <small>' . $totuser . ' Students participated | ' . $passuser . ' students passed</small>
                        <p>Highest Score ' . $high . ' | <a href="' . Route("student.leaderbord", ["challenge-id" => $challenge->id, "challenge-name" => $challenge->skill_test_name]) . '" target="_blank">LeaderBoard</a></p>
                        <p>Start Date : ' . $challenge->start_date . ' | End Date : ' . $challenge->end_date . ' </p>
                            <p><a  href="' . Route("student.instruction", ["challenge-id" => $challenge->id, "challenge-name" => $challenge->skill_test_name]) . '" class="pull-right btn btn-primary ' . $acta . '">' . $btntext . '</a></p>
                        <div class="clearfix"></div>
                    </div>
                </div>';
                    }
                }
            }
        }
        if (empty($chckr)) {
            echo '<div class="norecord">
                        <div class="alert alert-info">
                            <h2>
                                No Challange for now in your Area of Interest. Once any challenge will be posted within your Area of Interest you
                                will be notified.
                            </h2>
                            <p>You can also add Area of Interests if have to increase the probability to get the challenge.</p>
                        </div>
                    </div>';
        }
    }

    public function checkActivate($param) {
        $activaTest = ActiveChallenge::where("user_id", Auth::user()->id)->where("challenge_id", $param)->get();
        if ($activaTest->count()) {
            foreach ($activaTest as $asd) {
                $btntext = 'Already applied';
                return $btntext;
            }
        } else {
            return '';
        }
    }

    public function challengePassCount($testid) {
        $userpasscount = 0;
        $test = ResultChallenge::where("challenge_id", $testid)->get();
        foreach ($test as $tester) {
            $tpoint = $tester->total_points;
            $upoint = $tester->points;
            $pass = 0.4 * $tpoint;
            if ($upoint >= $pass) {
                $userpasscount = $userpasscount + 1;
            }
        }
        return $userpasscount;
    }

}
