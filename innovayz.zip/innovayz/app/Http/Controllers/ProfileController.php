<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\File;
use Image;
use DB;
use Illuminate\Support\Facades\Input;
use App\Models\User;

class ProfileController extends Controller {

    public function verifyprofilesteps() {
        $usertype = Auth::user()->user_type;
        $status = Auth::user()->profile_status;
        if ($status == 'done') {
            return redirect()->route('Dashboard');
        }
        if ($usertype) {
            if ($usertype == 'students') {
                return redirect()->route('student.' . $status);
            } else if ($usertype == 'teachers') {
                return redirect()->route('teacher.' . $status);
            } else if ($usertype == 'colleges') {
                return redirect()->route('college.' . $status);
            }
        } else {
            return redirect()->route('socilaprofile');
        }
    }

    public function socilaprofile() {

        return view("panels.user.completeProfile.socilaprofile");
    }

    public function socilaprofileuser(Request $request) {
        $id = Auth::user()->id;
        $validatauser = User::where('id', $id)->update(['user_type' => $request["utype"]]);
        if ($validatauser) {
            return redirect()->route('verifyprofilesteps');
        } else {
            return redirect()->back()->with("status", "danger")->with("message", "Error Occureed");
        }
    }

    public function areaIntreset() {
        $search = \Illuminate\Support\Facades\Input::get("area_interest");
        $searchf = "%{$search}%";
        $query = \App\Models\User\AreaIntrest::where("area_intrest", "like", $searchf)->where("isValid", "=", 1)->get();
        if ($query) {
            foreach ($query as $flight) {
                $data[] = $flight->area_intrest;
            }    //return json data
            echo json_encode($data);
        }
    }
    
    public function deleteareaIntreset() {
        $search = \Illuminate\Support\Facades\Input::get("id");
        $query = \App\Models\User\User_Area::find($search);
        if ($query->delete()) {
            $area = \App\Models\User\User_Area::where("user_id", Auth::user()->id)->get();
            foreach ($area as $ar) {
                echo '<a data-id="' . $ar->id . '">' . $ar->area_int->area_intrest . '&nbsp;<i class="fa fa-close"></i></a>';
            }
        }
    }
     public function updateareaintrest() {
        $search = \Illuminate\Support\Facades\Input::get("area_interest");
        $searchf = "%{$search}%";
        $user_area = Auth::user()->user_area;
        $areainta=array();
        if (count($user_area)) {
            foreach ($user_area as $area) {
                $areainta[] = $area->area_int->id;
            }
        }
        $query = \App\Models\User\AreaIntrest::where("area_intrest", "like", $searchf)->where("isValid", "=", 1)->whereNotIn("id",$areainta)->get();
        if ($query) {
            foreach ($query as $flight) {
                $data[] = $flight->area_intrest;
            }    //return json data
            echo json_encode($data);
        }
    }

    public function getInstitute() {
        $keyword = '%' . Input::get('term') . '%';
        $query = \App\Models\User\UserInstitute::where("institute", "like", $keyword)->where("isValid", "=", 1)->get();
        $searchArray = array();
        foreach ($query as $flight) {
            array_push($searchArray, array('label' => $flight->institute, 'value' => $flight->institute, 'id' => $flight->id));
        }
        echo json_encode($searchArray);
    }

    public function getStream() {
        $qualificationid= Input::get("qualificationid");
        $qual = \App\Models\User\QualificationList::where("category", $qualificationid)->get();
        foreach ($qual as $list) {
            echo '<option value="' . $list->id . '">' . $list->qulaification . '</option>';
        }
    }
    
public function getCity() {
        $state= Input::get("areau");
        $searchcity= User\CityState::where("city_state",$state)->get();
        foreach ($searchcity as $list) {
            echo '<option value="' . $list->city_name . '">' . $list->city_name . '</option>';
        }
}
    public function saveContact(Request $request) {
        $bio = \App\Models\User\Contact::firstOrNew(array('user_id' => Auth::user()->id));
        $bio->user_id = Auth::user()->id;
        $bio->address = $request['address'];
        $bio->mobile = $request['mobile'];
        $bio->skype = $request['skype'];
        $bio->uddhear = $request['uddhear'];
        $bio->country = $request['country'];
        $bio->state = $request['state'];
        $bio->city = $request['city'];
        $bio->pncode = $request['pncode'];
        $bio->recieveudates = $request['recieveudates'];
        if ($bio->save()) {
            $user1 = Auth::user();
            $user1->profile_status = 'done';
            $user1->save();
            return redirect()->route("Dashboard");
        } else {
            return redirect()->back()->with('issues', 'Error occur while saving data ,try again later');
        }
    }

   

    public function updateprofile() {
        $usertype = Auth::user()->user_type;
        if ($usertype == 'students') {
            $dta = \App\Models\Profile\Student::where("user_id", Auth::user()->id)->first();
            if ($dta) {
                return redirect()->route("student.update1");
            } else {
                return redirect()->route("verifyprofilesteps");
            }
        } else if ($usertype == 'teachers') {
            $dta = \App\Models\Profile\Teacher::where("user_id", Auth::user()->id)->first();
            if ($dta) {
                return redirect()->route("teacher.update1");
            } else {
                return redirect()->route("verifyprofilesteps");
            }
        } else if ($usertype == 'colleges') {
            $dta = \App\Models\Profile\College::where("user_id", Auth::user()->id)->first();
            if ($dta) {
                return redirect()->route("college.update1");
            } else {
                return redirect()->route("verifyprofilesteps");
            }
        }
    }

    public function updatesaveContact(Request $request) {
        $bio = \App\Models\User\Contact::firstOrNew(array('user_id' => Auth::user()->id));
        $bio->address = $request['address'];
        $bio->mobile = $request['mobile'];
        $bio->skype = $request['skype'];
        $bio->uddhear = $request['uddhear'];
        $bio->country = $request['country'];
        $bio->state = $request['state'];
        $bio->city = $request['city'];
        $bio->pncode = $request['pncode'];
        $bio->recieveudates = $request['recieveudates'];
        if ($bio->save()) {
            return redirect()->Route("Dashboard");
        } else {
            return redirect()->back()->with('issues', 'Error occur while saving data ,try again later');
        }
    }

    public function questionarie($userid) {
        $user = User::find($userid);
        $qu = \App\Model\Question\PostQuestion::where("user_id", $userid)->get();
        echo '<h2>Questions</h2><br>';
        echo '<ul>';
        foreach ($qu as $qe) {
            echo '<li>' . $qe->question . '</li>';
        }
        echo '</ul>';
    }

    public function about($userid) {
        $user = User::find($userid);
        return view('profile.about', compact('user'));
    }


    public function das(Request $request) {
        $rowcount = count($request->get('area'));
        for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
            $bio = AreaIntrest::firstOrNew(array('area_intrest' => $request->get('area')[$ix]));
            $bio->area_intrest = $request->get('area')[$ix];
            $bio->save();
        }
    }

}
