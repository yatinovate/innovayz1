<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\PostKnowledge;
use App\Http\Requests;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use App\Models\Profile\PostKnowledgeUser;
use App\Models\User;

class PostController extends Controller {

    public function postknowledge(Request $request) {
        try {
            $id = Auth::user()->id;
            $bio = new \App\Models\Profile\PostKnowledge();
            $bio->user_id = $id;
            $bio->Subject = $request['subject'];
            $bio->Description = urlencode($request['poster']);
            if ($bio->save()) {
                $puser = new PostKnowledgeUser();
                $puser->user_id = $bio->user_id;
                $puser->post_id = $bio->id;
                $puser->save();
                $myString = rtrim($request->get('tagcon1'), ',');
                if (!$myString == null) {
                    $myArray = explode(',', $myString);
                    $rowcount = count($myArray);
                    $freinds = "";
                    if (!empty($myArray)) {
                        $bio->Taguser = 1;
                        $bio->save();
                        for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                            $frnd = new PostKnowledgeUser();
                            $frnd->user_id = $myArray[$ix];
                            $frnd->post_id = $bio->id;
                            $frnd->save();
                            $user = User::find($myArray[$ix]);                            
                            try {
                                $user->notify(new \App\Notifications\PostKnowldgeUser($user->name));
                            } catch (\Swift_TransportException $ex) {
                                return redirect()->back()->with("status", "danger")->with("message", "Server Down Try again later !!");
                            }
                        }
                    }
                }
                return redirect()->back();
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", "Server Down Try again later !!");
        }
    }

    public function postknowledgeattachement(Request $request) {
        try {
            $bio = new \App\Models\Profile\PostKnowledge();
            $bio->user_id = Auth::user()->id;
            $bio->Subject = $request['subject'];
            $bio->Description = $request['poster'];
            $bio->attachement = htmlentities($request['attachement']);
            $bio->attachement_id = $request['attachement_id'];
            if ($bio->save()) {
                $puser = new PostKnowledgeUser();
                $puser->user_id = $bio->user_id;
                $puser->post_id = $bio->id;
                $puser->save();
                $myString = rtrim($request->get('tagcon1'), ',');
                if (!$myString == null) {
                    $myArray = explode(',', $myString);
                    $rowcount = count($myArray);
                    $freinds = "";
                    if (!empty($myArray)) {
                        $bio->Taguser = 1;
                        $bio->save();
                        for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                            $frnd = new PostKnowledgeUser();
                            $frnd->user_id = $myArray[$ix];
                            $frnd->post_id = $bio->id;
                            $frnd->save();
                            $user = User::find($myArray[$ix]);
                            try {
                                $user->notify(new \App\Notifications\PostKnowldgeUser($user->name));
                                return redirect()->back();
                            } catch (\Swift_TransportException $ex) {
                                return redirect()->back()->with("status", "danger")->with("message", "Server Down Try again later !!");
                            }
                        }
                    }
                } return redirect()->back();
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", "Server Down Try again later !!");
        }
    }

}
