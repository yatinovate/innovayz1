<?php

namespace App\Http\Controllers\Quiz;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Skill\SkillTestMain;
use App\Models\Skill\QCountInfo;
use App\Models\Skill\SkillActive;
use Illuminate\Support\Facades\Auth;
use App\Models\Skill\ResultSkill;
use Illuminate\Support\Facades\Input;
use App\Models\User\QualificationList;

class SkillController extends Controller {

    public function getActiveSkill() {
        $challcount = count(SkillTestMain::where("publish", 1)->get());
        $totuser = count(SkillActive::all());
        return view('skilltest.SkillView', ['challengecount' => $challcount, 'totaluser' => $totuser]);
    }

    public function skillPassCount($testid) {
        $userpasscount = 0;
        $test = ResultSkill::where("skill_tests_id", $testid)->get();
        foreach ($test as $tester) {
            $tpoint = $tester->total_points;
            $upoint = $tester->points;
            $pass = 0.4 * $tpoint;
            if ($upoint >= $pass) {
                $userpasscount = $userpasscount + 1;
            }
        }
        return $userpasscount;
    }

    public function checkSkillActivate($param) {
        $activaTest = SkillActive::where("user_id", Auth::user()->id)->where("skill_tests_id", $param)->get();
        if ($activaTest->count()) {
            foreach ($activaTest as $asd) {
                $currenttime = \Carbon\Carbon::now();
                $currenttime->setTimezone('UTC');
                $totalDuration = $currenttime->diffInSeconds($asd->created_at);
                $totalD = round($totalDuration / 3600, 2);
                if ($totalD >= 24) {
                    SkillActive::destroy($asd->id);
                    return '';
                } else {
                    $btntext = 'Wait for 24 hrs';
                }
                return $btntext;
            }
        } else {
            return '';
        }
    }

    public function getActiveSkillGrid() {
        $chckr = array();
        $user_area = Auth::user()->user_area;
        $dt = new \DateTime();
        if (!$user_area->isEmpty()) {
            foreach ($user_area as $area) {
                $areainta = $area->area_int;
                $questiontag = SkillTestMain::where("subject", $areainta->id)->where("publish", 1)->where("start_date", '<=', $dt->format('m/d/Y'))
                                ->where("end_date", '>=', $dt->format('m/d/Y'))->orderBy('created_at', 'DESC')->get();
                $acta = "";
                $btntext = 'Start';
                foreach ($questiontag as $challenge) {
                    $chckr[] = $challenge->id;
                    $asd = $this->checkSkillActivate($challenge->id);
                    if ($asd == null) {
                        $btntext = 'Start';
                        $acta = "";
                    } else {
                        $btntext = $asd;
                        $acta = "disabled";
                    }
                    $high = ResultSkill::where("skill_tests_id", $challenge->id)->max('points');
                    if (!$high) {
                        $high = 0;
                    }
                    $passuser = $this->skillPassCount($challenge->id);
                    $subj = \App\Models\User\AreaIntrest::find($challenge->subject)->area_intrest;
                    $totuser = count(ResultSkill::where("skill_tests_id", $challenge->id)->get());
                    echo '<div class="col-md-6">
                    <div class="skill_card">
                        <h3>' . $challenge->skill_test_name . '</h3>                        
                        <small>' . $totuser . ' Students participated | ' . $passuser . ' students passed</small>
                        <p>Highest Score ' . $high . ' | <a href="' . Route("student.skillleaderbord", ["skill-id" => $challenge->id, "skill-name" => $challenge->skill_test_name]) . '" target="_blank">LeaderBoard</a></p>
                        
                            <p><a href="' . Route("student.skillinstruction", ["skill-id" => $challenge->id, "skill-name" => $challenge->skill_test_name]) . '" class="pull-right btn btn-primary ' . $acta . '">' . $btntext . '</a></p>
                        <div class="clearfix"></div>
                    </div>
                </div>';
                }
            }
        }
        if (empty($chckr)) {
            echo '<div class="norecord">
                        <div class="alert alert-info">
                            <h2>
                                No Skill Test for now in your Area of Interest. Once any Skill Test will be posted within your Area of Interest you
                                will be notified.
                            </h2>
                            <p>You can also add Area of Interests if have to increase the probability to get the challenge.</p>
                        </div>
                    </div>';
        }
    }

    public function showInstruction() {
        $skillid = Input::get("skill-id");
        $checkin = SkillActive::where("user_id", Auth::user()->id)->where("skill_tests_id", $skillid)->get();
        if (count($checkin)) {
            return redirect()->back()->with("status", "warning")->with("message", "Skill Test already taken");
        } else {
            $skill = SkillTestMain::find($skillid);
            $totalpoints = 0;
        for ($ix = 1; $ix <= $skill->questn_count; $ix++) {
            $questions = QCountInfo::where('skill_tests_id',$skill->id)->where('question_id', $ix)->first();
            if ($questions) {
                $mycalss = 'App\\Models\\Skill\\' . $questions->qtype;
                $asd = $mycalss::find($questions->actual_question_id);
                $question_point = $asd->points;
                $totalpoints = $totalpoints + $question_point;
            }
        }
            return view("skilltest.instruction", compact("skill"), compact("totalpoints"));
        }
    }

    public function index() {
        $skill_id = Input::get("skill-id");
        $quiz = SkillTestMain::find($skill_id);
        $dt = new \DateTime();
        if ($quiz->start_date > $dt->format('m/d/Y')) {
            return redirect()->route("ex.errorpage")->with("error", "Page you are looking for is not available for you");
        } else {
            $challenge_area = $quiz->subject;
            $user_area = \App\Models\User\User_Area::where("user_id", Auth::user()->id)->where("area_intrests_id", $challenge_area)->get();
            if (count($user_area)) {
                $question = QCountInfo::where('skill_tests_id', $skill_id)->get();
                $activetest = SkillActive::where('user_id', Auth::user()->id)->where("skill_tests_id", $skill_id)->first();
                if(!count($activetest)){
                    $activetest = SkillActive::firstOrNew(array('skill_tests_id' => $skill_id, 'user_id' => Auth::user()->id));
                $activetest->user_id = Auth::user()->id;
                $activetest->skill_tests_id = $skill_id;
                $activetest->reactive = 1440;
                    $activetest->activetime = ($quiz->duration) * 60;
                    $activetest->save();
                }
                return view("skilltest.skill", ['quiz' => $quiz, 'qinfo' => $question,"activetest"=>$activetest]);
            } else {
                return redirect()->route("ex.errorpage")->with("error", "Page you are looking for is not available for you");
            }
        }
    }

    public function submitQuiz(Request $request) {
        $skill = SkillTestMain::find($request['skillid']);
        $qcount = $skill->questn_count;
        $totalpoints = 0;
        $user_points = 0;
        $corectqno = 0;
        $incorectqno = 0;
        $atempqno = 0;
        for ($ix = 1; $ix <= $qcount; $ix++) {
            $questions = QCountInfo::where('skill_tests_id', $request['skillid'])->where('question_id', $ix)->first();
            if ($questions) {
                $mycalss = 'App\\Models\\Skill\\' . $questions->qtype;
                $asd = $mycalss::find($questions->actual_question_id);
                $act_ans = $asd->correct_ans;
                $question_point = $asd->points;
                $totalpoints = $totalpoints + $asd->points;
                $userans = $request['q' . $ix];
                if ($userans == '') {
                    $atempqno = $atempqno + 1;
                } else {
                    if ($questions->qtype == 'MultiChoice') {
                        $act_ans = trim($act_ans, ",");
                        $pieces = explode(",", $act_ans);
                        $pontcor= count($pieces);
                        $asd = 0;
                        foreach ($userans  as $color) {
                            if (in_array($color, $pieces)) {
                                $asd = $asd+1;
                            }else{
                                $asd = $asd-1;
                            }
                        }
                        if ($asd==$pontcor) {
                            $user_points = $user_points + $question_point;
                            $corectqno = $corectqno + 1;
                        } else {
                            $incorectqno = $incorectqno + 1;
                        }
                    } else {
                        if ($userans == $act_ans) {
                            $user_points = $user_points + $asd->points;
                            $corectqno = $corectqno + 1;
                        } else {
                            $incorectqno = $incorectqno + 1;
                        }
                    }
                }
            }
        }
          $resu = ResultSkill::firstOrNew(array('skill_tests_id' => $request['skillid'],'user_id' => Auth::user()->id));
          $resu->skill_tests_id = $request['skillid'];
          $resu->user_id = Auth::user()->id;
          $resu->points = $user_points;
          $resu->total_points = $totalpoints;
          $resu->save(); 
        $pass = 0.4 * $totalpoints;
        if ($user_points >= $pass) {
            if ($user_points == $totalpoints) {
                $usermsg = '<h2>Congratulations you have scored ' . $user_points . ' marks out of ' . $totalpoints . '. </h2><br>'
                        . '<p>You are a champ.</p>';
            } else {
                $usermsg = '<h2>Congratulations you have scored ' . $user_points . ' marks out of ' . $totalpoints . '. </h2><br>'
                        . '<p>There is still a scope to improve yourself.</p>';
            }
        } else {
            $usermsg = '<h2>Thanks for attempting the skill test. Unfortunately you could not suceed to score enough.</h2><br>'
                    . '<p>You have scored ' . $user_points . ' marks out of ' . $totalpoints . ', Study hard and take the challenge.</p>';
        }

        return view("skilltest.result", ['skill'=>$skill,'correctq' => $corectqno, 'incorectq' => $incorectqno, 'unatempt' => $qcount - $atempqno, 'totalq' => $qcount, 'tpoints' => $totalpoints, 'upoints' => $user_points, 'usermsg' => $usermsg]);
    }

    public function getleaderView() {
        $challenge_id = Input::get("skill-id");
        $chll = SkillTestMain::find($challenge_id);
        $lead = ResultSkill::where("skill_tests_id", $challenge_id)->orderBy('points', 'desc')->take(9)->get();
        return view("skilltest.leaderboard", ['chllangenamae' => $chll->skill_test_name, 'leader' => $lead]);
    }
    public function updatetime() {
        $challenge_activationid = Input::get("id");
        $time = Input::get("time");
        $chll = SkillActive::find($challenge_activationid);
        $chll->activetime = $time;
        $chll->save();
    }

}
