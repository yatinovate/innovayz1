<?php

namespace App\Http\Controllers\Question;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use URL;
use App\Http\Controllers\Controller;
use \Illuminate\Support\Facades\Input;
use App\Models\Question\PostQuestion;
use App\Models\Question\QTags;
use App\Models\Question\QnAnswers;
use Illuminate\Support\Facades\Event;
use App\Models\User;
use Log;

class QuestionController extends Controller {

    public function areaIntreset() {
        $search = \Illuminate\Support\Facades\Input::get("query");
        $searchf = "%{$search}%";
        $query = \App\Models\User\AreaIntrest::where("area_intrest", "like", $searchf)->where("isValid", "=", 1)->get();
        $userarray = array();
        foreach ($query as $flight) {
            $userarray[] = array('value' => $flight->id, 'label' => $flight->area_intrest);
        }
        echo json_encode($userarray);
    }

    public function post(Request $request) {
        try {
            $bio = new \App\Models\Question\PostQuestion();
            $bio->user_id = Auth::user()->id;
            $bio->question = $request['enter_question'];
            $bio->description = $request['qdescription'];
            if ($bio->save()) {
                $myString = rtrim($request->get('questiontags1'), ',');
                if (!$myString == null) {
                    $myArray = explode(',', $myString);
                    $rowcount = count($myArray);
                    for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                        $tagin = new \App\Models\Question\QTags();
                        $tagin->post_question_id = $bio->id;
                        $tagin->tagid = $myArray[$ix];
                        $tagin->save();
                    }
                }
            }
            $this->notifysubjectusers($bio);
            return redirect()->route("question.myquestion");
        } catch (Exception $ex) {
            
        }
    }

    public function notifysubjectusers($question) {
        foreach ($question->question_tags as $tag) {
            $areasearch = \App\Models\User\User_Area::where("area_intrests_id", $tag->tagid)->get();
            foreach ($areasearch as $araeu) {
                if ($araeu->user_id != $question->user_id) {
                    $user = User::find($araeu->user_id);
                    try {
                        Event::fire(new \App\Events\NotifyUsers($user->id, 'A new Question for you', 'A new Question "' . $question->question . '" has been posted', Route('question.q_detail', ["q_code" => $question->id, "q_detail" => $question->question])));
                        $user->notify(new \App\Notifications\QuestionNotify($user->name, $question->question, $question->id));
                    } catch (\Swift_TransportException $ex) {
                        return redirect()->back()->with("status", "danger")->with("message", "Server Down Try again later !!");
                    }
                }
            }
        }
    }

    public function questionlist() {
        $myquestion = \App\Models\Question\PostQuestion::where('user_id', '=', Auth::user()->id)->orderBy('created_at', 'desc')->get();
        return view("panels.user.Question.QuestionTab", ['userquestion' => $myquestion]);
    }

    public function QuestionTagSearch() {
        $questiontag = \App\Models\Question\QTags::where('tagid', Input::get("q_code"))->orderBy('created_at', 'DESC')->get();
        $searcht = \App\Models\User\AreaIntrest::find(Input::get("q_code"))->area_intrest;
        return view("panels.user.Question.QuestionTag", ['searchtag' => $searcht, 'questiontag' => $questiontag]);
    }

    public function QuestionDetail() {
        $question = \App\Models\Question\PostQuestion::where('id', '=', Input::get("q_code"))->first();
        $anslistcount = count(\App\Models\Question\QnAnswers::where('post_question_id', Input::get("q_code"))->get());
        return view("panels.user.Question.QuestionDetail", compact("question"), compact("anslistcount"));
    }

    public function answeredQuetions() {
        $user_area = Auth::user()->user_area;
        if (!$user_area->isEmpty()) {
            foreach ($user_area as $area) {
                $tagin = $area->area_int->id;
                $questiontag = QTags::where("tagid", $tagin)->orderBy('created_at', 'DESC')->get();
                if (!empty($questiontag)) {
                    foreach ($questiontag as $tag) {
                        if ($tag->tag_quest->hasanswer == 1) {
                            echo $this->templateQuestion($tag->tag_quest);
                        }
                    }
                } else {
                    echo 'No questions on area intrest';
                }
            }
        } else {
            echo 'user area no';
        }
    }

    public function unansweredQuetions() {
        $user_area = Auth::user()->user_area;
        if (!$user_area->isEmpty()) {
            foreach ($user_area as $area) {
                $tagin = $area->area_int->id;
                $questiontag = QTags::where("tagid", $tagin)->orderBy('created_at', 'DESC')->get();
                if (!empty($questiontag)) {
                    foreach ($questiontag as $tag) {
                        if ($tag->tag_quest->hasanswer == 0) {
                            echo $this->templateQuestion($tag->tag_quest);
                        }
                    }
                } else {
                    echo 'No questions on area intrest';
                }
            }
        } else {
            echo 'user area no';
        }
    }

    public function templateQuestion($question) {
        $tags = "";
        foreach ($question->question_tags as $area) {
            $tags .= '<li><a href="' . Route("question.qtagsearch", ["q_code" => $area->q_tags->id, "q_tag" => $area->q_tags->area_intrest,]) . '">' . $area->q_tags->area_intrest . '</a></li>';
        }
        $answers = "";
        $colclass = 'col-md-10';
        if ($question->hasanswer) {
            $colclass = 'col-md-8';
            $answers = '<div class="col-md-2">
                <a id="anscount" href="' . URL::route('question.q_detail', ["q_code" => $question->id, "q_detail" => $question->question]) . '#detailan">Answer <b>' . count($question->answers) . '</b></a>
            </div>';
        }
        $var = '<div class="panel panel-default my_panel">
    <div class="panel-heading ">
        <div class="row">
            <div class="col-md-10">
                <h2><a href="' . Route('question.q_detail', ["q_code" => $question->id, "q_detail" => $question->question]) . '">' . $question->question . '</a></h2>
            </div>
            <div class="col-md-2 text-right">
                <span>Date : ' . $question->created_at->format('d,M') . '</span>
            </div>
        </div>
    </div>
    <div class="panel-body">
        <div class="row">
            <div class="desc_block">
                <p><strong>Description : </strong>' . $question->description . '</p>
            </div>
            <b>By : <a href="' . Route("profile.index", ["user-id" => $question->user->id, 'user-name' => $question->user->name]) . '">' . $question->user->name . '</a></b>
        </div>
    </div>
    <div class="panel-footer">
        <div class="row">
            <div class="' . $colclass . '">
                <div class="tagcontainer">
                    <strong>Tags : </strong>
                    <ul>' . $tags . '</ul>
                </div>
            </div>' . $answers . '
            <div class="col-md-2 text-right">
                <button type="button" class="btn btn-info answermodal" data-toggle="modal" id="' . $question->id . '" data-target="#ansewerpop">Add Answer</button>
            </div>
        </div>
    </div>  
</div>';
        return $var;
    }

    public function viewPop() {
        $qution = PostQuestion::find(Input::get("qid"));
        return view('panels.user.Question.includes.Answerpopup', compact('qution'));
    }

    public function postAnswer(Request $request) {
        try {
            $bio = new QnAnswers();
            $bio->post_question_id = $request['qid'];
            $bio->user_id = Auth::user()->id;
            $bio->answer = $request['answer'];
            $bio->notify = isset($request['notify']) ? $request['notify'] : 0;
            if ($bio->save()) {
                $changeq = PostQuestion::find($request['qid']);
                if ($changeq->user_id != Auth::user()->id) {
                    $changeq->hasanswer = 1;
                    $changeq->save();
                    $user = \App\Models\User::find($changeq->user_id);
                    try {
                        $user->notify(new \App\Notifications\QPanel\NotifyAnswer($user->name, $changeq->description, $changeq->id, $changeq->question));
                        Event::fire(new \App\Events\NotifyUsers($user->id, 'You have a new answer', 'Dear user , You have a new answer to the question ' . $changeq->question, Route('question.q_detail', ["q_code" => $changeq->id, "q_detail" => $changeq->question])));
                        $qcount = QnAnswers::where("post_question_id", $bio->post_question_id)->where("user_id", "!=", $changeq->user_id)->get();
                        if (count($qcount) >= 2) {
                            $newusers = QnAnswers::where("post_question_id", $bio->post_question_id)->where("notify", 1)->where("user_id", "!=", $changeq->user_id)->where("user_id", "!=", Auth::user()->id)->get();
                            foreach ($newusers as $qn) {
                                $nuser = \App\Models\User::find($qn->user_id);
                                $nuser->notify(new \App\Notifications\QPanel\AnswerNotify($nuser->name, $changeq->description, $changeq->id, $changeq->question));
                            }
                        }
                        return redirect()->back();
                    } catch (\Swift_TransportException $ex) {
                        return redirect()->back()->with("status", "danger")->with("message", "Server Down Try again later !!");
                    }
                }
                return redirect()->back();
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", "Server Down Try again later !!");
        }
    }


    public function answeredQuestion() {
        $ansquestion = PostQuestion::where('hasanswer', '=', '1')->orderBy('created_at', 'desc')->get();
        return view("Question.AnsweredQuestion", compact('ansquestion'));
    }

    public function answerlist() {
        $questionid = Input::get("question-id");
        $ans = \App\Models\Question\QnAnswers::where('post_question_id', $questionid)->orderBy("created_at", 'desc')->get();
        if (count($ans) > 0) {
            return view('panels.user.Question.Answerslist', ["ans" => $ans, "questionid" => $questionid]);
        }
    }

    public function deleteAnswer() {
        $questionid = Input::get("question-id");
        $del = \App\Models\Question\QnAnswers::destroy($questionid);
        if ($del) {
            return redirect()->back();
        }
    }

    public function likeAnswer() {
        $qid = Input::get('qid');
        $qans = \App\Models\Question\LikeQ::firstOrNew(array('user_id' => Auth::user()->id, 'post_id' => $qid));
        $qans->user_id = Auth::user()->id;
        $qans->type = 'like';
        $qans->post_id = $qid;
        $qans->save();
        $ans = QnAnswers::find($qid);
        $likecount = \App\Models\Question\LikeQ::where("post_id", $qid)->get();
        $question = PostQuestion::find($ans->post_question_id);
        Event::fire(new \App\Events\NotifyUsers($ans->user_id, 'Your Answer got New Like', 'Dear user , ' . Auth::user()->name . ' Liked you ans', Route('question.q_detail', ["q_code" => $question->id, "q_detail" => $question->question])));
        echo count($likecount);
    }

    public function matchTagShow() {
        $usertag = array();
        $user_area = Auth::user()->user_area;
        if (count($user_area) >= 1) {
            foreach ($user_area as $area) {
                //$tagin = \App\Model\User\AreaIntrest::find($area->area_intrests_id)->id;
                $questiontag = \App\Models\Question\QTags::where("tagid", $area->area_int->id)->orderBy('created_at', 'DESC')->get();
                if ($questiontag) {
                    foreach ($questiontag as $tag) {
                        $usertag[] = $tag->post_question_id;
                    }
                }
            }
        }
        return $usertag;
    }

    public function getSuggestedQuetions() {
        $suugestq = Input::get("qid");
        $questid = array_unique($this->matchTagShow());
        rsort($questid);
        if (empty($questid)) {
            echo '<li  class="text-center" ><a><br>No questions found</a></li>';
        } else {
            $dataitems = sizeof($questid);
            $datacounter = 5;
            if ($dataitems <= 5) {
                $datacounter = $dataitems;
            }
            for ($ix = 0; $ix < $datacounter; $ix++) {
                if ($questid[$ix] != $suugestq) {
                    $area1 = \App\Models\Question\PostQuestion::where('id', $questid[$ix])->orderBy('created_at', 'DESC')->first();
                    if ($area1->user_id != Auth::user()->id) {
                        echo '<li><a href="' . Route('question.q_detail', ["q_code" => $area1->id, "q_detail" => $area1->question]) . '">
                                    <time datetime="' . $area1->created_at->format('d/m/Y') . '">
                                        <span class="day">' . $area1->created_at->format('d') . '</span>
                                        <span class="month">' . $area1->created_at->format('M') . '</span>                
                                    </time>
                                    <div class="info">
                                        <p class="desc">' . $area1->question . '</p>
                                    </div>
                            </a></li>';
                    }
                }
            }
        }
    }

}
