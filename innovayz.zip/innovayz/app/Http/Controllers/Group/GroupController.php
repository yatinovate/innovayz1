<?php

namespace App\Http\Controllers\Group;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;
use App\Models\Group\Group;
use App\Models\Group\GroupsUser;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Event;
class GroupController extends Controller {

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function getallGroup() {

        $asdf = Auth::user()->user_area;
        $usercontact = \App\Models\User\Contact::where('user_id', '=', Auth::user()->id)->first();
        $elib = count(\Illuminate\Support\Facades\DB::table('laradrop_files')->where('user_id', Auth::user()->id)->whereNotIn('type', ['', 'folder'])->get());
        $userdata = new \App\Logic\Dashboard\UserData();
        $skillcount = $userdata->countskill();
        $chlcount = $userdata->countchall();
        $questncount = $userdata->countquestion();
        $stucount = $userdata->studentCount();
        $teachstucount = $userdata->teacherCount();
        $collstucount = $userdata->collegeCount();
        $suggested = $userdata->suugestedcooncetion();

        $grp = GroupsUser::where("user_id", Auth::user()->id)->get();

        return view('group.all', ['asdf' => $asdf, 'contact' => $usercontact, 'ecount' => $elib, 'skillcount' => $skillcount, 'chlcount' => $chlcount, 'questncount' => $questncount, 
            "stucount"=>$stucount,"teachstucount"=>$teachstucount,"collstucount"=>$collstucount, 'userarray' => $grp, 'suggested' => $suggested]);
    }

    public function manageGroup() {
        $usercontact = \App\Models\User\Contact::where('user_id', '=', Auth::user()->id)->first();
        $elib = count(\Illuminate\Support\Facades\DB::table('laradrop_files')->where('user_id', Auth::user()->id)->whereNotIn('type', ['', 'folder'])->get());
        $userdata = new \App\Logic\Dashboard\UserData();
        $skillcount = $userdata->countskill();
        $chlcount = $userdata->countchall();
        $questncount = $userdata->countquestion();
        $stucount = $userdata->studentCount();
        $teachstucount = $userdata->teacherCount();
        $collstucount = $userdata->collegeCount();
        $suggested = $userdata->suugestedcooncetion();
        $grp= Group::where("user_id", Auth::user()->id)->get();
        //$grpn = GroupsUser::where("user_id", Auth::user()->id)->get();
        //return view("group.index",compact("groupid"));
        return view('group.manage', ['grploop' => $grp, 'contact' => $usercontact, 'ecount' => $elib, 'skillcount' => $skillcount, 'chlcount' => $chlcount, 'questncount' => $questncount,
            "stucount"=>$stucount,"teachstucount"=>$teachstucount,"collstucount"=>$collstucount, 'suggested' => $suggested]);
    }

    public function manageUpdateGroup(Request $request) {
        try {
            $grp = Group::find($request["group_id"]);
            $grp->group_name = $request["grp_nme"];
            $grp->save();
            return redirect()->back()->with("status", "success")->with("message", "Group name Updated !!");
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", 'Error occur while saving data ,try again later');
        }
    }

    public function manageDeleteGroup() {
        try {
            $grp = Group::find(\Illuminate\Support\Facades\Input::get("grpid"));
            $grp->delete();
            return redirect()->back()->with("status", "success")->with("message", "Group Deleted !!");
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", 'Error occur while saving data ,try again later');
        }
    }

    public function setArchived() {
        try {
            $grp = Group::find(\Illuminate\Support\Facades\Input::get("grpid"));
            $arch_status = $grp->archive;
            if ($arch_status) {
                $grp->archive = 0;
                $grp->save();
                return redirect()->back()->with("status", "success")->with("archivedstatus", "1")->with("message", "Group Unarchived !!");
            } else {
                $grp->archive = 1;
                $grp->save();
                return redirect()->back()->with("status", "success")->with("archivedstatus", "1")->with("message", "Group Archived !!");
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", 'Error occur while saving data ,try again later');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function saveGroup(Request $request) {
        try {
            $key = str_random(15);
            $valkey = Group::where("group_code", $key)->get();
            if (count($valkey)) {
                $key = str_random(15);
            }
            $grp = new Group();
            $grp->group_name = $request["group_name"];
            $grp->user_id = Auth::user()->id;
            $grp->group_code = $key;
            if ($grp->save()) {
                $myString = rtrim($request->get('group_persons'), ',');
                if (!$myString == null) {
                    $myArray = explode(',', $myString);
                    $myArray[] = Auth::user()->id;
                    $rowcount = count($myArray);
                    for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                        $grp_user = new GroupsUser();
                        $grp_user->group_id = $grp->id;
                        $grp_user->user_id = $myArray[$ix];
                        $grp_user->save();
                        if($myArray[$ix]!=Auth::user()->id){
                            Event::fire(new \App\Events\NotifyUsers($myArray[$ix], 'You are added in a group', 'Dear user you are added to the group "'.$grp->group_name.'"', Route("groups.index", ["group-id" => $grp->id, "group-name" => $grp->group_name])));
                        }
                        
                    }
                } else {
                    $grp_user = new GroupsUser();
                    $grp_user->group_id = $grp->id;
                    $grp_user->user_id = Auth::user()->id;
                    $grp_user->save();
                }
            }
            return redirect()->route("groups.index", ["group-id" => $grp->id, "group-name" => $grp->group_name]);
        } catch (Exception $ex) {
            return redirect()->back()->with('issues', 'Error occur while saving data ,try again later');
        }
    }

    public function getGroupView() {
        $groupid = Input::get("group-id");
        $usercontact = \App\Models\User\Contact::where('user_id', '=', Auth::user()->id)->first();
        $elib = count(\Illuminate\Support\Facades\DB::table('laradrop_files')->where('user_id', Auth::user()->id)->whereNotIn('type', ['', 'folder'])->get());
        $userdata = new \App\Logic\Dashboard\UserData();
        $skillcount = $userdata->countskill();
        $chlcount = $userdata->countchall();
        $questncount = $userdata->countquestion();


        $stucount = $userdata->studentCount();
        $teachstucount = $userdata->teacherCount();
        $collstucount = $userdata->collegeCount();
        $suggested = $userdata->suugestedcooncetion();
        $grp = Group::find($groupid);
        $checkuseringroup = GroupsUser::where("group_id", $groupid)->where("user_id", Auth::user()->id)->get();
        if (!count($checkuseringroup)) {
            return redirect()->route("Dashboard");
        }
        $userrequest = \App\Models\Group\UserRequest::where("group_id", $groupid)->get();
        return view('group.index', ['grp' => $grp, 'contact' => $usercontact, 'ecount' => $elib, 'skillcount' => $skillcount, 'chlcount' => $chlcount, 'questncount' => $questncount,
            "stucount"=>$stucount,"teachstucount"=>$teachstucount,"collstucount"=>$collstucount, 'suggested' => $suggested, "userrequest" => $userrequest]);
    }

    public function create() {
        return view("group.create");
    }

    public function getUser() {
        $search = \Illuminate\Support\Facades\Input::get("query");
        $searchf = "%{$search}%";
        $users = \App\Models\Profile\Followers::where("followers_id", Auth::user()->id)->get();
        $userarray = array();
        foreach ($users as $us) {
            $folwer = \App\Models\User::find($us->user_id);
            $userarray[] = array('value' => $folwer->id, 'label' => $folwer->name);
        }
        echo json_encode($userarray);
    }

    public function addgetUser() {
        $grpid = \Illuminate\Support\Facades\Input::get("grpid");
        $existuser = array();
        $grpuser = GroupsUser::where("group_id", $grpid)->get();
        foreach ($grpuser as $guser) {
            $existuser[] = $guser->user_id;
        }
        $users = \Illuminate\Support\Facades\DB::table("followers")->where("followers_id", Auth::user()->id)->whereNotIn('user_id', $existuser)->get();
        $userarray = array();
        foreach ($users as $us) {
            $folwer = \App\Models\User::find($us->user_id);
            $userarray[] = array('value' => $folwer->id, 'label' => $folwer->name);
        }
        echo json_encode($userarray);
    }

    public function saveChat(Request $request) {
        try {
            $chat = new \App\Models\Group\GroupChat();
            $chat->group_id = $request["group_id"];
            $chat->user_id = \Illuminate\Support\Facades\Auth::user()->id;
            $chat->subject = $request["g_subject"];
            $chat->comments = stripslashes($request['g_poster']);
            $chat->save();
        } catch (Exception $ex) {
            return redirect()->back()
                            ->with('status', 'error')
                            ->with('message', 'Error occur while saving data ,try again later');
        }
    }

    public function getChat($id) {
        $chat = \App\Models\Group\GroupChat::where("group_id", $id)->orderby("created_at", "desc")->get();
        if (count($chat)) {
            $data = "";
            foreach ($chat as $ch) {
                $data = $data . '<li class="left clearfix">
                    <div class="col-md-2">
                <span class="chat-img pull-left">
                    <img src="' . asset(\App\Models\User::find($ch->user_id)->avatar) . '" alt="User Avatar" class="img-circle" title="' . \App\Models\User::find($ch->user_id)->name . '" />
                 </span>
                 </div>
                 <div class="col-md-10">
                <div class="chat-body clearfix">
                    <h3>' . $ch->subject . '</h3>
                    <p>' . $ch->comments . '</p>
                        <div class="header">
                         <small class="pull-right"><span class="glyphicon glyphicon-time"></span>' . $ch->created_at->format("M d, y - H:i:s") . '</small>
                             <div class="clearfix"></div>
                    </div>
                </div>
                </div>
                </li>';
            }
            return response()->json(['success' => true, 'data' => $data]);
        } else {
            return response()->json(['success' => false, 'errors' => 'no record'], 400);
        }
    }

    public function deleteUser($id) {
        $grp_id = \Illuminate\Support\Facades\Input::get("grp_id");
        $grpchat = GroupsUser::where("group_id", $grp_id)->where("user_id", $id)->delete();
        if ($grpchat) {
            return redirect()->back();
        }
    }

    public function addUserGroup(Request $request) {
        try {
            $myString = rtrim($request->get('addgroup_persons'), ',');
            if (!$myString == null) {
                $myArray = explode(',', $myString);
                $rowcount = count($myArray);
                for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                    $grp_user = new GroupsUser();
                    $grp_user->group_id = $request['group_id'];
                    $grp_user->user_id = $myArray[$ix];
                    $grp_user->save();
                }
            }
            return redirect()->back()->with("status", "success")->with("message", "Member Added !!");
        } catch (Exception $ex) {
            return redirect()->back()
                            ->with('status', 'error')
                            ->with('message', 'Error occur while saving data ,try again later');
        }
    }

    public function joinGroup(Request $request) {
        try {
            $grp = Group::where("group_code", $request["group_code"])->first();
            if ($grp) {
                $guser= GroupsUser::where("group_id",$grp->id)->where("user_id",\Illuminate\Support\Facades\Auth::user()->id)->get();
                if(!count($guser)){
                    $userrequest = \App\Models\Group\UserRequest::firstOrNew(array('user_id' => Auth::user()->id, 'group_id' => $grp->id));
                $userrequest->user_id = Auth::user()->id;
                $userrequest->group_id = $grp->id;
                $userrequest->save();
                $grpowner = \App\Models\User::find($grp->user_id);
                try {
                    $grpowner->notify(new \App\Notifications\Group\OwnerNotify($grp->id, $grp->group_name, $grpowner->name));
                } catch (\Swift_TransportException $ex) {
                    return redirect()->back()
                                    ->with('status', 'danger')
                                    ->with('message', 'Server Down Try again later !!');
                }
                return redirect()->back()
                                ->with('status', 'success')
                                ->with('message', 'Request sent');
                }else{
                    return redirect()->back()->with('status', 'warning')->with('message', 'You are already in group');
                }
            } else {
                return redirect()->back()
                                ->with('status', 'danger')
                                ->with('message', 'NO group found');
            }
        } catch (Exception $ex) {
            return redirect()->back()
                            ->with('status', 'danger')
                            ->with('message', 'Error occur while saving data ,try again later');
        }
    }

    public function setJoinAccept() {
        try {
            $req1 = Input::get("request-id");
            $req= \App\Models\Group\UserRequest::find($req1);
            $guser = GroupsUser::firstOrNew(array('user_id' => $req->user_id,"group_id"=>$req->group_id));
            $usernotify= \App\Models\User::find($req->user_id);
            $grp= Group::find($req->group_id);
            $guser->group_id = $req->group_id;
            $guser->user_id = $req->user_id;
            if($guser->save()){
                $req->delete();
            }
            try {
                $usernotify->notify(new \App\Notifications\Group\UserNotify($grp->id, $grp->group_name, $usernotify->name));
            } catch (\Swift_TransportException $ex) {
                return redirect()->back()
                                ->with('status', 'danger')
                                ->with('message', 'Server Down Try again later !!');
            }
            return redirect()->back()
                            ->with('status', 'success')
                            ->with('message', 'User Added');
        } catch (Exception $ex) {
            return redirect()->back()
                            ->with('status', 'danger')
                            ->with('message', 'Error occur while saving data ,try again later');
        }
    }
    public function delteJoin() {
        try {
            $req1 = Input::get("request-id");
            $req= \App\Models\Group\UserRequest::find($req1);
            $usernotify= \App\Models\User::find($req->user_id);
            $req->delete();
            try {
                $usernotify->notify(new \App\Notifications\Group\DeleteNotify($usernotify->name));
            } catch (\Swift_TransportException $ex) {
                return redirect()->back()
                                ->with('status', 'danger')
                                ->with('message', 'Server Down Try again later !!');
            }
            return redirect()->back()
                            ->with('status', 'success')
                            ->with('message', 'User Request Deleted');
        } catch (Exception $ex) {
            return redirect()->back()
                            ->with('status', 'danger')
                            ->with('message', 'Error occur while saving data ,try again later');
        }
    }
    

}
