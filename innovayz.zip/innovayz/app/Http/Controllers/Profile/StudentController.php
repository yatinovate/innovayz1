<?php

namespace App\Http\Controllers\Profile;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use DB;
use App\Models\Profile\Student;

class StudentController extends Controller {

    public function step1view() {
        $status = Auth::user()->profile_status;
        if ($status == 'step1') {
            return view('panels.user.completeProfile.student.Step1Student');
        }else{
            return redirect()->route('verifyprofilesteps');
        } 
    }
    public function step1(Request $request) {
        try {
            $user = Student::firstOrNew(array('user_id' => Auth::user()->id));
            $user->user_id = Auth::user()->id;
            $user->gender = $request['gender'];
            $user->dob = $request['profile_dob'];
            $user->describe_yourself = $request['desc_yourself'];
            if ($user->save()) {
                $myString = $request->get('area_interest1');
                $myArray = explode(',', $myString);
                $rowcount = count($myArray);
                for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                    $bio = \App\Models\User\AreaIntrest::where('area_intrest', $myArray[$ix])->where('isValid', 1)->first();
                    if ($bio) {
                        $user_area =\App\Models\User\User_Area::firstOrNew(array('user_id' => Auth::user()->id,"area_intrests_id"=>$bio->id));
                        $user_area->user_id = Auth::user()->id;
                        $user_area->area_intrests_id = $bio->id;
                        $checker = $user_area->save();
                    } else {
                        $area = new \App\Models\User\AreaIntrest();
                        $area->user_id = Auth::user()->id;
                        $area->area_intrest = $request->get('area_interest')[$ix];
                        $checker = $area->save();
                    }
                }
                $user1 = Auth::user();
                $user1->profile_status = 'step2';
                $user1->save();
                return redirect()->route('verifyprofilesteps');
            }
        } catch (Exception $ex) {
            return redirect()->back()->with('issues', 'Error occur while saving data ,try again later');
        }
    }

    public function step2view() {
        $status = Auth::user()->profile_status;
        if ($status == 'step2') {
            $qlist = \App\Models\User\QualificationList::where("category"," ")->get();
        return view('panels.user.completeProfile.student.Step2Student', compact("qlist"));
        } else {
            return redirect()->route('verifyprofilesteps');
        }
    }

    public function step2(Request $request) {
        try {
            $rowcount = sizeof($request['study_place']);
            for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                $institute_id = $request->get('institute1')[$ix];
                $institute_name = $request->get('institute')[$ix];
                $bio = new \App\Models\User\Qulaification();
                $bio->user_id = Auth::user()->id;
                $bio->study_place = $request->get('study_place')[$ix];
                $bio->qualification = $request->get('qualification')[$ix];
                $bio->stream = $request->get('stream')[$ix];
                $bio->institute = $institute_id;
                if ($bio->save()) {
                    if ($institute_id == null) {
                        $area = new \App\Models\User\UserInstitute();
                        $area->user_id = Auth::user()->id;
                        $area->institute = $institute_name;
                        $area->qualification_id = $bio->id;
                        $area->save();
                    }
                }
            }
            $user1 = Auth::user();
            $user1->profile_status = 'step3';
            $user1->save();
            return redirect()->route('verifyprofilesteps');
        } catch (Exception $ex) {
            return redirect()->back()->with('issues', 'Error occur while saving data ,try again later');
        }
    }

    public function step3view() {
         $status = Auth::user()->profile_status;
        if ($status == 'step3') {
            return view('panels.user.completeProfile.student.Step3Student');
        } else {
            return redirect()->route('verifyprofilesteps');
        }
        
    }

    /*     * **Update Method** */
    public function updatestepView1() {
        $dta = \App\Models\Profile\Student::where("user_id", Auth::user()->id)->first();
        $area = \App\Models\User\User_Area::where("user_id", Auth::user()->id)->get();
        return view('panels.user.updateprofile.student.Step1Student', compact("dta"), compact("area"));
    }

    public function updatestep1(Request $request) {
        $user = Student::firstOrNew(array('user_id' => Auth::user()->id));
        $user->gender = $request['gender'];
        $user->dob = $request['profile_dob'];
        $user->describe_yourself = $request['desc_yourself'];
        if ($user->save()) {
            $myString = $request->get('area_interest1');
            if($myString!=""){
            $myArray = explode(',', $myString);
            $rowcount = count($myArray);
            if ($rowcount >= 1) {
                for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                    $bio = \App\Models\User\AreaIntrest::where('area_intrest', $myArray[$ix])->where('isValid', 1)->first();
                    if ($bio) {
                        $user_area =\App\Models\User\User_Area::firstOrNew(array('user_id' => Auth::user()->id,"area_intrests_id"=>$bio->id));
                        $user_area->user_id = Auth::user()->id;
                        $user_area->area_intrests_id = $bio->id;
                        $checker = $user_area->save();
                    } else {
                        $area = new \App\Models\User\AreaIntrest();
                        $area->user_id = Auth::user()->id;
                        $area->area_intrest = $request->get('area_interest')[$ix];
                        $checker = $area->save();
                    }
                }
            }
            }
            return redirect()->route("student.update2");
        } else {
            return redirect()->back()->with('issues', 'Error occur while saving data ,try again later');
        }
    }

    public function updatestepView2() {
        $qlist = \App\Models\User\QualificationList::where("category"," ")->get();
        $qual = \App\Models\User\Qulaification::where("user_id", \Illuminate\Support\Facades\Auth::user()->id)->get();
        if (!count($qual) < 1) {
            return view('panels.user.updateprofile.student.Step2Student', compact("qual"), compact("qlist"));
        } else {
            return redirect()->route("verifyprofilesteps");
        }
    }

    public function updatestep2(Request $request) {
        try {
            $rowcount = sizeof($request['study_place']);
            for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                $course_id = isset($request->get('course_id')[$ix]) ? $request->get('course_id')[$ix] : '';
                if (!$course_id == "") {
                    $institute_id = $request->get('institute1')[$ix];
                    $institute_name = $request->get('institute')[$ix];
                    $bio = \App\Models\User\Qulaification::find($course_id);
                    $bio->study_place = $request->get('study_place')[$ix];
                    $bio->qualification = $request->get('qualification')[$ix];
                    $bio->stream = $request->get('stream')[$ix];
                    $bio->institute = $institute_id;
                    if ($bio->save()) {
                        if ($institute_id == null) {
                            $area = new \App\Models\User\UserInstitute();
                            $area->user_id = Auth::user()->id;
                            $area->institute = $institute_name;
                            $area->qualification_id = $bio->id;
                            $area->save();
                        }
                    }
                }
            }

            return redirect()->route("student.update3");
        } catch (Exception $ex) {
            return redirect()->back()->with('issues', 'Error occur while saving data ,try again later');
        }
    }

    public function addnewstep2() {
        $qlist = \App\Models\User\QualificationList::where("category"," ")->get();
        return view('panels.user.updateprofile.student.Step2Studentadd', compact("qlist"));
    }

    public function saveaddnewstep2(Request $request) {
        try {
            $rowcount = sizeof($request['study_place']);
            for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                $institute_id = $request->get('institute1')[$ix];
                $institute_name = $request->get('institute')[$ix];
                $bio = new \App\Models\User\Qulaification();
                $bio->user_id = Auth::user()->id;
                $bio->study_place = $request->get('study_place')[$ix];
                $bio->qualification = $request->get('qualification')[$ix];
                $bio->stream = $request->get('stream')[$ix];
                $bio->institute = $institute_id;
                if ($bio->save()) {
                    if ($institute_id == null) {
                        $area = new \App\Models\User\UserInstitute();
                        $area->user_id = Auth::user()->id;
                        $area->institute = $institute_name;
                        $area->qualification_id = $bio->id;
                        $area->save();
                    }
                }
            }
            return redirect()->route("student.update3");
        } catch (Exception $ex) {
            return redirect()->back()->with('issues', 'Error occur while saving data ,try again later');
        }
    }

    public function updatestep3View() {
        $data = \App\Models\User\Contact::where("user_id", \Illuminate\Support\Facades\Auth::user()->id)->first();
        if ($data) {
            return view('panels.user.updateprofile.student.Step3Student', compact("data"));
        } else {
            return redirect()->route("verifyprofilesteps");
        }
    }

}
