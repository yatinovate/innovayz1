<?php

namespace App\Http\Controllers\Profile;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;
use Validator;
use DB;
use Illuminate\Support\Facades\Input;
use App\Models\Profile\Teacher;

class TeacherController extends Controller {

    public function step1view() {
        $status = Auth::user()->profile_status;
        if ($status == 'step1') {
            return view('panels.user.completeProfile.teacher.Step1Teacher');
        }else{
            return redirect()->route('verifyprofilesteps');
        }  
    }

    public function step1(Request $request) {
        try {
            $user = Teacher::firstOrNew(array('user_id' => Auth::user()->id));
            $user->user_id = Auth::user()->id;
            $user->gender = $request['gender'];
            $user->dob = $request['profile_dob'];
            $user->describe_yourself = $request['desc_yourself'];
            if ($user->save()) {
                $myString = $request->get('area_interest1');
                $myArray = explode(',', $myString);
                $rowcount = count($myArray);
                for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                    $bio = \App\Models\User\AreaIntrest::where('area_intrest', $myArray[$ix])->where('isValid', 1)->first();
                    if ($bio) {
                        $user_area =\App\Models\User\User_Area::firstOrNew(array('user_id' => Auth::user()->id,"area_intrests_id"=>$bio->id));
                        $user_area->user_id = Auth::user()->id;
                        $user_area->area_intrests_id = $bio->id;
                        $checker = $user_area->save();
                    } else {
                        $area = new \App\Models\User\AreaIntrest();
                        $area->user_id = Auth::user()->id;
                        $area->area_intrest = $request->get('area_interest')[$ix];
                        $checker = $area->save();
                    }
                }
                $user1 = Auth::user();
                $user1->profile_status = 'step2';
                $user1->save();
                return redirect()->route('verifyprofilesteps');
            }
        } catch (Exception $ex) {
            return redirect()->back()->with('issues', 'Error occur while saving data ,try again later');
        }
    }

    public function step2view() {
        $status = Auth::user()->profile_status;
        if ($status == 'step2') {
            $qlist = \App\Models\User\QualificationList::where("category", " ")->get();
            return view('panels.user.completeProfile.teacher.Step2Teacher', compact("qlist"));
        } else {
            return redirect()->route('verifyprofilesteps');
        }
    }

    public function step2(Request $request) {
        try {
            $rowcount = sizeof($request['study_place']);
            for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                $institute_id = $request->get('institute1')[$ix];
                $institute_name = $request->get('institute')[$ix];
                $bio = new \App\Models\User\Qulaification();
                $bio->user_id = Auth::user()->id;
                $bio->study_place = $request->get('study_place')[$ix];
                $bio->qualification = $request->get('qualification')[$ix];
                $bio->stream = $request->get('stream')[$ix];
                $bio->institute = $institute_id;
                if ($bio->save()) {
                    if ($institute_id == null) {
                        $area = new \App\Models\User\UserInstitute();
                        $area->user_id = Auth::user()->id;
                        $area->institute = $institute_name;
                        $area->qualification_id = $bio->id;
                        $area->save();
                    }
                }
            }
            $user1 = Auth::user();
            $user1->profile_status = 'step3';
            $user1->save();
            return redirect()->route('verifyprofilesteps');
        } catch (Exception $ex) {
            return redirect()->back()->with('issues', 'Error occur while saving data ,try again later');
        }
    }

    public function step3view() {
        $status = Auth::user()->profile_status;
        if ($status == 'step3') {
            $areaint = \App\Models\User\AreaIntrest::where("isValid", "=", 1)->get();
        $qlist = \App\Models\User\QualificationList::where("category"," ")->get();
        return view('panels.user.completeProfile.teacher.Step3Teacher', compact("qlist"), compact("areaint"));
        } else {
            return redirect()->route('verifyprofilesteps');
        }
    }

    public function step3(Request $request) {
        try {
            $validatauser = Teacher::where("user_id", Auth::user()->id)->update(['grades' => $request["select_grades"],
                'experience' => $request["select_experience"], 'current_Organization' => $request["currentorg"], 'Previous_Organization' => $request["preorg"]]);
            if ($validatauser) {
                $rowcount = count($request->get('select_subject'));
                for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                    $subject_id = $request->get('select_subject')[$ix];
                    $bio = new \App\Models\User\Teacherskils();
                    $bio->user_id = Auth::user()->id;
                    $bio->Subject = $subject_id;
                    $bio->Category = $request->get('select_category')[$ix];
                    $bio->save();
                }
                $user1 = Auth::user();
                $user1->profile_status = 'step4';
                $user1->save();
                return redirect()->route('verifyprofilesteps');
            }
        } catch (Exception $ex) {
            return redirect()->back()->with('issues', 'Error occur while saving data ,try again later');
        }
    }

    public function step4view() {
         $status = Auth::user()->profile_status;
        if ($status == 'step4') {
            return view('panels.user.completeProfile.teacher.Step4Teacher');
        } else {
            return redirect()->route('verifyprofilesteps');
        }
    }


    /*     * **Update Method** */
    public function updatestepView1() {
        $dta = \App\Models\Profile\Teacher::where("user_id", Auth::user()->id)->first();
        $area = \App\Models\User\User_Area::where("user_id", Auth::user()->id)->get();
        return view('panels.user.updateprofile.teacher.Step1Teacher', compact("dta"), compact("area"));
    }
    
    public function updatestep1(Request $request) {
        $user = Teacher::firstOrNew(array('user_id' => Auth::user()->id));
        $user->gender = $request['gender'];
        $user->dob = $request['profile_dob'];
        $user->describe_yourself = $request['desc_yourself'];
        if ($user->save()) {
            $myString = $request->get('area_interest1');
            if($myString!=""){
            $myArray = explode(',', $myString);
            $rowcount = count($myArray);
            if ($rowcount >= 1) {
                for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                    $bio = \App\Models\User\AreaIntrest::where('area_intrest', $myArray[$ix])->where('isValid', 1)->first();
                    if ($bio) {
                        $user_area =\App\Models\User\User_Area::firstOrNew(array('user_id' => Auth::user()->id,"area_intrests_id"=>$bio->id));
                        $user_area->user_id = Auth::user()->id;
                        $user_area->area_intrests_id = $bio->id;
                        $checker = $user_area->save();
                    } else {
                        $area = new \App\Models\User\AreaIntrest();
                        $area->user_id = Auth::user()->id;
                        $area->area_intrest = $request->get('area_interest')[$ix];
                        $checker = $area->save();
                    }
                }
            }
            }
            return redirect()->route("teacher.update2");
        } else {
            return redirect()->back()->with('issues', 'Error occur while saving data ,try again later');
        }
    }
    
    public function updatestepView2() {
        $qlist = \App\Models\User\QualificationList::where("category"," ")->get();
        $qual = \App\Models\User\Qulaification::where("user_id", \Illuminate\Support\Facades\Auth::user()->id)->get();
        if (!count($qual) < 1) {
            return view('panels.user.updateprofile.teacher.Step2Teacher', compact("qual"), compact("qlist"));
        } else {
            return redirect()->route("verifyprofilesteps");
        }
    }

    public function updatestep2(Request $request) {
        try {
            $rowcount = sizeof($request['study_place']);
            for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                $course_id = isset($request->get('course_id')[$ix]) ? $request->get('course_id')[$ix] : '';
                if (!$course_id == "") {
                    $institute_id = $request->get('institute1')[$ix];
                    $institute_name = $request->get('institute')[$ix];
                    $bio = \App\Models\User\Qulaification::find($course_id);
                    $bio->study_place = $request->get('study_place')[$ix];
                    $bio->qualification = $request->get('qualification')[$ix];
                    $bio->stream = $request->get('stream')[$ix];
                    $bio->institute = $institute_id;
                    if ($bio->save()) {
                        if ($institute_id == null) {
                            $area = new \App\Models\User\UserInstitute();
                            $area->user_id = Auth::user()->id;
                            $area->institute = $institute_name;
                            $area->qualification_id = $bio->id;
                            $area->save();
                        }
                    }
                }
            }
            return redirect()->route("teacher.update3");
        } catch (Exception $ex) {
            return redirect()->back()->with('issues', 'Error occur while saving data ,try again later');
        }
    }
    public function addnewstep2() {
        $qlist = \App\Models\User\QualificationList::where("category"," ")->get();
        return view('panels.user.updateprofile.teacher.Step2Teacheradd', compact("qlist"));
    }
    public function saveaddnewstep2(Request $request) {
        try {
            $rowcount = sizeof($request['study_place']);
            for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                $institute_id = $request->get('institute1')[$ix];
                $institute_name = $request->get('institute')[$ix];
                $bio = new \App\Models\User\Qulaification();
                $bio->user_id = Auth::user()->id;
                $bio->study_place = $request->get('study_place')[$ix];
                $bio->qualification = $request->get('qualification')[$ix];
                $bio->stream = $request->get('stream')[$ix];
                $bio->institute = $institute_id;
                if ($bio->save()) {
                    if ($institute_id == null) {
                        $area = new \App\Models\User\UserInstitute();
                        $area->user_id = Auth::user()->id;
                        $area->institute = $institute_name;
                        $area->qualification_id = $bio->id;
                        $area->save();
                    }
                }
            }
            return redirect()->route("teacher.update3");
        } catch (Exception $ex) {
            return redirect()->back()->with('issues', 'Error occur while saving data ,try again later');
        }
    }

    public function updatestepView3() {
        $dta = Teacher::where("user_id", Auth::user()->id)->first();
        if ($dta) {
            $areaint = \App\Models\User\AreaIntrest::where("isValid", "=", 1)->get();
            $qlist = \App\Models\User\QualificationList::where("category"," ")->get();
            $skilss= \App\Models\User\Teacherskils::where("user_id", \Illuminate\Support\Facades\Auth::user()->id)->get();
            return view('panels.user.updateprofile.teacher.Step3Teacher',['dta'=>$dta,'qlist'=>$qlist,'areaint'=>$areaint,'skilss'=>$skilss] );
        } else {
            return redirect()->route("verifyprofilesteps");
        }
    }
    
     public function saveupdatestepView3(Request $request) {
        try {
            $validatauser = Teacher::where("user_id", Auth::user()->id)->update(['grades' => $request["select_grades"],
                'experience' => $request["select_experience"], 'current_Organization' => $request["currentorg"], 'Previous_Organization' => $request["preorg"]]);
            if ($validatauser) {
                $rowcount = count($request->get('select_subject'));
                    for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                $course_id = isset($request->get('course_id')[$ix]) ? $request->get('course_id')[$ix] : '';
                if (!$course_id == "") {
                    
                        $subject_id = $request->get('select_subject')[$ix];
                        $bio = \App\Models\User\Teacherskils::find($course_id);
                        $bio->Subject = $subject_id;
                        $bio->Category = $request->get('select_category')[$ix];
                        $bio->save();
                    }
                }
            }
            return redirect()->route("teacher.update4");
        } catch (Exception $ex) {
            return redirect()->back()->with('issues', 'Error occur while saving data ,try again later');
        }
    }

    public function updatestep4View() {
        $data = \App\Models\User\Contact::where("user_id", \Illuminate\Support\Facades\Auth::user()->id)->first();
        if ($data) {
            return view('panels.user.updateprofile.teacher.Step4Teacher', compact("data"));
        } else {
            return redirect()->route("verifyprofilesteps");
        }
    }


}
