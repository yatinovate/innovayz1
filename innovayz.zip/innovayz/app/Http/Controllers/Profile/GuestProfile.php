<?php

namespace App\Http\Controllers\Profile;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Auth;

class GuestProfile extends Controller {

    public function index() {
        $user = User::find(Input::get("user-id"));
        $userdata = new \App\Logic\Dashboard\UserData();
        $suggested = $userdata->suugestedcooncetionguest($user);

        $postdat = \App\Models\Profile\PostKnowledgeUser::where('user_id', $user->id)->orderby("created_at", "desc")->get();
        $connection = \App\Models\Profile\Followers::where("followers_id", $user->id)->get();
        $usertype = $user->user_type;
        $abt = '';
        if ($usertype == "students") {
            if ($user->profile_status == "step1") {
                $abt = "No About us";
            } else {
                $abt = $user->student->describe_yourself;
            }
        } elseif ($usertype == "teachers") {
            if ($user->profile_status == "step1") {
                $abt = "No About us";
            } else {
                $abt = $user->teacher->describe_yourself;
            }
        } elseif ($usertype == "colleges") {
            if ($user->profile_status == "step1") {
                $abt = "No About us";
            } else {
                $abt = $user->college->breif;
            }
        }
        
        $folloingarr = array();
        $followersusers = \App\Models\Profile\Followers::where("user_id", Auth::user()->id)->get();
        foreach ($followersusers as $us) {
            $folwer = User::find($us->followers_id);
            $folloingarr[] = array('userid' => $folwer->id, 'user_name' => $folwer->name, 'avatar' => $folwer->avatar);
        }
        $elib = \Illuminate\Support\Facades\DB::table("laradrop_files")->where("user_id", $user->id)->where("security", 0)->whereNotIn('type', ['folder', 'link'])->get();
        $question = \App\Models\Question\PostQuestion::where("user_id", $user->id)->get();
        $usercontact = \App\Models\User\Contact::where('user_id', '=', $user->id)->first();
        if(Auth::check()){
            if(Auth::user()->id!=$user->id){
                \Illuminate\Support\Facades\Event::fire(new \App\Events\NotifyUsers($user->id, 'Some One Viewed your profile', 'Dear user , '.Auth::user()->name.' has viewed your profile', Route("profile.index", ["user-id" => Auth::user()->id, 'user-name' => Auth::user()->name]) ));
            }
            
        }
        return view('panels.user.profile.index', ['userdata' => $user, 'aboutint' => $abt, 'folloingarr' => $folloingarr,'userarray' => $connection, 'postdta' => $postdat,
            'alluser' => $suggested, 'questionar' => $question, 'elib' => $elib, "contact" => $usercontact]);
    }

}
