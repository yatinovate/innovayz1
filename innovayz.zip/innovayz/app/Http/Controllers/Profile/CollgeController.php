<?php

namespace App\Http\Controllers\Profile;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;
use Validator;
use DB;
use Illuminate\Support\Facades\Input;

class CollgeController extends Controller {

    public function step1view() {
        $status = Auth::user()->profile_status;
        if ($status == 'step1') {
            return view('panels.user.completeProfile.college.Step1College');
        }else{
            return redirect()->route('verifyprofilesteps');
        } 
    }

    public function step1(Request $request) {
        $user = \App\Models\Profile\College::firstOrNew(array('user_id' => Auth::user()->id));
        $user->user_id = Auth::user()->id;
        $user->select_category = $request['col_type'];
        $user->affilatedby = $request['affilatedby'];
        $user->establishment = $request['estab_yr'];
        $user->breif = $request['description'];
        if ($user->save()) {
            $user1 = Auth::user();
            $user1->profile_status = 'step2';
            if ($user1->save()) {
                return redirect()->route('verifyprofilesteps');
            } else {
                return redirect()->back()->with('issues', 'Error occur while saving data ,try again later');
            }
        } else {
            return redirect()->back()->with('issues', 'Error occur while saving data ,try again later');
        }
    }

    public function step2view() {
        $status = Auth::user()->profile_status;
        if ($status == 'step2') {
            $course = \App\Models\User\QualificationList::where('category', "")->get();
        return view('panels.user.completeProfile.college.Step2College', compact("course"));
        }else{
            return redirect()->route('verifyprofilesteps');
        } 
    }

    public function getStream($cat_id) {

        $keyword = '%' . Input::get('term') . '%';
        $query = \App\Models\User\QualificationList::where('category', $cat_id)->where("qulaification", "like", $keyword)->get();
        $searchArray = array();
        foreach ($query as $flight) {
            array_push($searchArray, array('label' => $flight->qulaification, 'value' => $flight->qulaification, 'id' => $flight->id));
        }
        echo json_encode($searchArray);
    }

    public function step2(Request $request) {
        $rowcount = sizeof($request['col_name']);
        for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
            $subject_id = $request->get('col_stream1')[$ix];
            $subject_name = $request->get('col_stream')[$ix];
            $bio = new \App\Models\User\Courses();
            $bio->user_id = Auth::user()->id;
            $bio->course_name = $request->get('col_name')[$ix];
            $bio->duration_year = $request->get('col_yr')[$ix];
            $bio->duration_month = $request->get('col_month')[$ix];
            $bio->course_desc = $request->get('course_desc')[$ix];
            $bio->fee = $request->get('col_feee')[$ix];
            $bio->fee_type = $request->get('fee_type')[$ix];
            $bio->eligi_criteria = $request->get('course_eligibility')[$ix];
            if ($bio->save()) {
                if ($subject_id == null) {
                    $stream = new \App\Models\User\User_Stream();
                    $stream->category = $request->get('col_name')[$ix];
                    $stream->qualification = $request->get('col_stream')[$ix];
                    $stream->user_id = \Illuminate\Support\Facades\Auth::user()->id;
                    $stream->course_id = $bio->id;
                    $stream->save();
                } else {
                    $qual = \App\Models\User\QualificationList::where('id', $subject_id)->first()->qulaification;
                    if ($qual == $request->get('col_stream')[$ix]) {
                        $qualaaa = \App\Models\User\Courses::find($bio->id);
                        $qualaaa->stream = $subject_id;
                        $qualaaa->save();
                    } else {
                        $stream = new \App\Models\User\User_Stream();
                        $stream->category = $request->get('col_name')[$ix];
                        $stream->qualification = $request->get('col_stream')[$ix];
                        $stream->user_id = \Illuminate\Support\Facades\Auth::user()->id;
                        $stream->course_id = $bio->id;
                        $stream->save();
                    }
                }
            }
        }
        $user1 = Auth::user();
        $user1->profile_status = 'step3';
        if ($user1->save()) {
            return redirect()->route('verifyprofilesteps');
        } else {
            return redirect()->back()->with('issues', 'Error occur while saving data ,try again later');
        }
    }

    public function step3view() {
         $status = Auth::user()->profile_status;
        if ($status == 'step3') {
            return view('panels.user.completeProfile.college.Step3College');
        }else{
            return redirect()->route('verifyprofilesteps');
        } 
    }

    public function step3(Request $request) {
        $bio = \App\Model\User\Contact::firstOrNew(array('user_id' => Auth::user()->id));
        $bio->user_id = Auth::user()->id;
        $bio->address = $request['address'];
        $bio->mobile = $request['mobile'];
        $bio->skype = $request['skype'];
        $bio->uddhear = $request['uddhear'];
        $bio->country = $request['country'];
        $bio->state = $request['state'];
        $bio->city = $request['city'];
        $bio->pncode = $request['pncode'];
        $bio->recieveudates = $request['recieveudates'];
        if ($bio->save()) {
            $user1 = Auth::user();
            $user1->profile_status = 'done';
            $user1->save();
            return redirect()->route("Dashboard");
        } else {
            return redirect()->back()->with('issues', 'Error occur while saving data ,try again later');
        }
    }

    
    public function updatestepView1() {
        $dta = \App\Models\Profile\College::where("user_id", Auth::user()->id)->first();
        return view('panels.user.updateprofile.college.Step1College',compact("dta"));
    }
    public function updatestep1(Request $request) {
        $user = \App\Models\Profile\College::firstOrNew(array('user_id' => Auth::user()->id));
        $user->select_category = $request['col_type'];
        $user->affilatedby = $request['affilatedby'];
        $user->establishment = $request['estab_yr'];
        $user->breif = $request['description'];
        if ($user->save()) {
            return redirect()->route("college.update2");
        } else {
            return redirect()->back()->with('issues', 'Error occur while saving data ,try again later');
        }
    }

    public function updatestepView2() {

        $course = \App\Models\User\QualificationList::where('category', "")->get();
        $course_list = \App\Models\User\Courses::where("user_id", Auth::user()->id)->get();
        return view('panels.user.updateprofile.college.Step2College', ['course' => $course, 'course_list' => $course_list]);
    }

    public function updatestep2(Request $request) {
        $rowcount = sizeof($request['col_yr']);
        try {
            for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                $course_id = isset($request->get('course_id')[$ix]) ? $request->get('course_id')[$ix] : '';
                if (!$course_id == "") {
                    $bio = \App\Models\User\Courses::find($course_id);
                    $bio->duration_year = $request->get('col_yr')[$ix];
                    $bio->duration_month = $request->get('col_month')[$ix];
                    $bio->course_desc = $request->get('course_desc')[$ix];
                    $bio->fee = $request->get('col_feee')[$ix];
                    $bio->fee_type = $request->get('fee_type')[$ix];
                    $bio->eligi_criteria = $request->get('course_eligibility')[$ix];
                    $bio->save();
                }
            }
             return redirect()->route("college.update3");
        } catch (Exception $ex) {
            return redirect()->back()->with('issues', 'Error occur while saving data ,try again later');
        }
    }

    public function updatecourseView() {
        $course = \App\Models\User\QualificationList::where('category', "")->get();
        return view('panels.user.updateprofile.college.addcourse', compact("course"));
    }
    
    public function saveupdatecourseView(Request $request) {
        try{
        $rowcount = sizeof($request['col_name']);
        for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
            $subject_id = $request->get('col_stream1')[$ix];
            $subject_name = $request->get('col_stream')[$ix];
            $bio = new \App\Models\User\Courses();
            $bio->user_id = Auth::user()->id;
            $bio->course_name = $request->get('col_name')[$ix];
            $bio->duration_year = $request->get('col_yr')[$ix];
            $bio->duration_month = $request->get('col_month')[$ix];
            $bio->course_desc = $request->get('course_desc')[$ix];
            $bio->fee = $request->get('col_feee')[$ix];
            $bio->fee_type = $request->get('fee_type')[$ix];
            $bio->eligi_criteria = $request->get('course_eligibility')[$ix];
            if ($bio->save()) {
                if ($subject_id == null) {
                    $stream = new \App\Models\User\User_Stream();
                    $stream->category = $request->get('col_name')[$ix];
                    $stream->qualification = $request->get('col_stream')[$ix];
                    $stream->user_id = \Illuminate\Support\Facades\Auth::user()->id;
                    $stream->course_id = $bio->id;
                    $stream->save();
                } else {
                    $qual = \App\Models\User\QualificationList::where('id', $subject_id)->first()->qulaification;
                    if ($qual == $request->get('col_stream')[$ix]) {
                        $qualaaa = \App\Models\User\Courses::find($bio->id);
                        $qualaaa->stream = $subject_id;
                        $qualaaa->save();
                    } else {
                        $stream = new \App\Models\User\User_Stream();
                        $stream->category = $request->get('col_name')[$ix];
                        $stream->qualification = $request->get('col_stream')[$ix];
                        $stream->user_id = \Illuminate\Support\Facades\Auth::user()->id;
                        $stream->course_id = $bio->id;
                        $stream->save();
                    }
                }
            }
        }        
         return redirect()->route("college.update3");
        } catch (Exception $ex) {
            return redirect()->back()->with('issues', 'Error occur while saving data ,try again later');
        }
    }
    public function updatestepView3() {
        $data = \App\Models\User\Contact::where("user_id", \Illuminate\Support\Facades\Auth::user()->id)->first();
        return view('panels.user.updateprofile.college.Step3College', compact("data"));
    }

}
