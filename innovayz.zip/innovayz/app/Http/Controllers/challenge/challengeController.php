<?php

namespace App\Http\Controllers\challenge;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use DB;
use URL;
use App\Models\Challenge\ChallengeTest;
use Illuminate\Support\Facades\Input;
use App\Models\Challenge\MultiOptionCh;
use App\Models\Challenge\MultiChoiceCh;
use App\Models\Challenge\TrueFalseSkillCh;
use App\Models\Challenge\ResultChallenge;
use App\Models\Challenge\ActiveChallenge;
use Illuminate\Support\Facades\Session;
use App\Models\Challenge\GroupChallenge;
use Illuminate\Support\Facades\Event;

class challengeController extends Controller {

    public function index() {
        return view('challenge.teacher.index');
    }

    public function getskillView() {
        $tag11 = ChallengeTest::where('user_id', Auth::user()->id)->orderBy('created_at', 'DESC')->get();
        if (!count($tag11)) {
            echo '<div class="alert alert-success">
                No Challenge found 
                </div>';
        } else {
            foreach ($tag11 as $tag) {
                $high = ResultChallenge::where("challenge_id", $tag->id)->max('points');
                if (!$high) {
                    $high = 0;
                }
                $totuser = count(ActiveChallenge::where("challenge_id", $tag->id)->get());
                $passuser = $this->challengePassCount($tag->id);
                echo '<div class="col-md-6"><div class="skill_card">
                    <div class="skill_card1">
                        <h3><a href="' . Route("teach.chdetail", ["challenge-id" => $tag->id]) . '" target="_blank">' . $tag->skill_test_name . '&nbsp;(' . \App\Models\User\QualificationList::where("category", $tag->category)->first()->qulaification . ')</a></h3>                        
                        <small>' . $totuser . ' student participated | ' . $passuser . ' students passed</small>
                        <p>Highest Score ' . $high . '| <a href="' . Route("student.leaderbord", ["challenge-id" => $tag->id, "challenge-name" => $tag->skill_test_name]) . '" target="_blank"">LeaderBoard</a></p>
                        <div class="clearfix"></div>
                    </div></div>
                </div>';
            }
        }
    }

    public function createor() {
        return view('challenge.teacher.create');
    }

    public function createView() {
        $qual = \App\Models\User\QualificationList::where('category', '')->get();
        return view('challenge.teacher.creater', compact("qual"));
    }

    public function postcreateview(Request $request) {
        try {
            $test = new ChallengeTest();
            $test->user_id = Auth::user()->id;
            $test->skill_test_name = $request['skill_name'];
            $test->category = $request['skill_cat'];
            $myString = $request->get('skill_sub1');
            $myArray = explode(',', $myString);
            $rowcount = count($myArray);
            for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                $bio = \App\Models\User\AreaIntrest::where('area_intrest', $myArray[$ix])->where('isValid', 1)->first();
                if ($bio) {
                    $test->subject = $bio->id;
                }
            }
            $test->description = $request['skill_desc'];
            $test->start_date = $request['skill_start_date'];
            $test->end_date = $request['skill_end_date'];
            $test->questn_count = $request['skill_qno'];
            $test->duration = $request['skill_time'];
            $test->save();
            return redirect()->route("teach.startwizard", ["testid" => $test->id, "test-name" => $test->skill_test_name]);
        } catch (Exception $ex) {
            return redirect()->back()->with("issues", "error occured try agaon later !!.");
        }
    }

    public function challengeWizard() {
        $testid = Input::get("testid");
        $skilltest = ChallengeTest::find($testid);
        $totalq = $skilltest->questn_count;
        $progressq = $skilltest->qnoprocess;
        if ($progressq == $totalq) {
            return redirect()->route("teach.modify");
        } else {
            return view('challenge.teacher.challengeWizard', compact('skilltest'));
        }
    }

    public function qtype() {
        $questype = Input::get("qtype");
        $challid = Input::get("skillid");

        if ($questype === 'mo') {
            return view('challenge.teacher.include.multi_option', compact("challid"));
        } else if ($questype === 'mcq') {
            return view('challenge.teacher.include.multi_choice', compact("challid"));
        } else if ($questype === 'tf') {
            return view('challenge.teacher.include.true_false', compact("challid"));
        }
    }

    public function postMulti_option(Request $request) {
        try {
            $test = MultiOptionCh::firstOrNew(array('id' => $request['ques_id']));
            $test->challenge_id = $request['skill_id'];
            $test->points = $request['points'];
            $test->question = $request['question'];
            $test->ans_a = $request['ans_a'];
            $test->ans_b = $request['ans_b'];
            $test->ans_c = $request['ans_c'];
            $test->ans_d = $request['ans_d'];
            $test->correct_ans = $request['correct_ans'];
            $checkr = $test->save();
            if ($checkr) {
                Event::fire(new \App\Events\ChallengeTester($request['skill_id'], $test->id, 'MultiOptionCh'));
                return redirect()->back()->with("status", "success")->with("message", "Question added");
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", "error occured");
        }
    }

    public function postMulti_optionUpdate(Request $request) {
        try {
            $test = MultiOptionCh::firstOrNew(array('id' => $request['quesid']));
            $test->points = $request['points'];
            $test->question = $request['question'];
            $test->ans_a = $request['ans_a'];
            $test->ans_b = $request['ans_b'];
            $test->ans_c = $request['ans_c'];
            $test->ans_d = $request['ans_d'];
            $test->correct_ans = $request['correct_ans'];
            $checkr = $test->save();
            if ($checkr) {
                return redirect()->back()->with("status", "success")->with("message", "Question Updated");
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", "error occured");
        }
    }

    public function postMulti_choice(Request $request) {
        try {
            $test = MultiChoiceCh::firstOrNew(array('id' => $request['ques_id']));
            $test->challenge_id = $request['skill_id'];
            $test->points = $request['points'];
            $test->question = $request['question'];
            $test->ans_a = $request['ans_a'];
            $test->ans_b = $request['ans_b'];
            $test->ans_c = $request['ans_c'];
            $test->ans_d = $request['ans_d'];
            $test->correct_ans = $request['correct_ans'];
            $checkr = $test->save();
            if ($checkr) {
                Event::fire(new \App\Events\ChallengeTester($request['skill_id'], $test->id, 'MultiChoiceCh'));
                return redirect()->back()->with("status", "success")->with("message", "Question added");
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", "error occured");
        }
    }

    public function postMulti_choiceUpdate(Request $request) {
        try {
            $test = MultiChoiceCh::firstOrNew(array('id' => $request['quesid']));
            $test->points = $request['points'];
            $test->question = $request['question'];
            $test->ans_a = $request['ans_a'];
            $test->ans_b = $request['ans_b'];
            $test->ans_c = $request['ans_c'];
            $test->ans_d = $request['ans_d'];
            $test->correct_ans = trim($request['correct_ans'], ",");
            $checkr = $test->save();
            if ($checkr) {
                return redirect()->back()->with("status", "success")->with("message", "Question Updated");
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", "error occured");
        }
    }

    public function postTrue_false(Request $request) {
        try {
            $test = TrueFalseSkillCh::firstOrNew(array('id' => $request['ques_id']));
            $test->challenge_id = $request['skill_id'];
            $test->points = $request['points'];
            $test->question = $request['question'];
            $test->correct_ans = $request['correct_ans'];
            $checkr = $test->save();
            if ($checkr) {
                Event::fire(new \App\Events\ChallengeTester($request['skill_id'], $test->id, 'TrueFalseSkillCh'));
                return redirect()->back()->with("status", "success")->with("message", "Question added");
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", "error occured");
        }
    }

    public function postTrue_falseUpdate(Request $request) {
        try {
            $test = TrueFalseSkillCh::firstOrNew(array('id' => $request['quesid']));
            $test->points = $request['points'];
            $test->question = $request['question'];
            $test->correct_ans = $request['correct_ans'];
            $checkr = $test->save();
            if ($checkr) {
                return redirect()->back()->with("status", "success")->with("message", "Question Updated");
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", "error occured");
        }
    }

    public function updateQuestion() {
        $qid = Input::get("qid");
        $skillid = Input::get("skillid");
        $question = \App\Models\Challenge\QCountInfoCh::where("challenge_id", $skillid)->where("question_id", $qid)->first();
        if (!$question) {
            return response()->json(['success' => FALSE], 400);
        } else {
            $ques = $question->actual_question_id;
            $mycalss = 'App\\Models\\Challenge\\' . $question->qtype;
            $upview = $this->updateviewGetter($question->qtype);
            $quesfinder = $mycalss::find($ques);
            return view('challenge.teacher.include.' . $upview, compact("quesfinder"));
        }
    }

    public function updateviewGetter($param) {
        if ($param == 'MultiOptionCh') {
            return 'multi_optionUpdate';
        } else if ($param == 'TrueFalseSkillCh') {
            return 'true_falseUpdate';
        } else if ($param == 'MultiChoiceCh') {
            return 'multi_choiceUpdate';
        }
    }

    public function previewTest() {
        $quiz = ChallengeTest::find(Input::get("skill_id"));
        $question = \App\Models\Challenge\QCountInfoCh::where('challenge_id', Input::get("skill_id"))->get();

        return view("challenge.teacher.preview", ['quiz' => $quiz, 'qinfo' => $question]);
    }

    public function manage() {
        $skills = ChallengeTest::where('user_id', Auth::user()->id)->orderBy('created_at', 'desc')->get();
        return view("challenge.teacher.manage", compact('skills'));
    }

    public function archive() {
        $skillid = Input::get("skillid");
        $skills = ChallengeTest::find($skillid);
        $status = $skills->archive;
        if ($status == 0) {
            $skills->archive = 1;
            $skills->save();
            echo 'Archive';
        } else {
            $skills->archive = 0;
            $skills->save();
            echo 'Unarchive';
        }
    }

    public function addQuestion(Request $request) {
        try {
            $test = ChallengeTest::find($request['skillidq']);
            $prevq = $test->questn_count;
            $test->questn_count = $prevq + $request['add_question'];
            $checkr = $test->save();
            if ($checkr) {
                return redirect()->route("teach.editQuestion", ["skillid" => $request['skillidq']]);
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("status", "danger")->with("message", "error occured");
        }
    }

    public function editQuestion() {
        $skillid = Input::get("skillid");
        $skilltest = ChallengeTest::find($skillid);
        $question = \App\Models\Challenge\QCountInfoCh::where('challenge_id', $skilltest)->get();

        return view("challenge.teacher.updateskill", compact('skilltest'), compact('question'));
    }

    public function deleteTest() {
        $skillid = Input::get("skill-id");
        $skilltest = ChallengeTest::destroy($skillid);
        return redirect()->back();
    }

    public function post_upload(Request $request) {
        if ($request->ajax()) {
            try {
                $file = Input::file('upload_csv');
                $destinationPath = 'uploads';
                $extension = $file->getClientOriginalExtension();
                $fileName = 'uploadquiz' . rand(11111, 99999) . '.' . $extension; // renameing image
                $upload_success = $file->move($destinationPath, $fileName); // uploading file to given path
                if ($upload_success) {
                    Session::set('csvname', $fileName);
                    return response()->json(['success' => true], 200);
                } else {
                    return response()->json('error', 400);
                }
            } catch (Exception $e) {
                echo $e->getMessage();
            }
        }
    }

    public function createviewCSV() {
        $reader = \League\Csv\Reader::createFromPath('uploads/' . Session::get('csvname'));
        $results = $reader->setOffset(1)->fetchAll();
        $qcount = count($results);
        $qual = \App\Models\User\QualificationList::where('category', '')->get();
        return view('challenge.teacher.csvcreate', compact("qual"), compact("qcount"));
    }

    public function postcreateviewCSV(Request $request) {
        try {
            $test = new ChallengeTest();
            $test->user_id = Auth::user()->id;
            $test->skill_test_name = $request['skill_name'];
            $test->category = $request['skill_cat'];
            $myString = $request->get('skill_sub1');
            $myArray = explode(',', $myString);
            $rowcount = count($myArray);
            for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                $bio = \App\Models\User\AreaIntrest::where('area_intrest', $myArray[$ix])->where('isValid', 1)->first();
                if ($bio) {
                    $test->subject = $bio->id;
                }
            }
            $test->description = $request['skill_desc'];
            $test->start_date = $request['skill_start_date'];
            $test->end_date = $request['skill_end_date'];
            $test->questn_count = $request['skill_qno'];
            $test->duration = $request['skill_time'];
            if ($test->save()) {
                $csv = new \App\Models\Challenge\UploadCsvCh();
                $csv->csvname = Session::get('csvname');
                $csv->isActive = 0;
                $csv->challenge_id = $test->id;
                if ($csv->save()) {
                    Event::fire(new \App\Events\CsvUploaded($test->id, $csv->id, 'UploadCsvCh'));
                    return redirect()->route("teach.editQuestion", ["skillid" => $test->id]);
                }
            }
        } catch (Exception $ex) {
            return redirect()->back()->with("issues", "error occured try agaon later !!.");
        }
    }

    public function viewChallengeDetail() {
        $challenge_id = Input::get("challenge-id");
        $chal = ChallengeTest::find($challenge_id);
        return view("challenge.challengedetail", compact("chal"));
    }

    public function challengePassCount($testid) {
        $userpasscount = 0;
        $test = ResultChallenge::where("challenge_id", $testid)->get();
        foreach ($test as $tester) {
            $tpoint = $tester->total_points;
            $upoint = $tester->points;
            $pass = 0.4 * $tpoint;
            if ($upoint >= $pass) {
                $userpasscount = $userpasscount + 1;
            }
        }
        return $userpasscount;
    }

    public function findGroup() {
        $search = \Illuminate\Support\Facades\Input::get("query");
        $searchf = "%{$search}%";
        $users = \App\Models\Group\GroupsUser::where("user_id", Auth::user()->id)->get();
        $userarray = array();
        foreach ($users as $us) {
            $userarray[] = array('value' => $us->groupinfo->id, 'label' => $us->groupinfo->group_name);
        }
        echo json_encode($userarray);
    }

    public function sendSavedTest(Request $request) {
        $challenge = ChallengeTest::find($request['skill-id']);
        $decsion = $request['decsion'];
        if ($decsion == 'public') {
            if ($challenge->questn_count == $challenge->qnoprocess) {
                $challenge->publish = 1;
                $challenge->save();
                //$this->notifysubjectusers($challenge);
                return redirect()->route("teach.publishmail",["challenge-id"=>$challenge->id]);
            } else {
                return redirect()->back()->with("status", "warning")->with("message", "Unable to Publish,First Finish Challenge Questions");
            }
        } else {
            if ($challenge->questn_count == $challenge->qnoprocess) {
                try {
                    $myString = $request->get('groupa1');
                    $myArray = explode(',', $myString);
                    $rowcount = count($myArray);
                    for ($ix = 0; $ix <= $rowcount - 1; $ix++) {
                        $bio = \App\Models\Group\Group::find($myArray[$ix]);
                        $chat = new \App\Models\Group\GroupChat();
                        $chat->group_id = $bio->id;
                        $chat->user_id = Auth::user()->id;
                        $chat->subject = 'hey guys checkout this challenge';
                        $chat->comments = "check the challenge if you dare to win it ,<a href='" . Route("student.instruction", ["challenge-id" => $challenge->id, "challenge-name" => $challenge->skill_test_name]) . "'>click here</a>";
                        $chat->save();
                        $grpchall = new GroupChallenge();
                        $grpchall->group_id = $bio->id;
                        $grpchall->challenge_id = $challenge->id;
                        $grpchall->save();
                    }
                    $challenge->publish = 1;
                    $challenge->save();
                    return redirect()->back()->with("status", "success")->with("message", "Challenge Published");
                } catch (Exception $ex) {
                    return redirect()->back()->with("status", "danger")->with("message", "error occured");
                }
            } else {
                return redirect()->back()->with("status", "warning")->with("message", "Unable to Publish,First Finish Challenge Questions");
            }
        }
    }

    public function publish() {
        $skillid = Input::get("skillid");
        $skills = ChallengeTest::find($skillid);
        $status = $skills->publish;
        if ($status == 1) {
            $skills->publish = 0;
            $skills->save();
            echo 'Publish';
        }
    }

    public function notifysubjectusers() { 
        $challenge= ChallengeTest::find(Input::get("challenge-id"));
        
        $subject = $challenge->subject;
        $users = \App\Models\User\User_Area::where("area_intrests_id", $subject)->get();
        foreach ($users as $user) {
            $muser = \App\Models\User::find($user->user_id);
            if ($muser->user_type == "students") {
                try{
                Event::fire(new \App\Events\NotifyUsers($user->user_id, 'A new Challenge is created for you', 'A new Challange "' . $challenge->skill_test_name . '" has been started of subject ' . $challenge->area->area_intrest . ' from ' . $challenge->start_date . ' to ' . $challenge->end_date . ' for you. This would help you to analyze your in depth knowledge and your rank about where you lies in contest. ', Route("student.geterpage")));
                
                $muser->notify(new \App\Notifications\ChallengeNotify($user->name, $challenge->skill_test_name,$challenge->area->area_intrest,$challenge->start_date,$challenge->end_date));
                } catch (\Swift_TransportException $ex) {
                        return redirect()->back()->with("status", "danger")->with("message", "Server Down Try again later !!");
                    }
            }
        }
        
                return redirect()->route("teach.modify")->with("status", "success")->with("message", "Challenge Published");
    }

}
