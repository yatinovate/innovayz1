<?php

namespace App\Http\Controllers\challenge;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use App\Models\Challenge\ChallengeTest;
use App\Models\Challenge\QCountInfoCh;
use App\Models\Challenge\ActiveChallenge;
use Illuminate\Support\Facades\Auth;
use App\Models\Challenge\ResultChallenge;

class TakeController extends Controller {

    public function showInstruction() {
        $skillid = Input::get("challenge-id");
        $checkin = ActiveChallenge::where("user_id", Auth::user()->id)->where("challenge_id", $skillid)->get();
        if (count($checkin)) {
            return redirect()->back()->with("status", "warning")->with("message", "Challenge already taken");
        } else {
            $challenge = ChallengeTest::find($skillid);
        $totalpoints = 0;
        for ($ix = 1; $ix <= $challenge->questn_count; $ix++) {
            $questions = QCountInfoCh::where('challenge_id',$challenge->id)->where('question_id', $ix)->first();
            if ($questions) {
                $mycalss = 'App\\Models\\Challenge\\' . $questions->qtype;
                $asd = $mycalss::find($questions->actual_question_id);
                $question_point = $asd->points;
                $totalpoints = $totalpoints + $question_point;
            }
        }
            return view("challenge.student.instruction", compact("challenge"), compact("totalpoints"));
        }
    }

    public function index() {
        $skill_id = Input::get("challenge-id");
        $quiz = ChallengeTest::find($skill_id);
        $dt = new \DateTime();
        if ($quiz->start_date > $dt->format('m/d/Y')) {
            return redirect()->route("ex.errorpage")->with("error", "Page you are looking for is not available for you");
        } else {
            $challenge_area = $quiz->subject;
            $user_area = \App\Models\User\User_Area::where("user_id", Auth::user()->id)->where("area_intrests_id", $challenge_area)->get();
            if (count($user_area)) {
                $question = QCountInfoCh::where('challenge_id', $skill_id)->get();
                $activetest = ActiveChallenge::where('user_id', Auth::user()->id)->where("challenge_id", $skill_id)->first();
                if(!count($activetest)){
                    $activetest = ActiveChallenge::firstOrNew(array('user_id' => Auth::user()->id, "challenge_id" => $skill_id));
                    $activetest->user_id = Auth::user()->id;
                    $activetest->challenge_id = $skill_id;
                    $activetest->reactive = 1440;
                    $activetest->activetime = ($quiz->duration) * 60;
                    $activetest->save();
                }
                return view("challenge.student.skill", ['quiz' => $quiz, 'qinfo' => $question,"activetest"=>$activetest]);
            } else {
                return redirect()->route("ex.errorpage")->with("error", "Page you are looking for is not available for you");
            }
        }
    }

    public function result(Request $request) {
        $skill = ChallengeTest::find($request['skillid']);
        $qcount = $skill->questn_count;
        $totalpoints = 0;
        $user_points = 0;
        $corectqno = 0;
        $incorectqno = 0;
        $atempqno = 0;
        for ($ix = 1; $ix <= $qcount; $ix++) {
            $questions = QCountInfoCh::where('challenge_id', $request['skillid'])->where('question_id', $ix)->first();
            if ($questions) {
                $mycalss = 'App\\Models\\Challenge\\' . $questions->qtype;
                $asd = $mycalss::find($questions->actual_question_id);
                $act_ans = $asd->correct_ans;
                $question_point = $asd->points;
                $totalpoints = $totalpoints + $question_point;
                $userans = $request['q' . $ix];
                if ($userans == '') {
                    $atempqno = $atempqno + 1;
                } else {
                    if ($questions->qtype == 'MultiChoiceCh') {
                        $act_ans = trim($act_ans, ",");
                        $pieces = explode(",", $act_ans);
                        $pontcor = count($pieces);
                        $asd = 0;
                        foreach ($userans as $color) {
                            if (in_array($color, $pieces)) {
                                $asd = $asd + 1;
                            } else {
                                $asd = $asd - 1;
                            }
                        }
                        if ($asd == $pontcor) {
                            $user_points = $user_points + $question_point;
                            $corectqno = $corectqno + 1;
                        } else {
                            $incorectqno = $incorectqno + 1;
                        }
                    } else {

                        if ($userans == $act_ans) {
                            $user_points = $user_points + $asd->points;
                            $corectqno = $corectqno + 1;
                        } else {
                            $incorectqno = $incorectqno + 1;
                        }
                    }
                }
            }
        }
        $resu = ResultChallenge::firstOrNew(array('challenge_id' => $request['skillid'], 'user_id' => \Illuminate\Support\Facades\Auth::user()->id));
        $resu->challenge_id = $request['skillid'];
        $resu->user_id = \Illuminate\Support\Facades\Auth::user()->id;
        $resu->points = $user_points;
        $resu->total_points = $totalpoints;
        $resu->save();
        $pass = 0.4 * $totalpoints;
        if ($user_points >= $pass) {
            if ($user_points == $totalpoints) {
                $usermsg = '<h2>Congratsulatons you have scored ' . $user_points . ' marks out of ' . $totalpoints . ' </h2><br>'
                        . '<p>You are a champ</p>';
            } else {
                $usermsg = '<h2>Congratsulatons you have scored ' . $user_points . ' marks out of ' . $totalpoints . ' </h2><br>'
                        . '<p>There is still a scope to improve yourself</p>';
            }
        } else {
            $usermsg = '<h2>Thanks for attempting the challenge. Unfortunately you could not suceed to score enough</h2><br>'
                    . '<p>You have scored ' . $user_points . ' marks out of ' . $totalpoints . ', Study hard and take the challenge.</p>';
        }

        return view("challenge.result", ['skill'=>$skill,'correctq' => $corectqno, 'incorectq' => $incorectqno, 'unatempt' => $qcount - $atempqno, 'totalq' => $qcount, 'tpoints' => $totalpoints, 'upoints' => $user_points, 'usermsg' => $usermsg]);
    }

    public function getleaderView() {
        $challenge_id = Input::get("challenge-id");
        $chll = ChallengeTest::find($challenge_id);
        $lead = ResultChallenge::where("challenge_id", $challenge_id)->orderBy('points', 'desc')->take(9)->get();
        return view("challenge.leaderboard", ['chllangenamae' => $chll->skill_test_name, 'leader' => $lead]);
    }

    public function updatetime() {
        $challenge_activationid = Input::get("id");
        $time = Input::get("time");
        $chll = ActiveChallenge::find($challenge_activationid);
        $chll->activetime = $time;
        $chll->save();
    }

}
