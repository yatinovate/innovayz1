<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\User;

class LoginController extends Controller {

    public function authenticate(Request $request) {
        $validuser = User::where('email', '=', $request['email'])->where('activated', '=', 1)->first();
        if ($validuser) {
            if (Auth::attempt(['email' => $request["email"], 'password' => $request["password"], 'activated' => 1])) {
                if (auth()->user()->hasRole('user')) {
                    if (session('url.intended')) {
                        $url=session('url.intended');
                        \Illuminate\Support\Facades\Session::forget('url.intended');
                        return redirect($url);
                    }
                    return redirect()->route("verifyprofilesteps");
                }
                if (auth()->user()->hasRole('administrator')) {
                    return redirect()->route('admin.home');
                }
            } else {
                return redirect()->back()
                                ->with('loginactivationerror', 'Wrong Credentials');
            }
        } else {
            return redirect()->back()
                            ->with('loginactivationerror', 'Your account is not activated yet,Check the activtion mail on your email-id');
        }
    }

    public function logout() {
        Auth::logout();
        return redirect()->to('/');
    }

    public function forget(Request $request) {
        $user = User::where('email', $request['resetpass'])->first();
        if (!$user) {
            return redirect()->back()->with("forgeterror", 'Email is not registered');
        }
        $token = hash_hmac('sha256', str_random(40), config('app.key'));
        \Illuminate\Support\Facades\DB::table('password_resets')->insert(['email' => $request['resetpass'], 'token' => $token, 'created_at' => \Carbon\Carbon::now()->toDateTimeString()]);
        try {
            $user->notify(new \App\Notifications\ResetPassword($token, $user->name));
            return redirect()->back()->with("forgetsucess", 'Email sent successfully,check your inbox');
        } catch (\Swift_TransportException $ex) {
            return redirect()->back()->with("forgeterror", "Server Down Try again later !!");
        }
    }

    /*
     * MAIL_DRIVER=smtp
      MAIL_HOST=smtp.gmail.com
      MAIL_PORT=587
      MAIL_USERNAME= "mailtouddeshya@gmail.com"
      MAIL_PASSWORD="ssnmyaurvtzfejgv"
      MAIL_ENCRYPTION=tls
     */

    public function passwordset($token) {
        $email = \Illuminate\Support\Facades\Input::get("email");
        $check = \Illuminate\Support\Facades\DB::table('password_resets')->where("email", $email)->where("token", $token)->get();
        if (count($check)) {
            return view('Auth.passwordset')->with(['token' => $token, 'email' => $email]);
        } else {
            return redirect("/")->with("forgeterror", 'Wrong Password Token');
        }
    }

    public function setpassword(Request $request) {
        $user = User::where('email', $request["email"])->update(['password' => bcrypt($request["password"])]);
        if ($user) {
            $userdata = array('email' => $request["email"], 'password' => $request['password']);
            Auth::attempt($userdata);
            $resetuser = \Illuminate\Support\Facades\DB::table('password_resets')->where('email', $request["email"])->delete();
            if ($resetuser) {
                if (auth()->user()->hasRole('user')) {
                    return redirect()->route("verifyprofilesteps");
                } else if (auth()->user()->hasRole('administrator')) {
                    return redirect()->route('admin.home');
                }
            }
        } else {
            return redirect()->back()->with("forgeterror", 'Error Occured !!');
        }
    }

}
