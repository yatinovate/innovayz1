<?php

namespace App\Http\Controllers\Auth;


use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Socialite;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Input;
use App\Models\User;
use App\Models\User\Social;
use App\Models\User\Role;

class SocialController extends Controller
{
 
 
    public function redirectToProvider($provider)
    {
        $providerKey = Config::get('services.' . $provider);
        if (empty($providerKey)) {
            return view('pages.status')
                ->with('error','No such provider');
        }        
        return Socialite::driver($provider)->redirect();
    }
    public function handleProviderCallback($provider)
    {
        if (Input::get('error') != '' || Input::get('denied') != '' || !\Request::has('code')) {
            return redirect()->back()->with('loginactivationerror', 'You did not share your profile data with our social app.');                
        }
        $user = Socialite::driver($provider)->user();
        $socialUser = null;
        //Check is this email present
        $userCheck = User::where('email', '=', $user->email)->first();
        $email = $user->email;
        if (!$user->email) {
            $email = 'missing' . str_random(10);
        }
        if (!empty($userCheck)) {
            $socialUser = $userCheck;
        }else {
            $sameSocialId = Social::where('social_id', '=', $user->id)->where('provider', '=', $provider )->first();
            if (empty($sameSocialId)) {
                //There is no combination of this social id and provider, so create new one
                $newSocialUser = new User;
                $newSocialUser->email = $email;
                $newSocialUser->name = $user->name;
                $newSocialUser->password = bcrypt(str_random(16));
                $newSocialUser->avatar = $user->getAvatar();
                $newSocialUser->token = str_random(64);
                $newSocialUser->activated = 1;
                $newSocialUser->save();

                $socialData = new Social;
                $socialData->social_id = $user->id;
                $socialData->provider= $provider;
                $newSocialUser->social()->save($socialData);
                // Add role
                $role = Role::whereName('user')->first();
                $newSocialUser->assignRole($role);
                $socialUser = $newSocialUser;
            }
            else {
                //Load this existing social user
                $socialUser = $sameSocialId->user;
            }
        }
         auth()->login($socialUser, true);
        if ( auth()->user()->hasRole('user')) {
            return redirect()->route('verifyprofilesteps');
        }
        if ( auth()->user()->hasRole('administrator')) {
            return redirect()->route('admin.home');
        }
        //return abort(500, 'User has no Role assigned, role is obligatory! You did not seed the database with the roles.');
    }
        
}
