<?php

namespace App\Http\Controllers\Auth;

use App\Models\User;
use Validator;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Http\Request;
use \App\Traits\ActivationTrait;
use App\Models\User\Role;
use App\Models\User\InviteUser;

class RegisterController extends Controller {
    /*
      |--------------------------------------------------------------------------
      | Register Controller
      |--------------------------------------------------------------------------
      |
      | This controller handles the registration of new users as well as their
      | validation and creation. By default this controller uses a trait to
      | provide this functionality without requiring any additional code.
      |
     */

use RegistersUsers,
    ActivationTrait;

    /**
     * Where to redirect users after login / registration.
     *
     * @var string
     */
    protected $redirectTo = '/';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data) {
        $validator = Validator::make($data, [
                    'name' => 'required',
                    'email' => 'required|email|unique:users',
                    'password' => 'required|min:6|max:20'
                        ], [
                    'name.required' => 'Name is required',
                    'email.required' => 'Email is required',
                    'email.email' => 'Email is invalid',
                    'password.required' => 'Password is required',
                    'password.min' => 'Password needs to have at least 6 characters',
                    'password.max' => 'Password maximum length is 20 characters'
                        ]
        );

        return $validator;
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data) {
        $user = User::create([
                    'name' => $data['name'],
                    'email' => $data['email'],
                    'password' => bcrypt($data['password']),
                    'user_type' => $data['utype'],
                    'token' => str_random(64),
                    'activated' => true
        ]);

        $role = Role::whereName('user')->first();
        $user->assignRole($role);
        return $user;
    }

    public function register(Request $request) {
        $validator = $this->validator($request->all());
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator);
        } else {
            $invitecheck = $request["invitaion"];
            event(new \Illuminate\Auth\Events\Registered($user = $this->create($request->all())));
            if ($invitecheck) {
                $userinvite = InviteUser::where("token", $invitecheck)->first();
                $user1 = $userinvite->user_id;
                $verify = \App\Models\Profile\Followers::where('user_id', $user->id)->where('followers_id', $user1)->first();
                if (!$verify) {
                    $user->following()->save(User::find($user1));
                }
                $userinvite->delete();
            }
            try {
                $this->initiateEmailActivation($user);
                return redirect()->route("/")->with("signupsuccess", "We sent you an activation code, check your inbox !!");
            } catch (\Swift_TransportException $ex) {
                return redirect()->route("/")->with("signuperror", "Server Down Try again later !!");
            }
        }
    }

}
