<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;

class ActivateController extends Controller {

    use \App\Traits\ActivationTrait;

    public function activate($token) {
        if (!Auth::check()) {
            $activation = \App\Models\User\User_Activation::where('token', $token)->first();
            if (empty($activation)) {
                return redirect("/")->with("signuperror", "No such token in the database!");                                
            }
            $user = \App\Models\User::find($activation->user_id);
            $user->activated = true;
            $user->save();
            Auth::login($user);
            $activation->delete();
            try {
                $user->notify(new \App\Notifications\WelcomeMail($user->name));
            } catch (\Swift_TransportException $ex) {
                return redirect()->back()->with("signuperror", "Server Down Try again later !!");
            }

            return redirect()->route("verifyprofilesteps");
        } else {
            if (auth()->user()->activated) {
                return redirect()->route('verifyprofilesteps')
                                ->with('status', 'success')
                                ->with('message', 'Your email is already activated.');
            }
        }
    }

}
