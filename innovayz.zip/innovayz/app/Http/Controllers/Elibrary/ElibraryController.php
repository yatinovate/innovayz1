<?php

namespace App\Http\Controllers\Elibrary;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\User\Googl;
use Session;
use Illuminate\Support\Facades\Input;
use App\Models\User\Elibrary;

class ElibraryController extends Controller {

    public function getview(Googl $googl, Request $request) {
        $folder = Auth::user()->name.Auth::user()->id;
        $path = 'userdata/' . $folder;
        $user = User::where('id', Auth::user()->id)
                ->update(['e_library' => $folder]);
        if ($user) {
            if (!File::exists($path)) {
                File::makeDirectory($path, 0777, true, true);
            }
            if (Session::has('gdrivetoken')) {
            $congdeuve = new GdriveController($googl);
            $page_data = $congdeuve->files();
            return view("panels.user.elibrary.main", $page_data);
        }else{
            return view("panels.user.elibrary.main");
        }
        } else {
            return redirect()->route("/");
        }
    }

    public function gAcess(Googl $googl) {
        $client = $googl->client();
        $auth_url = $client->createAuthUrl();
        return redirect($auth_url);
    }

    public function gdriveacess(Googl $googl, Request $request) {
        $client = $googl->client();
        if (Input::get('error') != '' || Input::get('denied') != '' || !\Request::has('code')) {
            return redirect()->route("e-library")->with("status",'danger')->with('message', 'You did not share your profile data with our social app.');                
        }
        if ($request->has('code')) {
            $client->authenticate($request->input('code'));
            $token = $client->getAccessToken();
            session(['gdrivetoken' => $token]);
            return redirect()->route("gdocs");
        } else {
            $auth_url = $client->createAuthUrl();
            return redirect($auth_url);
        }
    }

    public function gdocs(Googl $googl, Request $request) {
        if (Session::has('gdrivetoken')) {
            $congdeuve = new GdriveController($googl);
            $page_data = $congdeuve->files();
            return view("panels.user.elibrary.gdrive", $page_data);
        }
    }

    public function gAcessDisconnect(Request $request) {
        $request->session()->forget('gdrivetoken');
        return redirect()->route('e-library');
    }
    public function getGdriveView(Googl $googl, Request $request) {
        
        if (Session::has('gdrivetoken')) {
            $congdeuve = new GdriveController($googl);
            $page_data = $congdeuve->files();
            return view("panels.user.elibrary.gdrive", $page_data);
        }else{
            return view("panels.user.elibrary.gdrive");
        }
    }

    
    
    
    
    
    
    
    
    
    
    

}
