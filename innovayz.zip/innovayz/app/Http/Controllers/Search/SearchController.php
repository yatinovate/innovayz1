<?php

namespace App\Http\Controllers\Search;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Auth;
use App\Models\User\AreaIntrest;
use App\Models\User\User_Area;
use App\Models\User\Contact;
class SearchController extends Controller {

    public function find(Request $request) {
        $category = $request['category'];
        $keyword = '%' . $request['search'] . '%';
        $sql_res = User::where('name', 'like', $keyword)->where("user_type", $category)->where('activated', 1)->get();
        foreach ($sql_res as $row) {
            $follow = "Follow";
            if (Auth::check()) {
                if ($row->id != Auth::user()->id) {
                    $user1 = User::find(Auth::user()->id);
                    $verify = \App\Models\Profile\Followers::where('user_id', $user1->id)->where('followers_id', $row->id)->first();
                    if ($verify) {
                        $follow = "Unfollow";
                    }
                    echo $this->searchitemui($row, $follow);
                }
            } else {
                echo $this->searchitemui($row, $follow);
            }
        }
    }

    public function searchitemui($row, $follow) {
        $btncont='<div class="col-md-6 col-md-offset-3 pull-right">
                                    <a class="btn btn-info pull-right" href="' . Route("profile.index", ["user-id" => $row->id, 'user-name' => $row->name, "message" => "true"]) . '">Message</a>
                                    
                                </div>' ;
        if(Auth::check()){
         $btncont=  '<div class="col-md-6 col-md-offset-3 pull-right">
                                    <a class="btn btn-info pull-right" href="' . Route("profile.index", ["user-id" => $row->id, 'user-name' => $row->name, "message" => "true"]) . '">Message</a>
                                    <a href="' . Route("follow", ["user-id" => $row->id]) . '" class="btn btn-info pull-right">' . $follow . '</a>&nbsp;&nbsp;
                                </div>' ;
        }
        $item = '<div class="resultitem">
                    <div class="row">
                        <div class="col-md-2">
                            <img src="' . asset($row->avatar) . '" alt="' . $row->name . '" class="img-responsive" />                            
                        </div>
                        <div class="col-md-10">
                            <div class="row">
                                <a href="' . Route("profile.index", ["user-id" => $row->id, 'user-name' => $row->name]) . '" class="search_title">' . $row->name . '</a>                            
                            </div>                            
                            <div class="row">
                            '.$btncont.'                                
                            </div>
                        </div>
                    </div>
                  </div>';
        return $item;
    }

    public function follow() {
        $user1 = User::find(Auth::user()->id);
        $user2 = User::find(Input::get("user-id"));
        $verify = \App\Models\Profile\Followers::where('user_id', $user1->id)->where('followers_id', $user2->id)->first();
        if ($verify) {
            $verify = \App\Models\Profile\Followers::where('user_id', $user1->id)->where('followers_id', $user2->id)->delete();
            return redirect()->route("profile.index", ["user-id" => $user2->id, 'user-name' => $user2->name]);
        } else {
            $user1->following()->save($user2);
            \Illuminate\Support\Facades\Event::fire(new \App\Events\NotifyUsers($user2->id, 'You have been followed by '.$user1->name, 'Dear user ,'.$user1->name.' has started following you to InnoVayz portal', Route("profile.index", ["user-id" => $user1->id, 'user-name' => $user1->name]) ));
            try {
                $user2->notify(new \App\Notifications\FollowerNotify($user2->name, $user1->name));
            } catch (\Swift_TransportException $ex) {
                return redirect()->route("profile.index", ["user-id" => $user2->id, 'user-name' => $user2->name])->with("status", "danger")->with("message", "Server Down Try again later !!");
            }
            return redirect()->route("profile.index", ["user-id" => $user2->id, 'user-name' => $user2->name]);
        }
    }

    public function searchSubmitView() {
        $para = Input::get('q');
        $category = Input::get('category');
        $keyword = '%' . $para . '%';
        if (Auth::check()) {
            $sql_res = User::where('name', 'like', $keyword)->where('user_type', $category)->where('activated', 1)->where('id', '!=', Auth::user()->id)->get();
        } else {
            $sql_res = User::where('name', 'like', $keyword)->where('activated', 1)->where('user_type', $category)->get();
        }
        return view('pages.search', compact('sql_res'), compact("para", "category"));
    }

    public function searchitemView() {
        $key = Input::get("string");
        $category = Input::get('category');
        $keyword = '%' . $key . '%';
        if (Auth::check()) {
            $sql_res = User::where('name', 'like', $keyword)->where('user_type', $category)->where('activated', 1)->where('id', '!=', Auth::user()->id)->get();
        } else {
            $sql_res = User::where('name', 'like', $keyword)->where('activated', 1)->where('user_type', $category)->get();
        }
        $areatag = array();
        $location = array();
        foreach ($sql_res as $us) {
            if ($us->profile_status == "done") {
                foreach ($us->user_area as $area) {
                    $areatag[] = array("id" => $area->area_int->id, "areaname" => $area->area_int->area_intrest);
                }
                $location[] = array("id" => $us->contact->id, "areaname" => $us->contact->city);
            }
        }
        $questid = array_unique($areatag, SORT_REGULAR);
        $questid1 = array_unique($location, SORT_REGULAR);

        return response()->json(['success' => true, 'area' => $questid, "location" => $questid1]);
    }
    
    public function searchitemViewSkill() {
        $key = Input::get("string");
        $category = Input::get('category');
        $keyword = '%' . $key . '%';
        $area = Input::get('areau');
        if (Auth::check()) {
            $sql_res = User::where('name', 'like', $keyword)->where('user_type', $category)->where('activated', 1)->where('id', '!=', Auth::user()->id)->get();
        } else {
            $sql_res = User::where('name', 'like', $keyword)->where('activated', 1)->where('user_type', $category)->get();
        }
        $userarray=array();
        foreach ($sql_res as $user) {
            $sql_res23 = User_Area::where('user_id', $user->id)->where('area_intrests_id', $area)->get();
            foreach ($sql_res23 as $usd) {
                $userarray[]=$usd->user_id;
            }
        }
        return view('pages.includes.searchitem', ['user' => $userarray]);
    }

        public function searchitemViewlocation() {
            $key = Input::get("string");
        $category = Input::get('category');
        $keyword = '%' . $key . '%';
        $area = Input::get('areau');
        if (Auth::check()) {
            $sql_res = User::where('name', 'like', $keyword)->where('user_type', $category)->where('activated', 1)->where('id', '!=', Auth::user()->id)->get();
        } else {
            $sql_res = User::where('name', 'like', $keyword)->where('activated', 1)->where('user_type', $category)->get();
        }
        $userarray=array();
        foreach ($sql_res as $user) {
            $sql_res23 = Contact::where('user_id', $user->id)->where('id', $area)->get();
            foreach ($sql_res23 as $usd) {
                $userarray[]=$usd->user_id;
            }
        }
        return view('pages.includes.searchitem', ['user' => $userarray]);
    }
}
