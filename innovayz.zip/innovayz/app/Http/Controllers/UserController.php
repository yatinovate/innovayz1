<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller {

    public function index() {
        if (Auth::guest()) {
            return view("pages.home");
        } else {
            return redirect()->route('Dashboard');
        }
    }

   

    public function confirm($confirmation_code) {
        if (!$confirmation_code) {
            throw new InvalidConfirmationCodeException;
        }

        $user = User::whereConfirmationCode($confirmation_code)->first();

        if (!$user) {
            throw new InvalidConfirmationCodeException;
        }

        $user->confirmed = 1;
        $user->confirmation_code = null;
        $user->save();

        Auth::login($user);
        return redirect()->route('verifyprofilesteps');
    }


    

    


    public function Subscription(Request $request) {
        $validator = Validator::make($request->all(), ["subscribe" => "required|email"]);
        if ($validator->fails()) {
            return response()->json(['success' => false, 'errors' => $validator->getMessageBag()->toArray()], 400);
        } else if ($validator->passes()) {
            $user = new \App\Subscriber();
            $user->email = $request['subscribe'];
            if ($user->save()) {
                return response()->json(['success' => true], 200);
            } else {
                return response()->json(['success' => false, 'custerrors' => 'Error occur while saving data ,try again later'], 400);
            }
        }
    }
    public function sendMessage(Request $request) {
        try{
            \Nahid\Talk\Facades\Talk::setAuthUserId(auth()->user()->id);
            $body = $request["send_message"];
            $userId = $request["userid"];

            if ($message = \Nahid\Talk\Facades\Talk::sendMessageByUserId($userId, $body)) {
               return redirect()->route('message.read', ['id'=> $userId]);
                //return view('panels.user.profile.includes.newMessage', compact('message'))->render();
            }
            
        } catch (Exception $ex) {
            return redirect()->back()->with("status","danger")->with("message","Error Occured");
        }
    }
    
    
    public function notify() {
        $notify = \App\Models\User\NotificationSystem::where("user_id", Auth::user()->id)->where("is_read",0)->orderBy('created_at', 'DESC')->get();
        $countnot = count($notify);
        if (count($notify)) {
            foreach ($notify as $nt) {
                echo '<a class="content" href="'.url($nt->link).'">
                        <div class="notification-item">
                            <h4 class="item-title">' . $nt->subject . '</h4>
                            <p class="item-info">' . $nt->body . '</p>
                        </div>
                      </a>';
            }
        }
    }

    public function notifyread() {
        $notify = \App\Models\User\NotificationSystem::where("user_id", Auth::user()->id)->where("is_read",0)->get();
        foreach($notify as $noty){
            $noty->is_read=1;
            $noty->save();
        }
        return 0;
    }
    
    
    public function allnotifyread() {
        $notify = \App\Models\User\NotificationSystem::where("user_id", Auth::user()->id)->orderBy('created_at', 'DESC')->get();
        return view("panels.user.Notification", compact("notify"));
    }
}
