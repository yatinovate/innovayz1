<?php

namespace App\Http\Controllers\Guest;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Models\VisitorInfo;
use App\Models\Visitor;
use Illuminate\Support\Facades\DB;

class GuestController extends Controller {

    public function index() {
        if (Auth::guest()) {
            $invitaioncode= \Illuminate\Support\Facades\Input::get("Invitaion-code");
            if($invitaioncode){
                $check= \App\Models\User\InviteUser::where("token",$invitaioncode)->first();
                if($check){
                    $usermail=$check->email;
                    return view("Guest.home", compact("invitaioncode"), compact("usermail"));
                }else{
                    return redirect()->route("/")->with('signuperror', "Invitaion code not found");
                  //  \Illuminate\Support\Facades\Session::set('signuperror', "Invitaion code not found");
                  //  return view("Guest.home");
                }
            }else{
                return view("Guest.home");
            }
        } else {
            return redirect()->route('Dashboard');
        }
    }

    public function terms() {
        return view("Guest.terms");
    }

    public function setVisitor(Request $request) {

        $ip = $request->ip();
        $agent = $request->header('User-Agent');
        $datetime = date("Y/m/d") . ' ' . date('H:i:s');
        $maxrows = 50;
        $v_rowcount1 = VisitorInfo::where("ip_address", $ip)->get();
        if (!count($v_rowcount1)) {
            $visitorinfo = new VisitorInfo();
            $visitorinfo->ip_address = $ip;
            $visitorinfo->user_agent = $agent;
            $visitorinfo->datetime = $datetime;
            if ($visitorinfo->save()) {
                $visorcout = DB::table('visitors')->select('count')->get();
                echo $visorcout;
                if (count($visorcout)) {
                    echo 'hai';
                    DB::table('visitors')->increment('count');
                } else {
                    echo 'nahai';
                    $insert = new Visitor();
                    $insert->count = 1000;
                    $insert->save();
                }
            }
        }
    }
    public function setErrorpage() {
        return view('errors.ex404');
    }
    public function services() {
        return view('Guest.services');
    }
    public function privacy() {
        return view('Guest.privacy-policy');
    }
    
}
