<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;

class CsvUploaded {

    use InteractsWithSockets,
        SerializesModels;

    public $skillid;
    public $upload_id;
    public $uploadclass;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct($skillid, $upload_id, $uploadclass) {
        $this->skillid = $skillid;
        $this->upload_id = $upload_id;
        $this->uploadclass = $uploadclass;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return Channel|array
     */
    public function broadcastOn() {
        return new PrivateChannel('channel-name');
    }

}
