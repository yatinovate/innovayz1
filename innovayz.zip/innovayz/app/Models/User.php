<?php

namespace App\Models;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable {

    use Notifiable;
    use \HighIdeas\UsersOnline\Traits\UsersOnlineTrait;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password', 'token', 'user_type'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function roles() {
        return $this->belongsToMany('App\Models\User\Role')->withTimestamps();
    }

    public function hasRole($name) {
        foreach ($this->roles as $role) {
            if ($role->name == $name)
                return true;
        }

        return false;
    }

    public function assignRole($role) {
        return $this->roles()->attach($role);
    }

    public function removeRole($role) {
        return $this->roles()->detach($role);
    }

    public function social() {
        return $this->hasMany('App\Models\User\Social');
    }

    public function notifications() {
        return $this->belongsToMany('App\Models\User\Notifications'); // amend to your namespace
    }

    public function user_area() {
        return $this->hasMany('App\Models\User\User_Area');
    }

    // This function allows us to get a list of users following us
    public function followers() {
        return $this->belongsToMany('\App\Models\User', 'followers', 'followers_id', 'user_id')->withTimestamps();
    }

// Get all users we are following
    public function following() {
        return $this->belongsToMany('\App\Models\User', 'followers', 'user_id', 'followers_id')->withTimestamps();
    }

    public function user_knowledge() {
        return $this->hasMany('App\Models\Profile\PostKnowledge');
    }
    public function student() {
        return $this->hasOne("App\Models\Profile\Student");
    }
    public function teacher() {
        return $this->hasOne("App\Models\Profile\Teacher");
    }
    public function college() {
        return $this->hasOne("App\Models\Profile\College");
    }
    public function qulaifiaction() {
        return $this->hasMany('App\Models\User\Qulaification');
    }
    public function teaching() {
        return $this->hasMany('App\Models\User\Teacherskils');
    }
    
    public function contact() {
        return $this->hasOne("App\Models\User\Contact");
    }
    public function course() {
        return $this->hasMany('App\Models\User\Courses');
    }
    public function msgcount() {
        return $this->hasMany('App\Models\User\Courses');
    }
    

}
