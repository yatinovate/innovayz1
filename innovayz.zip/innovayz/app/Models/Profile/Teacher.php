<?php

namespace App\Models\Profile;

use Illuminate\Database\Eloquent\Model;

class Teacher extends Model
{
    protected $fillable = ['user_id','gender', 'dob','describe_yourself','grades','experience','current_Organization','Previous_Organization'];
    
       
}
