<?php

namespace App\Models\Profile;

use Illuminate\Database\Eloquent\Model;

class PostKnowledgeUser extends Model
{
    public function post() {
        return $this->belongsTo('\App\Models\Profile\PostKnowledge');
    }
    public function user() {
        return $this->hasOne("App\Models\User","id","user_id");
    }
}
