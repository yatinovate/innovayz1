<?php

namespace App\Models\Profile;

use Illuminate\Database\Eloquent\Model;

class Followers extends Model {

    protected $fillable = ['user_id', 'followers_id'];

    public function scopeGroupuser($query, $userArray) {
        return $query->whereNotIn('user_id', $userArray)
                        ->get();
    }
    public function user() {
        return $this->hasOne("App\Models\User",'id','user_id');
    }

}
