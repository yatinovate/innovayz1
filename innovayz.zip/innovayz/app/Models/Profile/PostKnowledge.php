<?php

namespace App\Models\Profile;

use Illuminate\Database\Eloquent\Model;

class PostKnowledge extends Model
{
    protected $fillable = ['id', 'user_id', 'Subject','Taguser','Description'];
    
    public function user() {
        return $this->hasOne("App\Models\User",'id');
    }
}
