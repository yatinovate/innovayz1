<?php

namespace App\Models\Profile;

use Illuminate\Database\Eloquent\Model;

class College extends Model
{
    protected $fillable = ['user_id', 'select_category','titlecol','affilatedby','approvedby','establishment','teachercount','studentcount','mastercount','curricular','breif','cgpa','avgcgpa','placecount','maxsal','avgsal','facilities'];
    
    
}
