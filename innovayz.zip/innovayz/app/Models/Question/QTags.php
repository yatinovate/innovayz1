<?php

namespace App\Models\Question;

use Illuminate\Database\Eloquent\Model;

class QTags extends Model
{
    public function q_tags() {
        return $this->hasOne('App\Models\User\AreaIntrest','id','tagid');        
    }
    public function tag_quest() {
        return $this->hasOne('App\Models\Question\PostQuestion','id','post_question_id');        
    }
}
