<?php

namespace App\Models\Question;

use Illuminate\Database\Eloquent\Model;

class PostQuestion extends Model
{
    public function question_tags() {
        return $this->hasMany('App\Models\Question\QTags');
    }
    public function answers() {
        return $this->hasMany('App\Models\Question\QnAnswers');
    }
    public function getCommentsAttribute()
    {
        $comments = $this->answers()->getQuery()->orderBy('created_at', 'desc')->get();
        return $comments;
    }
    public function user() {
        return $this->hasOne('App\Models\User','id','user_id');        
    }

}
