<?php

namespace App\Models\Question;

use Illuminate\Database\Eloquent\Model;

class QnAnswers extends Model
{
    //
}
