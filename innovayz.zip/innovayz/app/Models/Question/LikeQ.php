<?php

namespace App\Models\Question;

use Illuminate\Database\Eloquent\Model;

class LikeQ extends Model
{
    protected $fillable = ['answer_id', 'like'];
}
