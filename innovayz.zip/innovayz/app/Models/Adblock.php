<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Adblock extends Model
{
    //
}
