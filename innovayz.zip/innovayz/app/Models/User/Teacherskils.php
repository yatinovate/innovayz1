<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Model;

class Teacherskils extends Model
{
     public function subject() {
        return $this->hasOne('App\Models\User\AreaIntrest',"id","Subject");
    }
}
