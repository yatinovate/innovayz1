<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Model;

class CityState extends Model
{
    //
}
