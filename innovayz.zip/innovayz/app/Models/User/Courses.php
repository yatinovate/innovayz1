<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Model;

class Courses extends Model
{
    protected $fillable = ['id','user_id', 'course_name', 'duration_year','duration_month','course_desc','stream','fee','fee_type','eligi_criteria'];
}
