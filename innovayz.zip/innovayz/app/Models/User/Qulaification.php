<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Model;

class Qulaification extends Model
{
    protected $fillable = ['user_id', 'study_place','qualification','stream','institute'];
    
    public function specalization() {
        return $this->hasOne("App\Models\User\QualificationList",'id','qualification');
    }
    public function maxstream() {
        return $this->hasOne("App\Models\User\QualificationList",'id','stream');
    }
}
