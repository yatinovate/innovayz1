<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Model;

class InviteUser extends Model
{
    //
}
