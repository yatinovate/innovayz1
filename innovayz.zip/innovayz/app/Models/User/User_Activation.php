<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Model;

class User_Activation extends Model
{
    public function user()
    {
        return $this->belongsTo(\App\Models\User::class);
    }
}
