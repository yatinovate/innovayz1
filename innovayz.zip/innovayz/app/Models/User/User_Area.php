<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Model;

class User_Area extends Model
{
    protected $fillable = ['user_id','area_intrests_id'];   
    
   
    public function area_int()
    {
        return $this->belongsTo('App\Models\User\AreaIntrest','area_intrests_id');
    }
    
}
