<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Model;

class UserInstitute extends Model
{
    //
}
