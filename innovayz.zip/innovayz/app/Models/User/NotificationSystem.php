<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Model;

class NotificationSystem extends Model
{
    protected $fillable = ['user_id', 'subject', 'body', 'link', 'is_read'];

    public function users() {
        return $this->belongsToMany('App\Models\User'); // amend to your namespace
    }
}
