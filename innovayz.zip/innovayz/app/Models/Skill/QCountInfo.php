<?php

namespace App\Models\Skill;

use Illuminate\Database\Eloquent\Model;

class QCountInfo extends Model
{
    protected $fillable = ['skill_test_id', 'question_id', 'actual_question_id'];
}
