<?php

namespace App\Models\Skill;

use Illuminate\Database\Eloquent\Model;

class SkillTestMain extends Model
{
    public function activetest() {
        return $this->hasOne("App\Models\Skill\SkillActive","skill_tests_id");
    }
    public function area() {
        return $this->hasOne("App\Models\User\AreaIntrest","id","subject");
    }
}
