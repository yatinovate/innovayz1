<?php

namespace App\Models\Skill;

use Illuminate\Database\Eloquent\Model;

class ResultSkill extends Model
{
    protected $fillable = ['skill_test_id','user_id','points'];
}
