<?php

namespace App\Models\Skill;

use Illuminate\Database\Eloquent\Model;

class SkillActive extends Model
{
    protected $fillable = ['user_id','skill_id','points','reactive'];
}
