<?php

namespace App\Models\Skill;

use Illuminate\Database\Eloquent\Model;

class MultiChoice extends Model
{
    protected $fillable = ['skill_tests_id','points','question', 'ans_a', 'ans_b','ans_c','ans_d','correct_ans'];
}
