<?php

namespace App\Models\Skill;

use Illuminate\Database\Eloquent\Model;

class UploadCsv extends Model
{
    //
}
