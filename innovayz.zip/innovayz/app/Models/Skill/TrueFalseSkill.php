<?php

namespace App\Models\Skill;

use Illuminate\Database\Eloquent\Model;

class TrueFalseSkill extends Model
{
    protected $fillable = ['skill_tests_id','points','question','correct_ans'];
}
