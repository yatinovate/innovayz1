<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VisitorInfo extends Model
{
    //
}
