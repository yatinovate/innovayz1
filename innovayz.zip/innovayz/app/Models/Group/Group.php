<?php

namespace App\Models\Group;

use Illuminate\Database\Eloquent\Model;

class Group extends Model {

    protected $fillable = ['group_name', 'user_id', 'group_code'];

    public function grpusers() {
        return $this->hasMany('App\Models\Group\GroupUser');
    }
    public function grpchat() {
        return $this->hasMany('App\Models\Group\GroupChat');
    }

}
