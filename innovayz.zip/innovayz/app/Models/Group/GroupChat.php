<?php

namespace App\Models\Group;

use Illuminate\Database\Eloquent\Model;

class GroupChat extends Model
{
    //
}
