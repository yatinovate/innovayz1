<?php

namespace App\Models\Group;

use Illuminate\Database\Eloquent\Model;

class GroupsUser extends Model
{
    protected $fillable = ['group_id','user_id'];
    public function groupinfo() {
        //return $this->hasMany('App\Models\Group\Group');
        return $this->belongsTo('App\Models\Group\Group','group_id');
    }
}
