<?php

namespace App\Models\Group;

use Illuminate\Database\Eloquent\Model;

class UserRequest extends Model
{
    protected $fillable = ['user_id', 'group_id'];
}
