<?php

namespace App\Models\Challenge;

use Illuminate\Database\Eloquent\Model;

class MultiOptionCh extends Model
{
    protected $fillable = ['challenge_id','points','question', 'ans_a', 'ans_b','ans_c','ans_d','correct_ans'];
}
