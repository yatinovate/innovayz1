<?php

namespace App\Models\Challenge;

use Illuminate\Database\Eloquent\Model;

class ChallengeTest extends Model
{
    public function area() {
        return $this->hasOne("App\Models\User\AreaIntrest","id","subject");
    }
    public function activetest() {
        return $this->hasOne("App\Models\Challenge\ActiveChallenge","challenge_id");
    }
}
