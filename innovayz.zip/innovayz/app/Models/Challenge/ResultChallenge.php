<?php

namespace App\Models\Challenge;

use Illuminate\Database\Eloquent\Model;

class ResultChallenge extends Model
{
    protected $fillable = ['challenge_id','user_id','points'];
}
