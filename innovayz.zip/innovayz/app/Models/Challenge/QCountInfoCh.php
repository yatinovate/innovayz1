<?php

namespace App\Models\Challenge;

use Illuminate\Database\Eloquent\Model;

class QCountInfoCh extends Model
{
    protected $fillable = ['challenge_id', 'question_id', 'actual_question_id'];
}
