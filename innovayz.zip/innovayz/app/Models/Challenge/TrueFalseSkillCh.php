<?php

namespace App\Models\Challenge;

use Illuminate\Database\Eloquent\Model;

class TrueFalseSkillCh extends Model
{
    protected $fillable = ['challenge_id','points','question','correct_ans'];
}
