<?php

namespace App\Models\Challenge;

use Illuminate\Database\Eloquent\Model;

class ActiveChallenge extends Model
{
    protected $fillable = [
        'user_id', 'challenge_id' ];

}
