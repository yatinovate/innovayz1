<?php

namespace App\Models\Challenge;

use Illuminate\Database\Eloquent\Model;

class GroupChallenge extends Model
{
    //
}
