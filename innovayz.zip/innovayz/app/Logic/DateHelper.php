<?php
namespace App\Logic;
use Carbon\Carbon;

class DateHelper {

    public static function format($date, $format = 'M j'){

        return Carbon::parse($date)->format($format);
    }
}