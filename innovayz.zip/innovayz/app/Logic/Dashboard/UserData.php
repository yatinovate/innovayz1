<?php

namespace App\Logic\Dashboard;

use App\Models\User;
use Auth;
/**
 * Description of UserData
 *
 * @author YATIN
 */
class UserData {
    public function studentCount() {
        $concount=0;
        $users = \App\Models\Profile\Followers::where("followers_id", Auth::user()->id)->get();
        if (count($users)) {
            foreach ($users as $us) {
                $folwer = User::find($us->user_id);
                if ($folwer->user_type == 'students') {
                    $concount = $concount+1;
                } 
            }
        }
        return $concount;
    }
    public function teacherCount() {
        $concount=0;
        $users = \App\Models\Profile\Followers::where("followers_id", Auth::user()->id)->get();
        if (count($users)) {
            foreach ($users as $us) {
                $folwer = User::find($us->user_id);
                if ($folwer->user_type == 'teachers') {
                    $concount = $concount+1;
                }
            }
        }
        return $concount;
    }
    public function collegeCount() {
        $concount=0;
        $users = \App\Models\Profile\Followers::where("followers_id", Auth::user()->id)->get();
        if (count($users)) {
            foreach ($users as $us) {
                $folwer = User::find($us->user_id); 
                if ($folwer->user_type == 'colleges') {
                    $concount = $concount+1;
                }
            }
        }
        return $concount;
    }
    
    function suugestedcooncetion() {
        $questid = array();
        $uarea = Auth::user()->user_area;
        if (count($uarea)) {
            $u_array=array();
            foreach ($uarea as $area) {
                $area_u = \App\Models\User\User_Area::where('area_intrests_id', $area->area_int->id)->get();
                foreach ($area_u as $area) {
                    $followers = \App\Models\Profile\Followers::where("followers_id",$area->user_id )->where("user_id",Auth::user()->id)->get();
                    if(!count($followers)){
                        if($area->user_id!= Auth::user()->id){
                            $u_array[] = $area->user_id;
                        }
                    }
                }
            }
            $questid = array_unique($u_array);
        }
        return $questid;
    }
    function suugestedcooncetionguest($user) {
        $questid = array();
        $uarea = $user->user_area;
        if (count($uarea)) {
            foreach ($uarea as $area) {
                $area_u = \App\Models\User\User_Area::where('area_intrests_id', $area->area_int->id)->get();
                foreach ($area_u as $area) {
                    $followers = \App\Models\Profile\Followers::where("followers_id",$area->user_id )->where("user_id",$user->id)->get();
                    if(!count($followers)){
                        if($area->user_id!= $user->id){
                            $u_array[] = $area->user_id;
                        }
                    }
                }
            }
            $questid = array_unique($u_array);
        }
        return $questid;
    }

    public function countquestion() {
        $questid = array();
        $user_area = Auth::user()->user_area;
        if (count($user_area)) {
            foreach ($user_area as $area) {
                $areainta = $area->area_int->id;
                $questiontag = \App\Models\Question\QTags::where("tagid", $areainta)->orderBy('created_at', 'DESC')->get();
                if(count($questiontag)){
                 
                foreach ($questiontag as $ques) {
                    $qtnarray[] = $ques->post_question_id;
                }
                $questid = array_unique($qtnarray);   
                }
            }
        }
        $skillcount = count($questid);
        return $skillcount;
    }

    public function countchall() {
        if(Auth::user()->user_type=="teachers"){
        $chlnge= \App\Models\Challenge\ChallengeTest::where("user_id",Auth::user()->id)->get();
        $skillcount = count($chlnge);
        return $skillcount;
        }else{
        $user_area = Auth::user()->user_area;
        $dt = new \DateTime();
        $qtnarray = array();
        if (count($user_area)) {
            foreach ($user_area as $area) {
                $areainta = $area->area_int;
                $questiontag = \App\Models\Challenge\ChallengeTest::where("subject", $areainta->id)->where("publish", 1)
                                ->where("start_date", '<=', $dt->format('m/d/Y'))->where("end_date", '>=', $dt->format('m/d/Y'))->get();
                foreach ($questiontag as $ques) {
                    $checkgrpchall= \App\Models\Challenge\GroupChallenge::where("challenge_id",$ques->id)->first();
                    if(!$checkgrpchall){
                        $qtnarray[] = $ques->id;
                    }
                }
            }
        }
        $skillcount = count($qtnarray);
        return $skillcount;
        }
    }

    public function countskill() {
        $qtnarray = array();
        $user_area = Auth::user()->user_area;
        $dt = new \DateTime();
        if (count($user_area)) {
            foreach ($user_area as $area) {
                $areainta = $area->area_int;
                $questiontag = \App\Models\Skill\SkillTestMain::where("subject", $areainta->id)->where("publish", 1)
                                ->where("start_date", '<=', $dt->format('m/d/Y'))->where("end_date", '>=', $dt->format('m/d/Y'))->orderBy('created_at', 'DESC')->get();
                foreach ($questiontag as $ques) {
                    $qtnarray[] = $ques->id;
                }
            }
        }
        $skillcount = count($qtnarray);
        return $skillcount;
    }
}
