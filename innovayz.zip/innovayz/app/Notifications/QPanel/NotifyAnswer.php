<?php

namespace App\Notifications\QPanel;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;

class NotifyAnswer extends Notification implements ShouldQueue
{
    use Queueable;
    public $name;
    public $description;
    public $questionid;
    public $question;
    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($name,$description,$questionid,$question)
    {
        $this->name = $name;
        $this->description=$description;
        $this->questionid=$questionid;
        $this->question=$question;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
                    ->subject('InnoVayz :: Your question has got answer.')
                    ->greeting('Dear '.$this->name.',')
                    ->line('Please have a look for the answer suggested by some expert of the related Area of Interest.')
                    ->line('Note: Someone reply on Your Question "'.$this->question.'".')
                    ->action('Check Answer here',Route('question.q_detail',["q_code"=>$this->questionid,"q_detail"=>$this->question]))
                    ->line('Thank you for using our application!');
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
