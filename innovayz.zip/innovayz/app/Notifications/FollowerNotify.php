<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;

class FollowerNotify extends Notification implements ShouldQueue
{
    use Queueable;

    public $name1;
    public $name2;
    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($name1,$name2)
    {
        $this->name1 = $name1;
        $this->name2 = $name2;
    }


    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
                    ->subject("InnoVayz :: $this->name2 started following you on InnoVayz.")
                    ->greeting('Dear '.$this->name1.',')
                    ->line("$this->name2 has started following you to InnoVayz portal. He/She is inspired by your thoughts and knowledge base. 
                        Continue spread knowledge and raise your sunshine. Congratulations!! ");
                   // ->line('Thank you for using our application!');
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
