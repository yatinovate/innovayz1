<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;

class ChallengeNotify extends Notification implements ShouldQueue{

    use Queueable;

    public $name1;
    public $challname;
    public $arae;
    public $startdate;
    public $enddate;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($name1, $challname,$arae,$startdate,$enddate) {
        $this->name1 = $name1;
        $this->challname = $challname;
        $this->arae = $arae;
        $this->startdate = $startdate;
        $this->enddate = $enddate;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable) {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable) {
        return (new MailMessage)
                        ->subject("InnoVayz :: A new Challenge is created for you")
                        ->greeting('Dear ' . $this->name1 . ',')
                        ->line('A new Challange ' . $this->challname . ' has been started of subject ' . $this->arae . ' from ' . $this->startdate . ' to ' . $this->enddate . ' for you.')
                        ->line('This would help you to analyze your in depth knowledge and your rank about where you lies in contest.')
                        ->action('Check here', Route("student.geterpage"));
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable) {
        return [
                //
        ];
    }

}
